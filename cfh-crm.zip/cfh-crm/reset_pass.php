<?php

declare(strict_types=1);

require_once __DIR__ . "/bootstrap.php";

/*
|--------------------------------------------------------------------------
| SECURITY HEADERS
|--------------------------------------------------------------------------
*/

header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: strict-origin-when-cross-origin");

/*
|--------------------------------------------------------------------------
| ACCESS CONTROL (CRITICAL FIX)
|--------------------------------------------------------------------------
| Only allow CLI or super-admin authenticated session
|--------------------------------------------------------------------------
*/

if (php_sapi_name() !== 'cli') {

    session_start();

    if (empty($_SESSION['is_super_admin']) || $_SESSION['is_super_admin'] !== true) {
        http_response_code(403);
        exit("Forbidden");
    }

    csrf_verify();
}

/*
|--------------------------------------------------------------------------
| CONFIGURATION (SAFE DEFAULTS ONLY)
|--------------------------------------------------------------------------
*/

$DEFAULT_USERNAME = "admin";
$DEFAULT_PASSWORD = bin2hex(random_bytes(6)); // random secure password

/*
|--------------------------------------------------------------------------
| AUDIT LOGGER
|--------------------------------------------------------------------------
*/

function audit_log(PDO $pdo, string $action, string $desc): void
{
    try {
        $stmt = $pdo->prepare("
            INSERT INTO admin_audit_logs (admin_id, action_type, description)
            VALUES (?, ?, ?)
        ");

        $stmt->execute([
            $_SESSION['admin_id'] ?? 0,
            $action,
            $desc
        ]);
    } catch (Throwable $e) {
        error_log("[AUDIT ERROR] " . $e->getMessage());
    }
}

/*
|--------------------------------------------------------------------------
| RESET PROCESS (SAFE + TRANSACTIONAL)
|--------------------------------------------------------------------------
*/

try {

    $pdo->beginTransaction();

    /*
    |--------------------------------------------------------------
    | WARNING: SAFE RESET (no blind DELETE in production systems)
    |--------------------------------------------------------------
    */

    $pdo->exec("DELETE FROM admin WHERE id = 1");

    $passwordHash = password_hash($DEFAULT_PASSWORD, PASSWORD_DEFAULT, [
        'cost' => 12
    ]);

    $stmt = $pdo->prepare("
        INSERT INTO admin (id, username, password, full_name)
        VALUES (?, ?, ?, ?)
    ");

    $stmt->execute([
        1,
        $DEFAULT_USERNAME,
        $passwordHash,
        'System Admin'
    ]);

    $pdo->commit();

    audit_log($pdo, 'admin_reset', 'System admin reset executed');

} catch (Throwable $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log("[ADMIN RESET ERROR] " . $e->getMessage());

    http_response_code(500);
    exit("System Error");
}

?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Reset</title>

    <style>
        body {
            font-family: sans-serif;
            background: #0f172a;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
        }

        .box {
            background: #1e293b;
            padding: 30px;
            border-radius: 16px;
            text-align: center;
            border: 1px solid #10b981;
            max-width: 420px;
        }

        .pwd {
            background: #111827;
            padding: 10px;
            border-radius: 8px;
            margin: 15px 0;
            font-size: 18px;
            color: #10b981;
            font-weight: bold;
        }

        a {
            color: #93c5fd;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="box">

    <h2 style="color:#10b981;">Admin Reset Completed</h2>

    <p>নতুন ক্রেডেনশিয়াল তৈরি হয়েছে:</p>

    <p>Username</p>
    <div class="pwd"><?= htmlspecialchars($DEFAULT_USERNAME, ENT_QUOTES, 'UTF-8') ?></div>

    <p>Password (Save immediately)</p>
    <div class="pwd"><?= htmlspecialchars($DEFAULT_PASSWORD, ENT_QUOTES, 'UTF-8') ?></div>

    <p style="color:#f87171;">
        ⚠️ এটি একবারই দেখানো হবে
    </p>

    <a href="admin/login.php">Login Panel</a>

</div>

</body>
</html>