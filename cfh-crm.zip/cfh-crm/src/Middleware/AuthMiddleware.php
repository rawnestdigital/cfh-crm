<?php
/**
 * src/Middleware/AuthMiddleware.php
 */

declare(strict_types=1);

namespace CFH\Middleware;

use RuntimeException;

class AuthMiddleware
{
    public static function guard(?string $requiredPermission = null): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        if (empty($_SESSION['admin_id'])) {
            $_SESSION['login_redirect'] = $_SERVER['REQUEST_URI'] ?? '/admin/';
            header('Location: /admin/login.php');
            exit;
        }
        
        $lifetime = (int) ($_ENV['SESSION_LIFETIME'] ?? 7200);
        if (isset($_SESSION['login_at']) && (time() - $_SESSION['login_at'] > $lifetime)) {
            session_unset();
            session_destroy();
            header('Location: /admin/login.php?expired=1');
            exit;
        }
        $_SESSION['last_activity'] = time();
        
        $currentUa = hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '');
        if (!isset($_SESSION['user_agent']) || !hash_equals($_SESSION['user_agent'], $currentUa)) {
            session_unset();
            session_destroy();
            header('Location: /admin/login.php?security=1');
            exit;
        }
        
        if ($requiredPermission !== null) {
            self::checkPermission($requiredPermission);
        }
    }
    
    private static function checkPermission(string $permission): void
    {
        $role = $_SESSION['admin_role'] ?? 'admin';
        if ($role === 'superadmin') {
            return;
        }
        $rolePermissions = [
            'admin' => ['view_applicants', 'manage_applicants', 'export_data', 'view_logs', 'manage_settings'],
            'moderator' => ['view_applicants', 'manage_applicants', 'export_data'],
        ];
        $permissions = $rolePermissions[$role] ?? [];
        if (!in_array($permission, $permissions, true)) {
            throw new RuntimeException('You do not have permission to perform this action.');
        }
    }
    
    public static function getAdminId(): ?int
    {
        return isset($_SESSION['admin_id']) ? (int) $_SESSION['admin_id'] : null;
    }
}