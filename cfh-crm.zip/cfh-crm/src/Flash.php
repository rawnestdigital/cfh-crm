<?php
/**
 * src/Flash.php — Session-based flash messages
 */

declare(strict_types=1);

namespace CFH;

class Flash
{
    private const SESSION_KEY = '_flash_messages';
    
    public static function set(string $type, string $message): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (!isset($_SESSION[self::SESSION_KEY])) {
            $_SESSION[self::SESSION_KEY] = [];
        }
        $_SESSION[self::SESSION_KEY][$type] = $message;
    }
    
    public static function get(): array
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $messages = $_SESSION[self::SESSION_KEY] ?? [];
        unset($_SESSION[self::SESSION_KEY]);
        return $messages;
    }
    
    public static function getType(string $type): ?string
    {
        $messages = self::get();
        return $messages[$type] ?? null;
    }
    
    public static function render(): string
    {
        $messages = self::get();
        if (empty($messages)) {
            return '';
        }
        $html = '';
        foreach ($messages as $type => $message) {
            $color = match ($type) {
                'success' => 'bg-green-100 border-green-400 text-green-700',
                'error' => 'bg-red-100 border-red-400 text-red-700',
                'warning' => 'bg-yellow-100 border-yellow-400 text-yellow-700',
                'info' => 'bg-blue-100 border-blue-400 text-blue-700',
                default => 'bg-gray-100 border-gray-400 text-gray-700',
            };
            $icon = match ($type) {
                'success' => '✅',
                'error' => '❌',
                'warning' => '⚠️',
                'info' => 'ℹ️',
                default => '📝',
            };
            $html .= sprintf(
                '<div class="flash-message %s px-4 py-3 rounded border mb-4" role="alert">
                    <span class="font-bold">%s</span> %s
                </div>',
                $color,
                $icon,
                htmlspecialchars($message, ENT_QUOTES, 'UTF-8')
            );
        }
        return $html;
    }
}