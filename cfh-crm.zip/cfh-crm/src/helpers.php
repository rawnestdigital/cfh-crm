<?php
/**
 * src/helpers.php - Utility functions
 */

declare(strict_types=1);

if (!function_exists('generate_random_string')) {
    function generate_random_string(int $length = 16): string
    {
        if ($length < 1) return '';
        return substr(bin2hex(random_bytes($length)), 0, $length);
    }
}

if (!function_exists('is_valid_phone')) {
    function is_valid_phone(string $phone): bool
    {
        return preg_match('/^(01[3-9]\d{8})$/', $phone) === 1;
    }
}

if (!function_exists('is_valid_trx_id')) {
    function is_valid_trx_id(string $trxId): bool
    {
        return preg_match('/^[A-Za-z0-9]{6,30}$/', $trxId) === 1;
    }
}

if (!function_exists('sanitize_email')) {
    function sanitize_email(string $email)
    {
        $email = trim($email);
        return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : false;
    }
}

if (!function_exists('format_date')) {
    function format_date(string $date, string $format = 'd M Y'): string
    {
        $timestamp = strtotime($date);
        return $timestamp !== false ? date($format, $timestamp) : $date;
    }
}

if (!function_exists('time_elapsed_string')) {
    function time_elapsed_string(string $datetime, bool $full = false): string
    {
        $now = new DateTime();
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);
        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;
        $string = ['y' => 'year', 'm' => 'month', 'w' => 'week', 'd' => 'day', 'h' => 'hour', 'i' => 'minute', 's' => 'second'];
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }
        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }
}

if (!function_exists('paginate')) {
    function paginate(int $total, int $perPage = 25, int $current = 1): array
    {
        $perPage = max(1, $perPage);
        $totalPages = max(1, (int) ceil($total / $perPage));
        $current = min($totalPages, max(1, $current));
        return [
            'total' => $total,
            'per_page' => $perPage,
            'total_pages' => $totalPages,
            'current' => $current,
            'offset' => ($current - 1) * $perPage,
            'has_prev' => $current > 1,
            'has_next' => $current < $totalPages,
            'prev' => $current - 1,
            'next' => $current + 1,
        ];
    }
}

if (!function_exists('sanitize_filename')) {
    function sanitize_filename(string $filename): string
    {
        $filename = basename($filename);
        $filename = str_replace(' ', '_', $filename);
        $filename = preg_replace('/[^a-zA-Z0-9._-]/', '', $filename);
        if (strlen($filename) > 64) {
            $ext = pathinfo($filename, PATHINFO_EXTENSION);
            $name = pathinfo($filename, PATHINFO_FILENAME);
            $filename = substr($name, 0, 60 - strlen($ext)) . '.' . $ext;
        }
        return $filename ?: 'unnamed_file';
    }
}