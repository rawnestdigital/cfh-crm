<?php

declare(strict_types=1);

namespace CFH\Core;

/**
 * Fast, minimal HTTP router.
 *
 * Features:
 *   - GET / POST route registration
 *   - Named URL parameters: /programs/{slug}
 *   - Middleware stacks per route
 *   - Controller@method or \Closure handlers
 *   - 404 / 405 fallbacks
 *
 * Usage (in routes.php):
 *   $router->get('/',          HomeController::class . '@handle');
 *   $router->get('/about',     fn($req) => Response::html('…'));
 *   $router->post('/contact',  ContactController::class . '@submit');
 *   $router->get('/programs/{slug}', ProgramController::class . '@show');
 */
final class Router
{
    /** @var array<string, array{pattern:string, handler:mixed, middleware:string[]}> */
    private array $routes = [];

    public function __construct(private readonly Container $container) {}

    // ── Route registration ────────────────────────────────────────────────────

    public function get(string $path, mixed $handler, array $middleware = []): void
    {
        $this->add('GET', $path, $handler, $middleware);
    }

    public function post(string $path, mixed $handler, array $middleware = []): void
    {
        $this->add('POST', $path, $handler, $middleware);
    }

    public function any(string $path, mixed $handler, array $middleware = []): void
    {
        $this->add('*', $path, $handler, $middleware);
    }

    // ── Dispatch ──────────────────────────────────────────────────────────────

    public function dispatch(Request $request): void
    {
        $method = $request->method();
        $path   = rtrim($request->path(), '/') ?: '/';

        $methodMatched = false;

        foreach ($this->routes as $route) {
            $params = $this->matchRoute($route['pattern'], $path);
            if ($params === null) {
                continue;
            }

            if ($route['method'] !== '*' && $route['method'] !== $method) {
                $methodMatched = true;
                continue;
            }

            // Execute middleware pipeline
            foreach ($route['middleware'] as $mw) {
                $instance = $this->container->make($mw);
                $result   = $instance->handle($request);
                if ($result instanceof Response) {
                    $result->send();
                    return;
                }
            }

            // Dispatch handler
            $response = $this->call($route['handler'], $request, $params);
            if ($response instanceof Response) {
                $response->send();
            }
            return;
        }

        // No route matched
        if ($methodMatched) {
            $this->send405();
        } else {
            $this->send404();
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Match a route pattern against a URL path.
     * Returns array of captured params, or null if no match.
     */
    private function matchRoute(string $pattern, string $path): ?array
    {
        // Convert {param} placeholders to named regex groups
        $regex = preg_replace('/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/', '(?P<$1>[^/]+)', $pattern);
        $regex = '#^' . $regex . '$#u';

        if (!preg_match($regex, $path, $matches)) {
            return null;
        }

        // Return only named captures
        return array_filter($matches, fn($k) => is_string($k), ARRAY_FILTER_USE_KEY);
    }

    private function add(string $method, string $path, mixed $handler, array $middleware): void
    {
        // Normalise path: strip trailing slash (except root)
        $pattern = rtrim($path, '/') ?: '/';

        $this->routes[] = [
            'method'     => strtoupper($method),
            'pattern'    => $pattern,
            'handler'    => $handler,
            'middleware' => $middleware,
        ];
    }

    private function call(mixed $handler, Request $request, array $params): mixed
    {
        // Closure
        if ($handler instanceof \Closure) {
            return $handler($request, $params);
        }

        // "ClassName@method" string
        if (is_string($handler) && str_contains($handler, '@')) {
            [$class, $method] = explode('@', $handler, 2);
            $instance = $this->container->make($class);
            return $instance->$method($request, $params);
        }

        // Invokable class
        if (is_string($handler)) {
            $instance = $this->container->make($handler);
            return $instance($request, $params);
        }

        throw new \RuntimeException('Invalid route handler for path.');
    }

    private function send404(): void
    {
        http_response_code(404);
        $file = __DIR__ . '/../../views/errors/404.php';
        is_file($file) ? include $file : print('<h1>404 Not Found</h1>');
        exit;
    }

    private function send405(): void
    {
        http_response_code(405);
        header('Allow: GET, POST');
        echo json_encode(['error' => 'Method Not Allowed']);
        exit;
    }
}
