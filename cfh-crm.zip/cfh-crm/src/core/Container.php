<?php

declare(strict_types=1);

namespace CFH\Core;

/**
 * Minimal dependency injection container.
 *
 * Supports:
 *   - Singleton bindings:  $c->singleton(Foo::class, fn($c) => new Foo(...))
 *   - Transient bindings:  $c->bind(Foo::class, fn($c) => new Foo(...))
 *   - Resolution:          $c->make(Foo::class)
 *   - Auto-wiring:         $c->make(Foo::class) without prior binding uses
 *                          PHP reflection to inject constructor dependencies.
 */
final class Container
{
    /** @var array<string, \Closure> */
    private array $bindings = [];

    /** @var array<string, object> */
    private array $singletons = [];

    // ── Registration ──────────────────────────────────────────────────────────

    /**
     * Register a shared (singleton) binding.
     * The factory is called once; subsequent calls return the cached instance.
     */
    public function singleton(string $abstract, \Closure $factory): void
    {
        $this->bindings[$abstract] = $factory;
    }

    /**
     * Register a transient binding.
     * The factory is called every time make() is invoked.
     */
    public function bind(string $abstract, \Closure $factory): void
    {
        $this->bindings[$abstract] = $factory;
        unset($this->singletons[$abstract]);
    }

    /**
     * Register a pre-built instance as a singleton.
     */
    public function instance(string $abstract, object $instance): void
    {
        $this->singletons[$abstract] = $instance;
    }

    // ── Resolution ────────────────────────────────────────────────────────────

    /**
     * Resolve a class or interface from the container.
     *
     * @template T of object
     * @param  class-string<T> $abstract
     * @return T
     * @throws \RuntimeException if unable to resolve
     */
    public function make(string $abstract): object
    {
        // Already built singleton?
        if (isset($this->singletons[$abstract])) {
            /** @var T */
            return $this->singletons[$abstract];
        }

        // Has a binding?
        if (isset($this->bindings[$abstract])) {
            $instance = ($this->bindings[$abstract])($this);
            // Singletons are cached after first build
            $this->singletons[$abstract] = $instance;
            /** @var T */
            return $instance;
        }

        // Auto-wire via reflection
        return $this->autowire($abstract);
    }

    // ── Internals ─────────────────────────────────────────────────────────────

    private function autowire(string $class): object
    {
        if (!class_exists($class)) {
            throw new \RuntimeException("Cannot resolve [{$class}]: class does not exist.");
        }

        $ref = new \ReflectionClass($class);

        if (!$ref->isInstantiable()) {
            throw new \RuntimeException("Cannot instantiate [{$class}]: abstract or interface.");
        }

        $constructor = $ref->getConstructor();
        if ($constructor === null) {
            return $ref->newInstance();
        }

        $deps = [];
        foreach ($constructor->getParameters() as $param) {
            $type = $param->getType();
            if ($type instanceof \ReflectionNamedType && !$type->isBuiltin()) {
                $deps[] = $this->make($type->getName());
            } elseif ($param->isDefaultValueAvailable()) {
                $deps[] = $param->getDefaultValue();
            } else {
                throw new \RuntimeException(
                    "Cannot resolve parameter [{$param->getName()}] in [{$class}]."
                );
            }
        }

        return $ref->newInstanceArgs($deps);
    }
}
