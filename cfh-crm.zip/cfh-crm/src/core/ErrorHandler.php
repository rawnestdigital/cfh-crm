<?php

declare(strict_types=1);

namespace CFH\Core;

/**
 * Global PHP error + exception handler.
 *
 * Register once at the top of the front controller via:
 *     ErrorHandler::register('/path/to/views/errors');
 *
 * Renders:
 *   - views/errors/404.php   for HTTP 404
 *   - views/errors/429.php   for HTTP 429
 *   - views/errors/500.php   for all other errors
 *
 * In production (APP_DEBUG=false) the error message is suppressed.
 */
final class ErrorHandler
{
    private static string $errorViewsPath = '';

    public static function register(string $errorViewsPath): void
    {
        self::$errorViewsPath = rtrim($errorViewsPath, '/\\');

        set_exception_handler([self::class, 'handleException']);
        set_error_handler([self::class, 'handleError']);
        register_shutdown_function([self::class, 'handleShutdown']);
    }

    // ── Exception handler ─────────────────────────────────────────────────────

    public static function handleException(\Throwable $e): void
    {
        $code = $e->getCode();

        // Map known HTTP codes; everything else → 500
        $status = match(true) {
            $code === 404                         => 404,
            $code === 429                         => 429,
            $code >= 400 && $code < 600           => (int) $code,
            default                               => 500,
        };

        Logger::fromThrowable('Uncaught exception', $e, ['status' => $status]);

        self::respond($status, APP_DEBUG ? $e->getMessage() : '');
    }

    // ── Error handler (converts PHP errors to exceptions) ─────────────────────

    public static function handleError(
        int    $severity,
        string $message,
        string $file = '',
        int    $line = 0
    ): bool {
        if (!(error_reporting() & $severity)) {
            return false;
        }
        throw new \ErrorException($message, 0, $severity, $file, $line);
    }

    // ── Shutdown handler (catches fatal errors) ───────────────────────────────

    public static function handleShutdown(): void
    {
        $error = error_get_last();
        if ($error === null) {
            return;
        }
        $fatals = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];
        if (in_array($error['type'], $fatals, true)) {
            Logger::critical('Fatal error', [
                'message' => $error['message'],
                'file'    => $error['file'],
                'line'    => $error['line'],
            ]);
            self::respond(500, APP_DEBUG ? $error['message'] : '');
        }
    }

    // ── Response renderer ─────────────────────────────────────────────────────

    private static function respond(int $status, string $debugMessage = ''): void
    {
        if (!headers_sent()) {
            http_response_code($status);
        }

        $viewFile = self::$errorViewsPath . DIRECTORY_SEPARATOR . $status . '.php';
        $fallback = self::$errorViewsPath . DIRECTORY_SEPARATOR . '500.php';

        $file = is_file($viewFile) ? $viewFile : (is_file($fallback) ? $fallback : null);

        if ($file !== null) {
            $debug = $debugMessage;
            include $file;
        } else {
            echo "<!DOCTYPE html><html><body><h1>{$status} Error</h1>"
               . ($debugMessage ? "<pre>{$debugMessage}</pre>" : '')
               . "</body></html>";
        }
        exit;
