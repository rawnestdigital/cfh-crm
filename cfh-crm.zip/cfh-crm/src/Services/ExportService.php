<?php
/**
 * src/Services/ExportService.php
 */

declare(strict_types=1);

namespace CFH\Services;

use CFH\Database\ApplicantRepository;
use RuntimeException;

class ExportService
{
    private ApplicantRepository $applicantRepo;
    
    public function __construct(ApplicantRepository $applicantRepo)
    {
        $this->applicantRepo = $applicantRepo;
    }
    
    public function streamCsv(array $filters = [], string $filename = 'export.csv'): void
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        header('Pragma: no-cache');
        
        echo "\xEF\xBB\xBF";
        $output = fopen('php://output', 'w');
        if ($output === false) {
            throw new RuntimeException('Failed to open output stream');
        }
        
        fputcsv($output, ['ID', 'Name', 'Father Name', 'Mother Name', 'Phone', 'Blood Group', 'Team', 'Division', 'District', 'TrxID', 'Status', 'Created At']);
        
        foreach ($this->applicantRepo->exportQuery($filters) as $row) {
            fputcsv($output, [
                (string) ($row['id'] ?? ''),
                (string) ($row['name'] ?? ''),
                (string) ($row['father_name'] ?? ''),
                (string) ($row['mother_name'] ?? ''),
                (string) ($row['phone'] ?? ''),
                (string) ($row['blood_group'] ?? ''),
                (string) ($row['team_category'] ?? ''),
                (string) ($row['division'] ?? ''),
                (string) ($row['district'] ?? ''),
                (string) ($row['trx_id'] ?? ''),
                (string) ($row['status'] ?? ''),
                date('d-m-Y H:i', strtotime($row['created_at'] ?? 'now')),
            ]);
            flush();
        }
        fclose($output);
        exit;
    }
}