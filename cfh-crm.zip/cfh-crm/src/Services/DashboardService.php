<?php
/**
 * src/Services/DashboardService.php
 */

declare(strict_types=1);

namespace CFH\Services;

use CFH\Database\ApplicantRepository;

class DashboardService
{
    private ApplicantRepository $applicantRepo;
    
    public function __construct(ApplicantRepository $applicantRepo)
    {
        $this->applicantRepo = $applicantRepo;
    }
    
    public function getDashboardData(): array
    {
        return [
            'stats' => $this->applicantRepo->getStats(),
            'trend' => $this->applicantRepo->getTrend(7),
            'recent' => $this->applicantRepo->getRecent(8),
        ];
    }
}