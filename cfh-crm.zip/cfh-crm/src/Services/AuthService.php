<?php
/**
 * src/Services/AuthService.php
 */

declare(strict_types=1);

namespace CFH\Services;

use CFH\Database\AuditRepository;
use PDO;
use RuntimeException;

class AuthService
{
    private PDO $pdo;
    private AuditRepository $audit;
    
    public function __construct(PDO $pdo, AuditRepository $audit)
    {
        $this->pdo = $pdo;
        $this->audit = $audit;
    }
    
    public function login(string $username, string $password, string $ip): ?array
    {
        $stmt = $this->pdo->prepare("SELECT `id`, `username`, `password`, `full_name`, `role`, `is_active` FROM `cfh_admin` WHERE `username` = :username LIMIT 1");
        $stmt->execute([':username' => $username]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$admin || (int) $admin['is_active'] !== 1) {
            $this->audit->log(null, 'LOGIN_FAILED', "Failed login attempt: {$username}", $ip);
            return null;
        }
        
        if (!password_verify($password, $admin['password'])) {
            $this->audit->log((int) $admin['id'], 'LOGIN_FAILED', "Incorrect password for: {$username}", $ip);
            return null;
        }
        
        if (password_needs_rehash($admin['password'], PASSWORD_DEFAULT)) {
            $newHash = password_hash($password, PASSWORD_DEFAULT);
            $this->pdo->prepare("UPDATE `cfh_admin` SET `password` = :hash WHERE `id` = :id")->execute([':hash' => $newHash, ':id' => $admin['id']]);
        }
        
        $this->pdo->prepare("UPDATE `cfh_admin` SET `last_login_at` = NOW() WHERE `id` = :id")->execute([':id' => $admin['id']]);
        $this->audit->log((int) $admin['id'], 'LOGIN_SUCCESS', "Admin logged in: {$username}", $ip);
        
        return [
            'id' => (int) $admin['id'],
            'name' => (string) $admin['full_name'],
            'role' => (string) $admin['role'],
        ];
    }
    
    public function logout(int $adminId, string $ip): void
    {
        $this->audit->log($adminId, 'LOGOUT', 'Admin logged out', $ip);
    }
    
    public function changePassword(int $adminId, string $currentPassword, string $newPassword): bool
    {
        $stmt = $this->pdo->prepare("SELECT `password` FROM `cfh_admin` WHERE `id` = :id");
        $stmt->execute([':id' => $adminId]);
        $hash = $stmt->fetchColumn();
        
        if (!$hash) {
            throw new RuntimeException('Admin not found');
        }
        if (!password_verify($currentPassword, $hash)) {
            $this->audit->log($adminId, 'PASSWORD_FAILED', 'Failed password change attempt');
            throw new RuntimeException('Current password is incorrect');
        }
        
        $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
        $this->pdo->prepare("UPDATE `cfh_admin` SET `password` = :hash WHERE `id` = :id")->execute([':hash' => $newHash, ':id' => $adminId]);
        $this->audit->log($adminId, 'PASSWORD_CHANGED', 'Password changed successfully');
        return true;
    }
}