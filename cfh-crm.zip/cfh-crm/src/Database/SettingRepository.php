<?php
/**
 * src/Database/SettingRepository.php
 */

declare(strict_types=1);

namespace CFH\Database;

class SettingRepository extends Repository
{
    private const TABLE = 'cfh_settings';
    
    public function get(string $key): ?string
    {
        $sql = "SELECT `value` FROM `" . self::TABLE . "` WHERE `key` = :key LIMIT 1";
        $result = $this->fetchOne($sql, [':key' => $key]);
        return $result ? (string) $result['value'] : null;
    }
    
    public function getAll(?string $group = null): array
    {
        $sql = "SELECT `key`, `value` FROM `" . self::TABLE . "`";
        $params = [];
        if ($group !== null) {
            $sql .= " WHERE `group` = :group";
            $params[':group'] = $group;
        }
        $rows = $this->fetchAll($sql, $params);
        $result = [];
        foreach ($rows as $row) {
            $result[(string) $row['key']] = (string) $row['value'];
        }
        return $result;
    }
    
    public function set(string $key, string $value, ?string $group = null): void
    {
        $exists = $this->fetchColumn("SELECT COUNT(*) FROM `" . self::TABLE . "` WHERE `key` = :key", [':key' => $key]);
        if ($exists > 0) {
            $this->update(self::TABLE, ['value' => $value, 'group' => $group ?? 'general'], ['key' => $key]);
        } else {
            $this->insert(self::TABLE, ['key' => $key, 'value' => $value, 'group' => $group ?? 'general', 'type' => 'string']);
        }
    }
}