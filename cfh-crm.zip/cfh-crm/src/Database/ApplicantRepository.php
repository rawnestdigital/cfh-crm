<?php
/**
 * src/Database/ApplicantRepository.php
 */

declare(strict_types=1);

namespace CFH\Database;

use PDO;
use RuntimeException;

class ApplicantRepository extends Repository
{
    private const TABLE = 'cfh_applicants';
    
    public function getList(array $filters = [], int $lastId = 0, int $limit = 20): array
    {
        $whereConditions = ['1=1'];
        $params = [];
        
        if (!empty($filters['status'])) {
            $whereConditions[] = 'status = :status';
            $params[':status'] = $filters['status'];
        }
        if (!empty($filters['division'])) {
            $whereConditions[] = 'division = :division';
            $params[':division'] = $filters['division'];
        }
        if (!empty($filters['search'])) {
            $search = '%' . $filters['search'] . '%';
            $whereConditions[] = '(name LIKE :search OR phone LIKE :search OR trx_id LIKE :search)';
            $params[':search'] = $search;
        }
        if ($lastId > 0) {
            $whereConditions[] = 'id < :last_id';
            $params[':last_id'] = $lastId;
        }
        
        $whereSql = implode(' AND ', $whereConditions);
        $totalSql = "SELECT COUNT(*) FROM `" . self::TABLE . "` WHERE {$whereSql}";
        $total = (int) $this->fetchColumn($totalSql, $params);
        
        $sql = "SELECT `id`, `name`, `phone`, `blood_group`, `team_category`, 
                       `division`, `district`, `trx_id`, `status`, `created_at`
                FROM `" . self::TABLE . "`
                WHERE {$whereSql}
                ORDER BY `id` DESC
                LIMIT :limit";
        
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', $limit + 1, PDO::PARAM_INT);
        $stmt->execute();
        
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $nextId = null;
        if (count($items) > $limit) {
            $lastItem = array_pop($items);
            $nextId = (int) $lastItem['id'];
        }
        
        return [
            'items' => $items,
            'total' => $total,
            'next_id' => $nextId,
            'has_next' => $nextId !== null,
        ];
    }
    
    public function getStats(): array
    {
        $sql = "SELECT
                    COUNT(*) AS total,
                    SUM(`status` = 'pending') AS pending,
                    SUM(`status` = 'approved') AS approved,
                    SUM(`status` = 'rejected') AS rejected,
                    SUM(DATE(`created_at`) = CURDATE()) AS today
                FROM `" . self::TABLE . "`";
        $row = $this->fetchOne($sql) ?? [];
        return [
            'total' => max(0, (int) ($row['total'] ?? 0)),
            'pending' => max(0, (int) ($row['pending'] ?? 0)),
            'approved' => max(0, (int) ($row['approved'] ?? 0)),
            'rejected' => max(0, (int) ($row['rejected'] ?? 0)),
            'today' => max(0, (int) ($row['today'] ?? 0)),
        ];
    }
    
    public function getTrend(int $days = 7): array
    {
        $days = max(1, min(365, $days));
        $sql = "SELECT DATE(`created_at`) AS d, COUNT(*) AS c
                FROM `" . self::TABLE . "`
                WHERE `created_at` >= DATE_SUB(CURDATE(), INTERVAL :days DAY)
                GROUP BY DATE(`created_at`)
                ORDER BY d ASC";
        $rows = $this->fetchAll($sql, [':days' => $days - 1]);
        $byDate = [];
        foreach ($rows as $row) {
            $byDate[(string) ($row['d'] ?? '')] = (int) ($row['c'] ?? 0);
        }
        $counts = [];
        $labels = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $dateStr = date('Y-m-d', strtotime("-{$i} days"));
            $counts[] = $byDate[$dateStr] ?? 0;
            $labels[] = date('d M', strtotime($dateStr));
        }
        return ['counts' => $counts, 'labels' => $labels];
    }
    
    public function getRecent(int $limit = 8): array
    {
        $sql = "SELECT `id`, `name`, `phone`, `district`, `status`, `created_at`
                FROM `" . self::TABLE . "`
                ORDER BY `id` DESC
                LIMIT :limit";
        return $this->fetchAll($sql, [':limit' => max(1, $limit)]);
    }
    
    public function getById(int $id): ?array
    {
        $sql = "SELECT * FROM `" . self::TABLE . "` WHERE `id` = :id LIMIT 1";
        return $this->fetchOne($sql, [':id' => $id]);
    }
    
    public function updateStatus(int $id, string $status, int $adminId): bool
    {
        if (!in_array($status, ['pending', 'approved', 'rejected'], true)) {
            throw new RuntimeException('Invalid status value');
        }
        $current = $this->fetchOne("SELECT `status`, `name` FROM `" . self::TABLE . "` WHERE `id` = :id", [':id' => $id]);
        if (!$current) {
            throw new RuntimeException('Applicant not found');
        }
        if ($current['status'] === $status) {
            return false;
        }
        $this->beginTransaction();
        try {
            $this->update(self::TABLE, ['status' => $status, 'updated_at' => date('Y-m-d H:i:s')], ['id' => $id]);
            $this->commit();
            return true;
        } catch (\Throwable $e) {
            $this->rollBack();
            throw new RuntimeException('Failed to update status: ' . $e->getMessage(), 0, $e);
        }
    }
    
    public function exportQuery(array $filters = []): \Generator
    {
        $whereConditions = ['1=1'];
        $params = [];
        if (!empty($filters['status'])) {
            $whereConditions[] = 'status = :status';
            $params[':status'] = $filters['status'];
        }
        if (!empty($filters['from_date'])) {
            $whereConditions[] = 'DATE(created_at) >= :from_date';
            $params[':from_date'] = $filters['from_date'];
        }
        if (!empty($filters['to_date'])) {
            $whereConditions[] = 'DATE(created_at) <= :to_date';
            $params[':to_date'] = $filters['to_date'];
        }
        $whereSql = implode(' AND ', $whereConditions);
        $sql = "SELECT `id`, `name`, `father_name`, `mother_name`, `phone`, 
                       `blood_group`, `team_category`, `division`, `district`, 
                       `trx_id`, `status`, `created_at`
                FROM `" . self::TABLE . "`
                WHERE {$whereSql}
                ORDER BY `id` DESC";
        $this->pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            yield $row;
        }
        $stmt->closeCursor();
        $this->pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
    }
}