<?php
/**
 * src/Database/Repository.php - Base repository class
 */

declare(strict_types=1);

namespace CFH\Database;

use PDO;
use RuntimeException;

abstract class Repository
{
    protected PDO $pdo;
    
    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }
    
    protected function execute(string $sql, array $params = []): \PDOStatement
    {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (\PDOException $e) {
            throw new RuntimeException("Database error: " . $e->getMessage(), 0, $e);
        }
    }
    
    protected function fetchAll(string $sql, array $params = []): array
    {
        return $this->execute($sql, $params)->fetchAll(PDO::FETCH_ASSOC);
    }
    
    protected function fetchOne(string $sql, array $params = []): ?array
    {
        $result = $this->execute($sql, $params)->fetch(PDO::FETCH_ASSOC);
        return $result !== false ? $result : null;
    }
    
    protected function fetchColumn(string $sql, array $params = [], int $column = 0)
    {
        return $this->execute($sql, $params)->fetchColumn($column);
    }
    
    protected function insert(string $table, array $data): int
    {
        $columns = array_keys($data);
        $placeholders = array_fill(0, count($columns), '?');
        $sql = sprintf('INSERT INTO `%s` (`%s`) VALUES (%s)', $table, implode('`, `', $columns), implode(', ', $placeholders));
        $this->execute($sql, array_values($data));
        return (int) $this->pdo->lastInsertId();
    }
    
    protected function update(string $table, array $data, array $where): int
    {
        if (empty($data) || empty($where)) {
            return 0;
        }
        $setParts = [];
        foreach (array_keys($data) as $column) {
            $setParts[] = "`{$column}` = ?";
        }
        $whereParts = [];
        foreach (array_keys($where) as $column) {
            $whereParts[] = "`{$column}` = ?";
        }
        $sql = sprintf('UPDATE `%s` SET %s WHERE %s', $table, implode(', ', $setParts), implode(' AND ', $whereParts));
        $stmt = $this->execute($sql, array_merge(array_values($data), array_values($where)));
        return $stmt->rowCount();
    }
    
    protected function delete(string $table, array $where): int
    {
        if (empty($where)) {
            return 0;
        }
        $whereParts = [];
        foreach (array_keys($where) as $column) {
            $whereParts[] = "`{$column}` = ?";
        }
        $sql = sprintf('DELETE FROM `%s` WHERE %s', $table, implode(' AND ', $whereParts));
        $stmt = $this->execute($sql, array_values($where));
        return $stmt->rowCount();
    }
    
    protected function beginTransaction(): void
    {
        $this->pdo->beginTransaction();
    }
    
    protected function commit(): void
    {
        $this->pdo->commit();
    }
    
    protected function rollBack(): void
    {
        $this->pdo->rollBack();
    }
}