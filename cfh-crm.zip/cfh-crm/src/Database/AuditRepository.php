<?php
/**
 * src/Database/AuditRepository.php
 */

declare(strict_types=1);

namespace CFH\Database;

class AuditRepository extends Repository
{
    private const TABLE = 'cfh_audit_logs';
    
    public function log(?int $adminId, string $action, string $description = '', ?string $ip = null): int
    {
        if ($ip === null) {
            $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        }
        return $this->insert(self::TABLE, [
            'admin_id' => $adminId,
            'action_type' => $action,
            'description' => $description,
            'ip_address' => $ip,
        ]);
    }
    
    public function getLogs(array $filters = [], int $page = 1, int $perPage = 30): array
    {
        $whereConditions = ['1=1'];
        $params = [];
        if (!empty($filters['action_type'])) {
            $whereConditions[] = 'l.action_type = :action_type';
            $params[':action_type'] = $filters['action_type'];
        }
        if (!empty($filters['admin_id'])) {
            $whereConditions[] = 'l.admin_id = :admin_id';
            $params[':admin_id'] = $filters['admin_id'];
        }
        if (!empty($filters['from_date'])) {
            $whereConditions[] = 'DATE(l.created_at) >= :from_date';
            $params[':from_date'] = $filters['from_date'];
        }
        if (!empty($filters['to_date'])) {
            $whereConditions[] = 'DATE(l.created_at) <= :to_date';
            $params[':to_date'] = $filters['to_date'];
        }
        if (!empty($filters['search'])) {
            $whereConditions[] = '(l.description LIKE :search OR l.ip_address LIKE :search)';
            $params[':search'] = '%' . $filters['search'] . '%';
        }
        $whereSql = implode(' AND ', $whereConditions);
        $totalSql = "SELECT COUNT(*) FROM `" . self::TABLE . "` l WHERE {$whereSql}";
        $total = (int) $this->fetchColumn($totalSql, $params);
        $pagination = $this->pagination($total, $perPage, $page);
        $offset = $pagination['offset'];
        $sql = "SELECT l.*, a.username
                FROM `" . self::TABLE . "` l
                LEFT JOIN `cfh_admin` a ON a.id = l.admin_id
                WHERE {$whereSql}
                ORDER BY l.id DESC
                LIMIT :limit OFFSET :offset";
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', $perPage, \PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, \PDO::PARAM_INT);
        $stmt->execute();
        return [
            'items' => $stmt->fetchAll(\PDO::FETCH_ASSOC),
            'total' => $total,
            'pagination' => $pagination,
        ];
    }
    
    public function getDistinctActions(): array
    {
        $sql = "SELECT DISTINCT `action_type` FROM `" . self::TABLE . "` ORDER BY `action_type` ASC";
        return $this->fetchAll($sql, []);
    }
    
    private function pagination(int $total, int $perPage, int $current): array
    {
        $perPage = max(1, $perPage);
        $totalPages = max(1, (int) ceil($total / $perPage));
        $current = min($totalPages, max(1, $current));
        return [
            'total' => $total,
            'per_page' => $perPage,
            'current' => $current,
            'total_pages' => $totalPages,
            'offset' => ($current - 1) * $perPage,
            'has_prev' => $current > 1,
            'has_next' => $current < $totalPages,
        ];
    }
}