<?php
/**
 * src/Database/HomeContentRepository.php
 */

declare(strict_types=1);

namespace CFH\Database;

class HomeContentRepository extends Repository
{
    public function getAll(): array
    {
        return [
            'hero' => $this->getHero(),
            'missions' => $this->getMissions(),
            'stats' => $this->getStats(),
            'team' => $this->getTeam(),
            'programs' => $this->getPrograms(),
            'testimonials' => $this->getTestimonials(),
            'events' => $this->getEvents(),
            'gallery' => $this->getGallery(),
            'faqs' => $this->getFaqs(),
            'settings' => $this->getHomeSettings(),
        ];
    }
    
    public function getHero(): ?array
    {
        $sql = "SELECT * FROM `cfh_home_hero` WHERE `is_active` = 1 LIMIT 1";
        return $this->fetchOne($sql);
    }
    
    public function updateHero(array $data): bool
    {
        $this->update('cfh_home_hero', $data, ['id' => 1]);
        return true;
    }
    
    public function getMissions(?string $type = null): array
    {
        $sql = "SELECT * FROM `cfh_home_mission` WHERE `is_active` = 1";
        $params = [];
        if ($type !== null) {
            $sql .= " AND `type` = :type";
            $params[':type'] = $type;
        }
        $sql .= " ORDER BY `order` ASC";
        return $this->fetchAll($sql, $params);
    }
    
    public function addMission(array $data): int
    {
        return $this->insert('cfh_home_mission', $data);
    }
    
    public function getStats(): array
    {
        $sql = "SELECT * FROM `cfh_home_stats` WHERE `is_active` = 1 ORDER BY `order` ASC";
        return $this->fetchAll($sql);
    }
    
    public function updateStat(int $id, int $value): bool
    {
        $this->update('cfh_home_stats', ['value' => $value], ['id' => $id]);
        return true;
    }
    
    public function getTeam(): array
    {
        $sql = "SELECT * FROM `cfh_home_team` WHERE `is_active` = 1 ORDER BY `order` ASC";
        return $this->fetchAll($sql);
    }
    
    public function addTeamMember(array $data): int
    {
        return $this->insert('cfh_home_team', $data);
    }
    
    public function getPrograms(): array
    {
        $sql = "SELECT * FROM `cfh_home_programs` WHERE `is_active` = 1 ORDER BY `order` ASC";
        return $this->fetchAll($sql);
    }
    
    public function getTestimonials(): array
    {
        $sql = "SELECT * FROM `cfh_home_testimonials` WHERE `is_active` = 1 ORDER BY `order` ASC";
        return $this->fetchAll($sql);
    }
    
    public function getEvents(bool $upcomingOnly = false): array
    {
        $sql = "SELECT * FROM `cfh_home_events` WHERE `is_active` = 1";
        $params = [];
        if ($upcomingOnly) {
            $sql .= " AND (`date` IS NULL OR `date` >= CURDATE())";
        }
        $sql .= " ORDER BY `order` ASC, `date` ASC";
        return $this->fetchAll($sql, $params);
    }
    
    public function getGallery(): array
    {
        $sql = "SELECT * FROM `cfh_home_gallery` WHERE `is_active` = 1 ORDER BY `order` ASC";
        return $this->fetchAll($sql);
    }
    
    public function getFaqs(): array
    {
        $sql = "SELECT * FROM `cfh_home_faqs` WHERE `is_active` = 1 ORDER BY `order` ASC";
        return $this->fetchAll($sql);
    }
    
    public function getHomeSettings(): array
    {
        $sql = "SELECT `key`, `value` FROM `cfh_home_settings` WHERE `is_active` = 1";
        $rows = $this->fetchAll($sql);
        $result = [];
        foreach ($rows as $row) {
            $result[(string) $row['key']] = (string) $row['value'];
        }
        return $result;
    }
}