<?php
/**
 * public/index.php
 * 
 * CFH Homepage with full content management.
 * Uses caching for performance.
 */

declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

use CFH\Database\HomeContentRepository;

// Try to get cached content
$cacheFile = dirname(__DIR__) . '/storage/cache/homepage.html';
$cacheTTL = 300; // 5 minutes

if (file_exists($cacheFile) && time() - filemtime($cacheFile) < $cacheTTL) {
    // Serve cached version
    readfile($cacheFile);
    exit;
}

// Get fresh content
try {
    $pdo = require dirname(__DIR__) . '/config/database.php';
    $homeRepo = new HomeContentRepository($pdo);
    $content = $homeRepo->getAll();
} catch (Throwable $e) {
    error_log('[HOMEPAGE ERROR] ' . $e->getMessage());
    // Fallback to static content
    $content = [
        'hero' => ['title' => 'Building a <span class="gradient-text">Humane Bangladesh</span> Together.', 
                   'subtitle' => 'Founded 2024',
                   'description' => 'CFH is a technology-driven volunteer organization empowering youth to solve social crises across Bangladesh with compassion and action.'],
        'stats' => [
            ['label' => 'Volunteers', 'value' => 1200, 'suffix' => '+', 'icon' => 'fas fa-users'],
            ['label' => 'Lives Impacted', 'value' => 45000, 'suffix' => '+', 'icon' => 'fas fa-hands-helping'],
            ['label' => 'Districts', 'value' => 64, 'suffix' => '/64', 'icon' => 'fas fa-map-marker-alt'],
            ['label' => 'Projects', 'value' => 38, 'suffix' => '+', 'icon' => 'fas fa-seedling'],
        ],
        'missions' => [
            ['icon' => 'fa-eye', 'title' => 'Identify', 'description' => 'We use field research and data analytics to find where help is needed most.'],
            ['icon' => 'fa-users', 'title' => 'Mobilise', 'description' => 'We connect passionate volunteers with the right skills to the right cause.'],
            ['icon' => 'fa-bolt', 'title' => 'Act Fast', 'description' => 'Rapid deployment ensures aid reaches people within 48 hours of a crisis.'],
            ['icon' => 'fa-chart-bar', 'title' => 'Measure', 'description' => 'Every intervention is measured for impact, ensuring accountability and learning.'],
        ],
        'programs' => [
            ['title' => 'Emergency Relief', 'description' => 'Rapid response teams providing food, shelter, and medical aid during crises.'],
            ['title' => 'Youth Education', 'description' => 'Scholarships, tutoring centres, and digital skills training for underprivileged youth.'],
            ['title' => 'Clean Water Access', 'description' => 'Installation and maintenance of tube-wells and water purification units in remote areas.'],
        ],
        'testimonials' => [
            ['name' => 'Rahul Biswas', 'meta' => 'Former beneficiary, Dhaka', 'text' => 'CFH changed my life. The youth bootcamp gave me the skills I needed to get my first tech job.'],
        ],
        'faqs' => [
            ['question' => 'How do I become a volunteer?', 'answer' => 'Register on our website, complete a short onboarding quiz.'],
        ],
    ];
    // Safe defaults for other sections
    $content['team'] = $content['team'] ?? [];
    $content['events'] = $content['events'] ?? [];
    $content['gallery'] = $content['gallery'] ?? [];
}

// Start output buffering
ob_start();

// Include the actual homepage template
include dirname(__DIR__) . '/views/homepage.php';

// Capture output
$html = ob_get_clean();

// Save to cache
if (!is_dir(dirname($cacheFile))) {
    mkdir(dirname($cacheFile), 0755, true);
}
file_put_contents($cacheFile, $html);

// Serve
echo $html;