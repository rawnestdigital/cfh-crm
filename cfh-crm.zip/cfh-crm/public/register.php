<?php
/**
 * public/register.php
 * 
 * Multi-step registration form for new volunteers.
 * Uses SettingRepository for dynamic configuration.
 */

declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

use CFH\Database\SettingRepository;
use CFH\Flash;

// Get database connection
$pdo = require dirname(__DIR__) . '/config/database.php';

// Initialize repository
$settingRepo = new SettingRepository($pdo);

// Get payment settings
$bkashNumber = $settingRepo->get('bkash_number') ?: '017XXXXXXXX';
$regFee = (int) ($settingRepo->get('reg_fee') ?: 200);

// Get divisions from config
$divisions = defined('BD_DIVISIONS') ? BD_DIVISIONS : [];

// Generate CSRF token
$csrfToken = csrf_token();

// Flash messages (for errors)
$flash = Flash::render();

$pageTitle = 'সদস্য নিবন্ধন | CFH';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Hind Siliguri', sans-serif;
            background: #0f172a;
            color: #fff;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            padding: 20px;
        }
        .container {
            width: 100%;
            max-width: 850px;
            margin: 40px auto;
        }
        .card {
            background: rgba(30, 41, 59, 0.8);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            backdrop-filter: blur(8px);
        }
        .card h2 {
            text-align: center;
            color: #10b981;
            font-size: 28px;
            margin-bottom: 8px;
        }
        .card .subtitle {
            text-align: center;
            color: #94a3b8;
            margin-bottom: 24px;
        }
        .stepper {
            display: flex;
            margin-bottom: 30px;
            justify-content: center;
            gap: 0;
        }
        .step {
            display: flex;
            align-items: center;
            opacity: 0.4;
            transition: opacity 0.3s;
        }
        .step.active {
            opacity: 1;
        }
        .step .step-n {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #334155;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 14px;
            transition: background 0.3s;
        }
        .step.active .step-n {
            background: #10b981;
        }
        .step .step-line {
            width: 40px;
            height: 2px;
            background: #334155;
            margin: 0 8px;
            transition: background 0.3s;
        }
        .step.active .step-line {
            background: #10b981;
        }
        .panel {
            display: none;
            animation: fadeIn 0.3s ease;
        }
        .panel.active {
            display: block;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        .form-group {
            margin-bottom: 14px;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 4px;
            font-size: 14px;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px 12px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            color: #fff;
            font-size: 16px;
            transition: border-color 0.2s;
        }
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #10b981;
        }
        .form-group input.error {
            border-color: #ef4444;
        }
        .form-group .error-text {
            color: #ef4444;
            font-size: 13px;
            margin-top: 4px;
            display: none;
        }
        .form-group .error-text.show {
            display: block;
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary {
            background: #10b981;
            color: #fff;
        }
        .btn-primary:hover {
            background: #059669;
            transform: translateY(-2px);
        }
        .btn-secondary {
            background: #334155;
            color: #fff;
        }
        .btn-secondary:hover {
            background: #475569;
        }
        .btn-group {
            display: flex;
            gap: 12px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        .payment-info {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.2);
            border-radius: 8px;
            padding: 16px;
            margin: 16px 0;
        }
        .payment-info p {
            margin: 4px 0;
        }
        .payment-info .amount {
            font-size: 20px;
            font-weight: 700;
            color: #10b981;
        }
        .flash-message {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
        .flash-message.error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: #f87171;
        }
        .flash-message.success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: #34d399;
        }
        @media (max-width: 768px) {
            .grid { grid-template-columns: 1fr; }
            .card { padding: 20px; }
            .step .step-line { width: 20px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h2>সদস্য নিবন্ধন</h2>
            <p class="subtitle">Join the CFH volunteer movement</p>
            
            <?= $flash ?>
            
            <div class="stepper">
                <div class="step active" data-step="1">
                    <div class="step-n">1</div>
                    <div class="step-line"></div>
                </div>
                <div class="step" data-step="2">
                    <div class="step-n">2</div>
                    <div class="step-line"></div>
                </div>
                <div class="step" data-step="3">
                    <div class="step-n">3</div>
                </div>
            </div>
            
            <form id="registrationForm" method="POST" action="submit_registration.php" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
                
                <!-- Step 1: Personal Info -->
                <div class="panel active" data-panel="1">
                    <div class="grid">
                        <div class="form-group">
                            <label for="name">নাম *</label>
                            <input type="text" id="name" name="name" required autocomplete="name">
                            <div class="error-text" id="nameError">নাম আবশ্যক</div>
                        </div>
                        <div class="form-group">
                            <label for="father_name">পিতার নাম *</label>
                            <input type="text" id="father_name" name="father_name" required autocomplete="off">
                            <div class="error-text" id="fatherError">পিতার নাম আবশ্যক</div>
                        </div>
                        <div class="form-group">
                            <label for="mother_name">মাতার নাম *</label>
                            <input type="text" id="mother_name" name="mother_name" required autocomplete="off">
                            <div class="error-text" id="motherError">মাতার নাম আবশ্যক</div>
                        </div>
                        <div class="form-group">
                            <label for="phone">মোবাইল নম্বর *</label>
                            <input type="tel" id="phone" name="phone" required pattern="01[3-9]\d{8}" placeholder="01XXXXXXXXX">
                            <div class="error-text" id="phoneError">সঠিক মোবাইল নম্বর দিন (01XXXXXXXXX)</div>
                        </div>
                        <div class="form-group">
                            <label for="blood_group">রক্তের গ্রুপ</label>
                            <select id="blood_group" name="blood_group">
                                <option value="">নির্বাচন করুন</option>
                                <option value="A+">A+</option>
                                <option value="A-">A-</option>
                                <option value="B+">B+</option>
                                <option value="B-">B-</option>
                                <option value="O+">O+</option>
                                <option value="O-">O-</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="team_category">টিম ক্যাটাগরি</label>
                            <select id="team_category" name="team_category">
                                <option value="">নির্বাচন করুন</option>
                                <option value="টিম লিডার">টিম লিডার</option>
                                <option value="ভলান্টিয়ার">ভলান্টিয়ার</option>
                                <option value="মেম্বার">মেম্বার</option>
                            </select>
                        </div>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-primary" onclick="goToStep(2)">পরবর্তী →</button>
                    </div>
                </div>
                
                <!-- Step 2: Address -->
                <div class="panel" data-panel="2">
                    <div class="grid">
                        <div class="form-group">
                            <label for="division">বিভাগ</label>
                            <select id="division" name="division" onchange="loadDistricts(this.value)">
                                <option value="">নির্বাচন করুন</option>
                                <?php foreach (array_keys($divisions) as $div): ?>
                                    <option value="<?= h($div) ?>"><?= h($div) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="district">জেলা</label>
                            <select id="district" name="district">
                                <option value="">নির্বাচন করুন</option>
                            </select>
                        </div>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-secondary" onclick="goToStep(1)">← পেছনে</button>
                        <button type="button" class="btn btn-primary" onclick="goToStep(3)">পরবর্তী →</button>
                    </div>
                </div>
                
                <!-- Step 3: Payment & Upload -->
                <div class="panel" data-panel="3">
                    <div class="grid">
                        <div class="form-group">
                            <label for="photo">ছবি *</label>
                            <input type="file" id="photo" name="photo" accept="image/*" required>
                            <div class="error-text" id="photoError">ছবি আবশ্যক</div>
                        </div>
                        <div class="form-group">
                            <label for="nid_f">NID (সামনের অংশ)</label>
                            <input type="file" id="nid_f" name="nid_f" accept="image/*">
                        </div>
                        <div class="form-group">
                            <label for="nid_b">NID (পেছনের অংশ)</label>
                            <input type="file" id="nid_b" name="nid_b" accept="image/*">
                        </div>
                    </div>
                    
                    <div class="payment-info">
                        <p>💳 বিকাশ নম্বর: <strong><?= h($bkashNumber) ?></strong></p>
                        <p>রেজিস্ট্রেশন ফি: <span class="amount"><?= number_format($regFee) ?> টাকা</span></p>
                    </div>
                    
                    <div class="form-group">
                        <label for="trx_id">Transaction ID *</label>
                        <input type="text" id="trx_id" name="trx_id" required pattern="[A-Za-z0-9]{6,30}" placeholder="বিকাশের Transaction ID">
                        <div class="error-text" id="trxError">সঠিক Transaction ID দিন</div>
                    </div>
                    
                    <div class="btn-group">
                        <button type="button" class="btn btn-secondary" onclick="goToStep(2)">← পেছনে</button>
                        <button type="submit" class="btn btn-primary">জমা দিন</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Division/district data from PHP
        const divisions = <?= json_encode($divisions, JSON_HEX_TAG) ?>;
        
        function loadDistricts(division) {
            const districtSelect = document.getElementById('district');
            districtSelect.innerHTML = '<option value="">নির্বাচন করুন</option>';
            
            if (division && divisions[division]) {
                divisions[division].forEach(function(district) {
                    const option = document.createElement('option');
                    option.value = district;
                    option.textContent = district;
                    districtSelect.appendChild(option);
                });
            }
        }
        
        function goToStep(step) {
            // Validate current step before moving
            if (step > getCurrentStep() && !validateStep(getCurrentStep())) {
                return;
            }
            
            // Hide all panels
            document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
            document.querySelectorAll('.step').forEach(s => s.classList.remove('active'));
            
            // Show selected panel
            document.querySelector(`.panel[data-panel="${step}"]`).classList.add('active');
            
            // Update stepper
            for (let i = 1; i <= 3; i++) {
                const stepEl = document.querySelector(`.step[data-step="${i}"]`);
                if (i <= step) {
                    stepEl.classList.add('active');
                } else {
                    stepEl.classList.remove('active');
                }
            }
        }
        
        function getCurrentStep() {
            const activePanel = document.querySelector('.panel.active');
            return activePanel ? parseInt(activePanel.dataset.panel) : 1;
        }
        
        function validateStep(step) {
            let valid = true;
            
            if (step === 1) {
                const name = document.getElementById('name');
                const father = document.getElementById('father_name');
                const mother = document.getElementById('mother_name');
                const phone = document.getElementById('phone');
                
                if (!name.value.trim()) {
                    document.getElementById('nameError').classList.add('show');
                    name.classList.add('error');
                    valid = false;
                } else {
                    document.getElementById('nameError').classList.remove('show');
                    name.classList.remove('error');
                }
                
                if (!father.value.trim()) {
                    document.getElementById('fatherError').classList.add('show');
                    father.classList.add('error');
                    valid = false;
                } else {
                    document.getElementById('fatherError').classList.remove('show');
                    father.classList.remove('error');
                }
                
                if (!mother.value.trim()) {
                    document.getElementById('motherError').classList.add('show');
                    mother.classList.add('error');
                    valid = false;
                } else {
                    document.getElementById('motherError').classList.remove('show');
                    mother.classList.remove('error');
                }
                
                const phoneRegex = /^01[3-9]\d{8}$/;
                if (!phoneRegex.test(phone.value.trim())) {
                    document.getElementById('phoneError').classList.add('show');
                    phone.classList.add('error');
                    valid = false;
                } else {
                    document.getElementById('phoneError').classList.remove('show');
                    phone.classList.remove('error');
                }
            }
            
            return valid;
        }
        
        // Validate on form submit
        document.getElementById('registrationForm').addEventListener('submit', function(e) {
            if (!validateStep(3)) {
                e.preventDefault();
                return false;
            }
            
            const photo = document.getElementById('photo');
            if (!photo.files || photo.files.length === 0) {
                document.getElementById('photoError').classList.add('show');
                photo.classList.add('error');
                e.preventDefault();
                return false;
            }
            
            const trx = document.getElementById('trx_id');
            const trxRegex = /^[A-Za-z0-9]{6,30}$/;
            if (!trxRegex.test(trx.value.trim())) {
                document.getElementById('trxError').classList.add('show');
                trx.classList.add('error');
                e.preventDefault();
                return false;
            }
        });
    </script>
</body>
</html>