<?php

declare(strict_types=1);

require_once __DIR__ . "/../bootstrap.php";

/*
|--------------------------------------------------------------------------
| SECURITY: CSRF CHECK
|--------------------------------------------------------------------------
*/

csrf_verify();

/*
|--------------------------------------------------------------------------
| SECURITY: HEADERS (defensive reinforcement)
|--------------------------------------------------------------------------
*/

header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: DENY");
header("Referrer-Policy: strict-origin-when-cross-origin");

/*
|--------------------------------------------------------------------------
| CONFIG
|--------------------------------------------------------------------------
*/

$uploadBase = realpath(__DIR__ . "/../storage/uploads");

if ($uploadBase === false) {
    throw new RuntimeException("Upload directory missing.");
}

/*
|--------------------------------------------------------------------------
| AUDIT LOGGER
|--------------------------------------------------------------------------
*/

function audit_log(PDO $pdo, string $action, string $status): void
{
    try {
        $stmt = $pdo->prepare("
            INSERT INTO cfh_audit_logs (admin_id, action_type, description)
            VALUES (?, ?, ?)
        ");

        $stmt->execute([
            $_SESSION['admin_id'] ?? 0,
            $action,
            $status
        ]);
    } catch (Throwable $e) {
        error_log("[AUDIT FAIL] " . $e->getMessage());
    }
}

/*
|--------------------------------------------------------------------------
| SAFE FILE UPLOAD (HARDENED)
|--------------------------------------------------------------------------
*/

function secure_upload(array $file, string $baseDir): string
{
    if (
        !isset($file['error'], $file['tmp_name'], $file['size'])
    ) {
        throw new RuntimeException("Invalid upload structure.");
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException("Upload failed.");
    }

    if ($file['size'] > 2 * 1024 * 1024) {
        throw new RuntimeException("File too large.");
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($allowed[$mime])) {
        throw new RuntimeException("Invalid file type.");
    }

    $subDir = date("Y/m/d");

    $targetDir = rtrim($baseDir, "/") . "/" . $subDir;

    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $fileName = bin2hex(random_bytes(16)) . "." . $allowed[$mime];

    $destination = $targetDir . "/" . $fileName;

    if (!is_uploaded_file($file['tmp_name'])) {
        throw new RuntimeException("Possible file injection detected.");
    }

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new RuntimeException("Failed to store file.");
    }

    return $subDir . "/" . $fileName;
}

/*
|--------------------------------------------------------------------------
| MAIN PROCESS
|--------------------------------------------------------------------------
*/

try {

    $pdo->beginTransaction();

    /*
    |--------------------------
    | INPUT VALIDATION LAYER
    |--------------------------
    */

    $name        = trim($_POST['name'] ?? '');
    $father      = trim($_POST['father_name'] ?? '');
    $mother      = trim($_POST['mother_name'] ?? '');
    $phone       = trim($_POST['phone'] ?? '');
    $blood       = trim($_POST['blood_group'] ?? '');
    $category    = trim($_POST['team_category'] ?? '');
    $division    = trim($_POST['division'] ?? '');
    $district    = trim($_POST['district'] ?? '');
    $trxId       = trim($_POST['trx_id'] ?? '');

    if ($name === '' || $phone === '' || $father === '' || $mother === '') {
        throw new RuntimeException("Required fields missing.");
    }

    /*
    |--------------------------
    | FILE UPLOAD
    |--------------------------
    */

    $photo = secure_upload($_FILES['photo'], $uploadBase);

    $nidFront = !empty($_FILES['nid_f']['name'])
        ? secure_upload($_FILES['nid_f'], $uploadBase)
        : null;

    $nidBack = !empty($_FILES['nid_b']['name'])
        ? secure_upload($_FILES['nid_b'], $uploadBase)
        : null;

    /*
    |--------------------------
    | IP (GDPR SAFE OPTIONAL MASK)
    |--------------------------
    */

    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $ipHash = hash('sha256', $ip);

    /*
    |--------------------------
    | DATABASE INSERT (SAFE)
    |--------------------------
    */

    $stmt = $pdo->prepare("
        INSERT INTO cfh_applicants
        (
            name, father_name, mother_name,
            phone, blood_group, team_category,
            division, district,
            photo, nid_front, nid_back,
            trx_id, ip_address, status
        )
        VALUES
        (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    ");

    $stmt->execute([
        $name,
        $father,
        $mother,
        $phone,
        $blood,
        $category,
        $division,
        $district,
        $photo,
        $nidFront,
        $nidBack,
        $trxId,
        $ipHash
    ]);

    $id = (int)$pdo->lastInsertId();

    $pdo->commit();

    audit_log($pdo, 'registration', 'success #' . $id);

    header("Location: success.php?id=" . $id);
    exit;

} catch (Throwable $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log("[REG ERROR] " . $e->getMessage());

    audit_log($pdo, 'registration', 'failed');

    http_response_code(400);

    echo "
    <div style='font-family:sans-serif;text-align:center;padding:40px'>
        <h2>দুঃখিত!</h2>
        <p>আপনার অনুরোধটি সম্পন্ন করা যায়নি।</p>
        <a href='index.php'>আবার চেষ্টা করুন</a>
    </div>";
}