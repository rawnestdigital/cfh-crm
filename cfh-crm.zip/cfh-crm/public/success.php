<?php
/**
 * public/success.php
 * 
 * Registration success page with registration ID.
 */

declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    header('Location: index.php');
    exit;
}

// Get applicant data
$pdo = require dirname(__DIR__) . '/config/database.php';

$stmt = $pdo->prepare("SELECT name, phone, photo FROM cfh_applicants WHERE id = :id");
$stmt->execute([':id' => $id]);
$applicant = $stmt->fetch();

if (!$applicant) {
    header('Location: index.php');
    exit;
}

$regId = 'CFH-' . str_pad((string) $id, 5, '0', STR_PAD_LEFT);
$photoPath = !empty($applicant['photo']) 
    ? '/storage/public/uploads/' . $applicant['photo'] 
    : '/assets/img/no-image.png';

$pageTitle = 'নিবন্ধন সফল | CFH';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Hind Siliguri', sans-serif;
            background: #0f172a;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .success-box {
            background: #1e293b;
            padding: 40px;
            border-radius: 24px;
            text-align: center;
            max-width: 480px;
            width: 100%;
            border: 2px solid #10b981;
            box-shadow: 0 20px 60px rgba(0,0,0,0.5);
        }
        .success-box .icon {
            font-size: 64px;
            margin-bottom: 16px;
        }
        .success-box h1 {
            color: #10b981;
            font-size: 28px;
            margin-bottom: 8px;
        }
        .success-box p.sub {
            color: #94a3b8;
            margin-bottom: 24px;
        }
        .card-preview {
            background: #fff;
            border-radius: 16px;
            padding: 24px;
            text-align: left;
            margin-bottom: 24px;
            position: relative;
        }
        .card-preview .reg-id {
            font-size: 12px;
            color: #64748b;
        }
        .card-preview .reg-id-value {
            font-size: 20px;
            font-weight: 700;
            color: #0f172a;
        }
        .card-preview .details {
            margin-top: 12px;
        }
        .card-preview .details p {
            color: #475569;
            font-size: 15px;
            margin: 4px 0;
        }
        .card-preview .details strong {
            color: #0f172a;
        }
        .card-preview img {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 70px;
            height: 70px;
            border-radius: 12px;
            object-fit: cover;
            border: 2px solid #e2e8f0;
        }
        .btn {
            padding: 12px 28px;
            border: none;
            border-radius: 40px;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: #10b981;
            color: #fff;
        }
        .btn-primary:hover {
            background: #059669;
            transform: translateY(-2px);
        }
        .btn-secondary {
            background: #334155;
            color: #fff;
        }
        .btn-secondary:hover {
            background: #475569;
        }
        .btn-group {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
        }
        @media print {
            .btn-group { display: none; }
            .success-box { border: none; box-shadow: none; }
            .card-preview { border: 1px solid #e2e8f0; }
        }
        @media (max-width: 480px) {
            .success-box { padding: 24px; }
            .card-preview img { position: static; margin-bottom: 12px; }
            .card-preview { text-align: center; }
        }
    </style>
</head>
<body>
    <div class="success-box">
        <div class="icon">✅</div>
        <h1>আবেদন সফল!</h1>
        <p class="sub">আপনার তথ্য নিরাপদভাবে সংরক্ষিত হয়েছে।</p>
        
        <div class="card-preview">
            <img src="<?= h($photoPath) ?>" alt="Profile Photo">
            <div class="reg-id">রেজিস্ট্রেশন আইডি</div>
            <div class="reg-id-value"><?= h($regId) ?></div>
            <div class="details">
                <p><strong>নাম:</strong> <?= h($applicant['name']) ?></p>
                <p><strong>ফোন:</strong> <?= h($applicant['phone']) ?></p>
            </div>
        </div>
        
        <div class="btn-group">
            <button onclick="window.print()" class="btn btn-primary">🖨️ ডাউনলোড কপি</button>
            <a href="index.php" class="btn btn-secondary">মূল পাতায় ফিরুন</a>
        </div>
    </div>
</body>
</html>