<?php
/**
 * public/admin/login.php
 * 
 * Admin login page with rate limiting and CSRF protection.
 */

declare(strict_types=1);

// Bootstrap
require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

use CFH\Services\AuthService;
use CFH\Database\AuditRepository;
use CFH\Flash;

// Redirect if already logged in
if (!empty($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

// Get database connection
$pdo = require dirname(__DIR__, 2) . '/config/database.php';

// Initialize services
$auditRepo = new AuditRepository($pdo);
$authService = new AuthService($pdo, $auditRepo);

// Rate limiting
$ip = client_ip();
$lockFile = dirname(__DIR__, 2) . '/storage/private/locks/' . md5($ip) . '.lock';
$maxAttempts = (int) ($_ENV['LOGIN_MAX_ATTEMPTS'] ?? 5);
$lockoutTime = (int) ($_ENV['LOGIN_LOCKOUT_TIME'] ?? 900);

// Check if locked
$isLocked = false;
if (file_exists($lockFile)) {
    $data = file_get_contents($lockFile);
    $attempts = (int) ($data ?? 0);
    if ($attempts >= $maxAttempts) {
        // Check if lock has expired
        $mtime = filemtime($lockFile);
        if (time() - $mtime < $lockoutTime) {
            $isLocked = true;
        } else {
            unlink($lockFile);
        }
    }
}

$error = '';
$success = '';

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$isLocked) {
    try {
        csrf_verify();
        
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if ($username === '' || $password === '') {
            throw new RuntimeException('Username and password are required.');
        }
        
        $admin = $authService->login($username, $password, $ip);
        
        if ($admin === null) {
            // Record failed attempt
            if (!file_exists(dirname($lockFile))) {
                mkdir(dirname($lockFile), 0750, true);
            }
            $attempts = 1;
            if (file_exists($lockFile)) {
                $data = file_get_contents($lockFile);
                $attempts = (int) ($data ?? 0) + 1;
            }
            file_put_contents($lockFile, (string) $attempts, LOCK_EX);
            
            throw new RuntimeException('Invalid username or password.');
        }
        
        // Successful login - clear lock
        if (file_exists($lockFile)) {
            unlink($lockFile);
        }
        
        // Set session
        session_regenerate_id(true);
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['name'];
        $_SESSION['admin_role'] = $admin['role'];
        $_SESSION['login_at'] = time();
        $_SESSION['user_agent'] = hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '');
        
        // Redirect to dashboard or previous URL
        $redirect = $_SESSION['login_redirect'] ?? 'dashboard.php';
        unset($_SESSION['login_redirect']);
        header("Location: {$redirect}");
        exit;
        
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

// Get flash messages
$flashMessages = Flash::get();

// Generate CSRF token
$csrfToken = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | CFH</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #0f172a;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .login-box {
            background: #1e293b;
            padding: 40px;
            border-radius: 16px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.5);
        }
        .login-box h1 {
            color: #f8fafc;
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 6px;
        }
        .login-box p.sub {
            color: #94a3b8;
            font-size: 14px;
            margin-bottom: 24px;
        }
        .form-group {
            margin-bottom: 16px;
        }
        .form-group label {
            display: block;
            color: #94a3b8;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 6px;
        }
        .form-group input {
            width: 100%;
            padding: 12px 16px;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            color: #f8fafc;
            font-size: 16px;
            transition: border-color 0.2s;
        }
        .form-group input:focus {
            outline: none;
            border-color: #10b981;
        }
        .form-group input:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .btn-submit {
            width: 100%;
            padding: 12px;
            background: #10b981;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }
        .btn-submit:hover {
            background: #059669;
        }
        .btn-submit:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: #f87171;
        }
        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.2);
            color: #34d399;
        }
        .alert-info {
            background: rgba(59, 130, 246, 0.1);
            border: 1px solid rgba(59, 130, 246, 0.2);
            color: #60a5fa;
        }
        .lock-notice {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            color: #f87171;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
            text-align: center;
        }
        .footer-text {
            text-align: center;
            margin-top: 16px;
            color: #64748b;
            font-size: 14px;
        }
        .footer-text a {
            color: #10b981;
            text-decoration: none;
        }
        @media (max-width: 480px) {
            .login-box { padding: 24px; }
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h1>🔐 CFH Admin</h1>
        <p class="sub">Sign in to access the admin panel</p>
        
        <?php if ($isLocked): ?>
            <div class="lock-notice">
                ⛔ Too many failed attempts. Please try again in <?= ceil(($lockoutTime - (time() - filemtime($lockFile))) / 60) ?> minutes.
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?= h($error) ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?= h($success) ?></div>
        <?php endif; ?>
        
        <?php if (isset($_GET['expired'])): ?>
            <div class="alert alert-info">Your session has expired. Please log in again.</div>
        <?php endif; ?>
        
        <?php if (isset($_GET['security'])): ?>
            <div class="alert alert-error">Security verification failed. Please log in again.</div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
            
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required autocomplete="username" <?= $isLocked ? 'disabled' : '' ?>>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required autocomplete="current-password" <?= $isLocked ? 'disabled' : '' ?>>
            </div>
            
            <button type="submit" class="btn-submit" <?= $isLocked ? 'disabled' : '' ?>>Sign In</button>
        </form>
        
        <div class="footer-text">
            <a href="/">← Back to Homepage</a>
        </div>
    </div>
</body>
</html>