<?php
require_once __DIR__ . '/../bootstrap.php';
if(!empty($_SESSION['admin_id'])) log_audit(db(),'LOGOUT',"Admin logged out");
$_SESSION = [];
if(ini_get('session.use_cookies')){
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time()-86400, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();
header('Location: login.php');
exit;