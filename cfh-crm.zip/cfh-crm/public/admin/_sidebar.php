<?php
$activePage = $activePage ?? 'dashboard';
$adminName = h($_SESSION['admin_name'] ?? 'Admin');
$adminRole = $_SESSION['admin_role'] ?? 'admin';
$roleLabels = ['superadmin'=>'Super Admin','admin'=>'Administrator','moderator'=>'Moderator'];
$displayRole = $roleLabels[$adminRole] ?? 'Admin';
$avatarChar = mb_substr($adminName, 0, 1, 'UTF-8');

$nav = [
    'dashboard'   => ['icon'=>'📊','label'=>'Dashboard','href'=>'dashboard.php'],
    'applicants'  => ['icon'=>'👥','label'=>'Applicants','href'=>'applicants.php'],
    'logs'        => ['icon'=>'📋','label'=>'Audit Logs','href'=>'logs.php'],
    'export'      => ['icon'=>'📥','label'=>'Export','href'=>'export.php'],
    'home_settings'=>['icon'=>'🏠','label'=>'Homepage','href'=>'home_settings.php'],
    'settings'    => ['icon'=>'⚙️','label'=>'Settings','href'=>'settings.php'],
    'password'    => ['icon'=>'🔑','label'=>'Change Password','href'=>'change_password.php'],
];
?>
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header"><div class="logo">🌿 CFH Admin</div><button class="close-sidebar" onclick="toggleSidebar()">✕</button></div>
    <div class="user-profile"><div class="user-avatar"><?= $avatarChar ?></div><div><div class="user-name"><?= $adminName ?></div><div class="user-role"><?= $displayRole ?></div></div></div>
    <nav class="sidebar-nav"><?php foreach($nav as $key=>$item): ?><a href="<?= $item['href'] ?>" class="nav-item <?= $activePage===$key ? 'active' : '' ?>"><span class="nav-icon"><?= $item['icon'] ?></span><span><?= $item['label'] ?></span></a><?php endforeach; ?></nav>
    <div class="sidebar-footer"><a href="logout.php" class="nav-item logout" onclick="return confirm('Logout?')"><span class="nav-icon">🚪</span><span>Logout</span></a></div>
</aside>
<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--sidebar-w:280px;--primary:#10b981}
.sidebar{width:var(--sidebar-w);background:#0f172a;height:100vh;position:fixed;left:0;top:0;display:flex;flex-direction:column;border-right:1px solid #1e293b;z-index:1000;transition:transform .3s}
.sidebar-header{display:flex;justify-content:space-between;padding:24px 20px;border-bottom:1px solid #1e293b}
.logo{font-weight:800;font-size:18px;background:linear-gradient(135deg,#10b981,#3b82f6);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.close-sidebar{display:none;background:none;border:none;color:#94a3b8;font-size:20px;cursor:pointer}
.user-profile{margin:20px 16px;padding:16px;background:rgba(255,255,255,0.05);border-radius:20px;display:flex;gap:12px;align-items:center}
.user-avatar{width:48px;height:48px;background:linear-gradient(135deg,#10b981,#059669);border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700}
.user-name{font-weight:600;color:#f8fafc}.user-role{font-size:12px;color:#94a3b8}
.sidebar-nav{flex:1;padding:8px 12px;display:flex;flex-direction:column;gap:4px}
.nav-item{display:flex;align-items:center;gap:12px;padding:12px 16px;border-radius:14px;color:#94a3b8;text-decoration:none;transition:.2s}
.nav-item:hover{background:rgba(255,255,255,0.06);color:#f8fafc}
.nav-item.active{background:rgba(16,185,129,0.15);color:#10b981}
.nav-icon{font-size:20px;width:28px}
.logout{margin-top:auto;border-top:1px solid #1e293b;padding-top:16px;color:#f87171}
.sidebar-footer{padding:16px}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:999}
@media(max-width:768px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:translateX(0)}.close-sidebar{display:block}.sidebar-overlay.show{display:block}}
</style>
<script>function toggleSidebar(){var s=document.getElementById('sidebar'),o=document.getElementById('sidebarOverlay');if(s)s.classList.toggle('open');if(o)o.classList.toggle('show')}</script>