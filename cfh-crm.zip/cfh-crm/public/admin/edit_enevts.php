<?php
require_once __DIR__ . '/../bootstrap.php';
auth_guard();
require_permission('manage_settings');
$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect('manage_events.php');
$pdo = db();
$stmt = $pdo->prepare("SELECT * FROM cfh_home_events WHERE id = ?");
$stmt->execute([$id]);
$event = $stmt->fetch();
if (!$event) redirect('manage_events.php');
$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $date = $_POST['date'] ?? null;
    $location = $_POST['location'] ?? '';
    $type = $_POST['type'] ?? '';
    $order = (int)($_POST['order'] ?? 1);
    $image = $event['image'];
    if (!empty($_FILES['image']['name'])) {
        $upload = uploadFile($_FILES['image'], 'events');
        if ($upload['success']) $image = $upload['filename'];
        else $error = $upload['error'];
    }
    if (empty($error)) {
        $stmt = $pdo->prepare("UPDATE cfh_home_events SET title=?, description=?, date=?, location=?, type=?, image=?, `order`=? WHERE id=?");
        $stmt->execute([$title, $description, $date, $location, $type, $image, $order, $id]);
        $success = 'ইভেন্ট আপডেট করা হয়েছে।';
        // Refresh
        $stmt = $pdo->prepare("SELECT * FROM cfh_home_events WHERE id = ?");
        $stmt->execute([$id]);
        $event = $stmt->fetch();
    }
}
function uploadFile($file, $folder) { /* same as above */ }
?>
<!DOCTYPE html>
<html lang="bn">
<head><meta charset="UTF-8"><title>ইভেন্ট এডিট | CFH</title><link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet"><style>/* same styles as edit_team */</style></head>
<body><?php include '_sidebar.php'; ?><main class="main"><h1>✏️ ইভেন্ট এডিট</h1>
<?php if($success): ?><div class="alert alert-success">✅ <?=h($success)?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-error">⚠️ <?=h($error)?></div><?php endif; ?>
<div class="card">
<form method="POST" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=csrf_token()?>">
<div class="form-group"><label>শিরোনাম *</label><input type="text" name="title" value="<?=h($event['title'])?>" required></div>
<div class="form-group"><label>বিবরণ</label><textarea name="description" rows="3"><?=h($event['description'])?></textarea></div>
<div class="form-group"><label>তারিখ</label><input type="date" name="date" value="<?=$event['date']?>"></div>
<div class="form-group"><label>স্থান</label><input type="text" name="location" value="<?=h($event['location'])?>"></div>
<div class="form-group"><label>ধরন</label><input type="text" name="type" value="<?=h($event['type'])?>"></div>
<div class="form-group"><label>বর্তমান ছবি</label><br><?php if($event['image']): ?><img src="../storage/uploads/<?=h($event['image'])?>" width="80"><?php else: ?>ছবি নেই<?php endif; ?></div>
<div class="form-group"><label>নতুন ছবি</label><input type="file" name="image" accept="image/*"></div>
<div class="form-group"><label>অর্ডার</label><input type="number" name="order" value="<?=$event['order']?>"></div>
<button type="submit" class="btn">আপডেট করুন</button>
<a href="manage_events.php" class="btn" style="background:#64748b">বাতিল</a>
</form></div></main>
<script>function toggleSidebar(){var s=document.getElementById('sidebar'),o=document.getElementById('sidebarOverlay');if(s)s.classList.toggle('open');if(o)o.classList.toggle('show')}</script>
</body></html>