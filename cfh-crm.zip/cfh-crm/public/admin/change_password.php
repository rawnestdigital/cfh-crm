<?php
require_once __DIR__ . '/../bootstrap.php';
auth_guard();
$activePage = 'password';
$error = $success = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    csrf_verify();
    $current = $_POST['current'] ?? '';
    $new1 = $_POST['new1'] ?? '';
    $new2 = $_POST['new2'] ?? '';
    if(!$current || !$new1 || !$new2) $error = 'All fields required.';
    elseif(strlen($new1) < 8) $error = 'Password must be at least 8 characters.';
    elseif($new1 !== $new2) $error = 'New passwords do not match.';
    else{
        $stmt = db()->prepare("SELECT password FROM cfh_admin WHERE id = ?");
        $stmt->execute([(int)$_SESSION['admin_id']]);
        $hash = $stmt->fetchColumn();
        if(!password_verify($current, $hash)) $error = 'Current password incorrect.';
        else{
            db()->prepare("UPDATE cfh_admin SET password = ? WHERE id = ?")->execute([password_hash($new1, PASSWORD_DEFAULT), (int)$_SESSION['admin_id']]);
            log_audit(db(), 'PASSWORD', 'Password changed');
            $success = 'Password changed successfully.';
        }
    }
}
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Change Password | CFH</title><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet"><style>body{font-family:'Inter',sans-serif;background:#f1f5f9;display:flex}.main{margin-left:280px;flex:1;padding:32px;display:flex;justify-content:center;align-items:center}.card{background:#fff;border-radius:32px;padding:40px;max-width:480px;width:100%}.form-group{margin-bottom:20px}.form-group label{display:block;font-weight:600;margin-bottom:8px}.form-group input{width:100%;padding:12px;border:1px solid #e2e8f0;border-radius:16px}.btn{width:100%;padding:14px;background:#10b981;color:#fff;border:none;border-radius:40px;font-weight:600;cursor:pointer}.alert{padding:12px;border-radius:20px;margin-bottom:20px}.alert-success{background:#d1fae5;color:#065f46}.alert-error{background:#fee2e2;color:#991b1b}@media(max-width:768px){.main{margin-left:0;padding:16px}}</style></head>
<body><?php include '_sidebar.php'; ?><main class="main"><div class="card"><h2 style="margin-bottom:24px">🔑 Change Password</h2>
<?php if($success): ?><div class="alert alert-success">✅ <?=h($success)?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-error">⚠️ <?=h($error)?></div><?php endif; ?>
<form method="POST"><input type="hidden" name="csrf_token" value="<?=csrf_token()?>"><div class="form-group"><label>Current Password</label><input type="password" name="current" required></div><div class="form-group"><label>New Password</label><input type="password" name="new1" required></div><div class="form-group"><label>Confirm New Password</label><input type="password" name="new2" required></div><button type="submit" class="btn">Update Password</button></form></div></main></body></html>