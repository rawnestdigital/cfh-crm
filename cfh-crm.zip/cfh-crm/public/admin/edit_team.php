<?php
require_once __DIR__ . '/../bootstrap.php';
auth_guard();
require_permission('manage_settings');
$activePage = 'settings';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { redirect('manage_team.php'); }

$pdo = db();
$error = '';
$success = '';

// Fetch existing data
$stmt = $pdo->prepare("SELECT * FROM cfh_home_team WHERE id = ?");
$stmt->execute([$id]);
$member = $stmt->fetch();
if (!$member) { redirect('manage_team.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $name = $_POST['name'] ?? '';
    $position = $_POST['position'] ?? '';
    $bio = $_POST['bio'] ?? '';
    $facebook = $_POST['facebook'] ?? '';
    $twitter = $_POST['twitter'] ?? '';
    $linkedin = $_POST['linkedin'] ?? '';
    $order = (int)($_POST['order'] ?? 1);
    
    $photo = $member['photo'];
    if (!empty($_FILES['photo']['name'])) {
        $upload = uploadFile($_FILES['photo'], 'team');
        if ($upload['success']) {
            $photo = $upload['filename'];
        } else {
            $error = $upload['error'];
        }
    }
    
    if (empty($error)) {
        $stmt = $pdo->prepare("UPDATE cfh_home_team SET name=?, position=?, bio=?, photo=?, facebook=?, twitter=?, linkedin=?, `order`=? WHERE id=?");
        $stmt->execute([$name, $position, $bio, $photo, $facebook, $twitter, $linkedin, $order, $id]);
        $success = 'সদস্য আপডেট করা হয়েছে।';
        // Refresh data
        $stmt = $pdo->prepare("SELECT * FROM cfh_home_team WHERE id = ?");
        $stmt->execute([$id]);
        $member = $stmt->fetch();
    }
}

function uploadFile($file, $folder) {
    if ($file['error'] !== UPLOAD_ERR_OK) return ['success' => false, 'error' => 'Upload failed'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','webp'])) return ['success' => false, 'error' => 'Invalid file type'];
    $filename = uniqid() . '.' . $ext;
    $uploadDir = dirname(__DIR__) . '/storage/uploads/' . $folder;
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    if (move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $filename)) {
        return ['success' => true, 'filename' => $folder . '/' . $filename];
    }
    return ['success' => false, 'error' => 'Move failed'];
}
?>
<!DOCTYPE html>
<html lang="bn">
<head><meta charset="UTF-8"><title>টিম এডিট | CFH</title><link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet"><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Hind Siliguri',sans-serif;background:#f1f5f9;display:flex}:root{--sidebar-w:260px}.main{margin-left:var(--sidebar-w);flex:1;padding:32px}.card{background:#fff;border-radius:16px;padding:24px;margin-bottom:24px}.form-group{margin-bottom:16px}.form-group label{display:block;font-weight:600;margin-bottom:6px}.form-group input,.form-group textarea{width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:8px}.btn{padding:10px 20px;background:#10b981;color:#fff;border:none;border-radius:8px;cursor:pointer}.alert{padding:12px;border-radius:8px;margin-bottom:20px}.alert-success{background:#d1fae5;color:#065f46}.alert-error{background:#fee2e2;color:#991b1b}@media(max-width:768px){.main{margin-left:0;padding:16px}}</style></head>
<body><?php include '_sidebar.php'; ?><main class="main"><h1>✏️ টিম মেম্বার এডিট</h1>
<?php if($success): ?><div class="alert alert-success">✅ <?=h($success)?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-error">⚠️ <?=h($error)?></div><?php endif; ?>
<div class="card">
<form method="POST" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=csrf_token()?>">
<div class="form-group"><label>নাম *</label><input type="text" name="name" value="<?=h($member['name'])?>" required></div>
<div class="form-group"><label>পদবি</label><input type="text" name="position" value="<?=h($member['position'])?>"></div>
<div class="form-group"><label>বায়ো</label><textarea name="bio" rows="3"><?=h($member['bio'])?></textarea></div>
<div class="form-group"><label>বর্তমান ছবি</label><br><?php if($member['photo']): ?><img src="../storage/uploads/<?=h($member['photo'])?>" width="80" height="80" style="object-fit:cover;border-radius:10px"><?php else: ?>ছবি নেই<?php endif; ?></div>
<div class="form-group"><label>নতুন ছবি (ঐচ্ছিক)</label><input type="file" name="photo" accept="image/*"></div>
<div class="form-group"><label>ফেসবুক</label><input type="url" name="facebook" value="<?=h($member['facebook'])?>"></div>
<div class="form-group"><label>টুইটার</label><input type="url" name="twitter" value="<?=h($member['twitter'])?>"></div>
<div class="form-group"><label>লিংকডইন</label><input type="url" name="linkedin" value="<?=h($member['linkedin'])?>"></div>
<div class="form-group"><label>অর্ডার</label><input type="number" name="order" value="<?=$member['order']?>"></div>
<button type="submit" class="btn">আপডেট করুন</button>
<a href="manage_team.php" class="btn" style="background:#64748b">বাতিল</a>
</form></div></main>
<script>function toggleSidebar(){var s=document.getElementById('sidebar'),o=document.getElementById('sidebarOverlay');if(s)s.classList.toggle('open');if(o)o.classList.toggle('show')}</script>
</body></html>