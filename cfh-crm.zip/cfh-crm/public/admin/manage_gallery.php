<?php
require_once __DIR__ . '/../bootstrap.php';
auth_guard();
require_permission('manage_settings');
$activePage = 'settings';
$pdo = db();
$error = $success = '';

// Delete
if (isset($_GET['delete'])) {
    csrf_verify($_GET['csrf_token'] ?? '');
    $stmt = $pdo->prepare("DELETE FROM cfh_home_gallery WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    $success = 'ছবি মুছে ফেলা হয়েছে।';
}

// Add
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    csrf_verify();
    $title = $_POST['title'] ?? '';
    $category = $_POST['category'] ?? '';
    $order = (int)($_POST['order'] ?? 1);
    $upload = uploadFile($_FILES['image'], 'gallery');
    if ($upload['success']) {
        $stmt = $pdo->prepare("INSERT INTO cfh_home_gallery (title, image, category, `order`, is_active) VALUES (?,?,?,?,1)");
        $stmt->execute([$title, $upload['filename'], $category, $order]);
        $success = 'ছবি যোগ করা হয়েছে।';
    } else {
        $error = $upload['error'];
    }
}

$gallery = $pdo->query("SELECT * FROM cfh_home_gallery ORDER BY `order`")->fetchAll();

function uploadFile($file, $folder) { /* same as before */ }
?>
<!DOCTYPE html>
<html lang="bn">
<head><meta charset="UTF-8"><title>গ্যালারি ম্যানেজমেন্ট | CFH</title><link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet"><style>/* same base styles */</style></head>
<body><?php include '_sidebar.php'; ?><main class="main"><h1>🖼️ গ্যালারি ম্যানেজমেন্ট</h1>
<?php if($success): ?><div class="alert alert-success">✅ <?=h($success)?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-error">⚠️ <?=h($error)?></div><?php endif; ?>

<div class="card"><h2>➕ নতুন ছবি যোগ করুন</h2>
<form method="POST" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=csrf_token()?>">
<div class="form-group"><label>শিরোনাম (ঐচ্ছিক)</label><input type="text" name="title"></div>
<div class="form-group"><label>ক্যাটাগরি</label><input type="text" name="category" placeholder="যেমন: রক্তদান, শিক্ষা"></div>
<div class="form-group"><label>ছবি *</label><input type="file" name="image" accept="image/*" required></div>
<div class="form-group"><label>অর্ডার</label><input type="number" name="order" value="1"></div>
<button type="submit" class="btn">আপলোড করুন</button></form></div>

<div class="card"><h2>📷 বর্তমান গ্যালারি</h2>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:15px">
<?php foreach($gallery as $g): ?>
<div style="background:#fff;border-radius:12px;padding:10px;text-align:center">
<img src="../storage/uploads/<?=h($g['image'])?>" style="width:100%;height:120px;object-fit:cover;border-radius:8px">
<p style="margin:8px 0"><?=h($g['title'])?></p>
<small><?=h($g['category'])?></small><br>
<a href="?delete=<?=$g['id']?>&csrf_token=<?=urlencode(csrf_token())?>" onclick="return confirm('মুছতে চান?')" style="color:#ef4444;text-decoration:none">🗑️ ডিলিট</a>
</div>
<?php endforeach; ?>
</div></div></main>
<script>function toggleSidebar(){var s=document.getElementById('sidebar'),o=document.getElementById('sidebarOverlay');if(s)s.classList.toggle('open');if(o)o.classList.toggle('show')}</script>
</body></html>