<?php
/**
 * public/admin/dashboard.php
 * 
 * Admin dashboard with stats, trends, and recent applicants.
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

use CFH\Middleware\AuthMiddleware;
use CFH\Services\DashboardService;
use CFH\Database\ApplicantRepository;
use CFH\Flash;

// Require authentication
AuthMiddleware::guard('view_applicants');

// Get database connection
$pdo = require dirname(__DIR__, 2) . '/config/database.php';

// Initialize repositories and services
$applicantRepo = new ApplicantRepository($pdo);
$dashboardService = new DashboardService($applicantRepo);

// Get dashboard data
$data = $dashboardService->getDashboardData();
$stats = $data['stats'];
$trend = $data['trend'];
$recent = $data['recent'];

// Calculate approval rate
$approvalRate = $stats['total'] > 0 
    ? round(($stats['approved'] / $stats['total']) * 100, 1) 
    : 0;

// Get flash messages
$flash = Flash::render();

// Page title
$pageTitle = 'Dashboard | CFH Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #f1f5f9;
            display: flex;
            min-height: 100vh;
        }
        :root { --sidebar-w: 280px; --primary: #10b981; }
        .main {
            margin-left: var(--sidebar-w);
            flex: 1;
            padding: 32px;
            min-height: 100vh;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 12px;
        }
        .page-header h1 {
            font-size: 28px;
            font-weight: 700;
            color: #0f172a;
        }
        .page-header .date-display {
            color: #64748b;
            font-size: 14px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }
        .stat-card {
            background: #fff;
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            border: 1px solid #e2e8f0;
            transition: transform 0.2s;
        }
        .stat-card:hover { transform: translateY(-2px); }
        .stat-label {
            font-size: 13px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
        }
        .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: #0f172a;
            margin: 4px 0;
        }
        .stat-sub {
            font-size: 13px;
            color: #94a3b8;
        }
        .stat-card .stat-value.green { color: #10b981; }
        .stat-card .stat-value.yellow { color: #f59e0b; }
        .stat-card .stat-value.red { color: #ef4444; }
        .stat-card .stat-value.blue { color: #3b82f6; }
        
        .two-col {
            display: grid;
            grid-template-columns: 1fr 1.5fr;
            gap: 24px;
            margin-bottom: 32px;
        }
        .panel {
            background: #fff;
            border-radius: 16px;
            border: 1px solid #e2e8f0;
            overflow: hidden;
        }
        .panel-header {
            padding: 16px 20px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .panel-header strong { font-size: 15px; color: #0f172a; }
        .panel-header a { color: #10b981; text-decoration: none; font-size: 14px; }
        .panel-header a:hover { text-decoration: underline; }
        .chart-container { padding: 16px; height: 260px; }
        .recent-table { width: 100%; border-collapse: collapse; }
        .recent-table th, .recent-table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        .recent-table th {
            background: #f8fafc;
            font-size: 12px;
            text-transform: uppercase;
            color: #64748b;
            letter-spacing: 0.5px;
        }
        .badge {
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        .badge-pending { background: #fef3c7; color: #92400e; }
        .badge-approved { background: #d1fae5; color: #065f46; }
        .badge-rejected { background: #fee2e2; color: #991b1b; }
        .view-link { color: #10b981; text-decoration: none; font-weight: 500; }
        .view-link:hover { text-decoration: underline; }
        
        .quick-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 16px;
        }
        .quick-actions a {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 40px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s;
        }
        .quick-actions .btn-primary {
            background: #10b981;
            color: #fff;
        }
        .quick-actions .btn-primary:hover { background: #059669; transform: translateY(-2px); }
        .quick-actions .btn-outline {
            background: #fff;
            border: 1px solid #e2e8f0;
            color: #1e293b;
        }
        .quick-actions .btn-outline:hover {
            border-color: #10b981;
            color: #10b981;
        }
        
        @media (max-width: 1024px) {
            .two-col { grid-template-columns: 1fr; }
        }
        @media (max-width: 768px) {
            .main { margin-left: 0; padding: 16px; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .page-header h1 { font-size: 22px; }
            .stat-value { font-size: 26px; }
        }
        @media (max-width: 480px) {
            .stats-grid { grid-template-columns: 1fr; }
            .page-header { flex-direction: column; align-items: flex-start; }
        }
    </style>
</head>
<body>
    <?php include '_sidebar.php'; ?>
    
    <main class="main">
        <div class="page-header">
            <h1>👋 Welcome back, <?= h($_SESSION['admin_name'] ?? 'Admin') ?></h1>
            <div class="date-display"><?= date('l, F j, Y') ?></div>
        </div>
        
        <?= $flash ?>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">Total Applications</div>
                <div class="stat-value"><?= number_format($stats['total']) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Today</div>
                <div class="stat-value green"><?= number_format($stats['today']) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Pending</div>
                <div class="stat-value yellow"><?= number_format($stats['pending']) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Approved</div>
                <div class="stat-value green"><?= number_format($stats['approved']) ?></div>
                <div class="stat-sub"><?= $approvalRate ?>% approval rate</div>
            </div>
        </div>
        
        <div class="two-col">
            <div class="panel">
                <div class="panel-header">
                    <strong>📈 7-Day Trend</strong>
                </div>
                <div class="chart-container">
                    <canvas id="trendChart"></canvas>
                </div>
            </div>
            <div class="panel">
                <div class="panel-header">
                    <strong>🕒 Recent Applicants</strong>
                    <a href="applicants.php">View all →</a>
                </div>
                <div style="overflow-x: auto;">
                    <table class="recent-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>District</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent)): ?>
                                <tr><td colspan="5" style="text-align:center;padding:30px;color:#94a3b8;">No applicants yet</td></tr>
                            <?php else: foreach ($recent as $r): ?>
                                <tr>
                                    <td><strong><?= h($r['name']) ?></strong></td>
                                    <td><?= h($r['phone']) ?></td>
                                    <td><?= h($r['district']) ?></td>
                                    <td><span class="badge badge-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
                                    <td><a href="view.php?id=<?= (int) $r['id'] ?>" class="view-link">View</a></td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="quick-actions">
            <a href="home_settings.php" class="btn-primary">🎨 Customize Homepage</a>
            <a href="manage_team.php" class="btn-outline">👥 Team</a>
            <a href="manage_events.php" class="btn-outline">📅 Events</a>
            <a href="manage_gallery.php" class="btn-outline">🖼️ Gallery</a>
            <a href="settings.php" class="btn-outline">⚙️ Settings</a>
        </div>
    </main>
    
    <script nonce="<?= h(csrf_token()) ?>">
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('trendChart');
            if (!ctx) return;
            
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?= json_encode($trend['labels']) ?>,
                    datasets: [{
                        label: 'Applications',
                        data: <?= json_encode($trend['counts']) ?>,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        fill: true,
                        tension: 0.3,
                        pointRadius: 4,
                        pointBackgroundColor: '#10b981',
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: 'rgba(15, 23, 42, 0.9)',
                            titleColor: '#f8fafc',
                            bodyColor: '#f8fafc',
                            cornerRadius: 8,
                            padding: 12,
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: '#e2e8f0' },
                            ticks: { stepSize: 1 }
                        },
                        x: {
                            grid: { display: false }
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>