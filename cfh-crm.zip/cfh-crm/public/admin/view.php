<?php
/**
 * public/admin/view.php
 * 
 * Single applicant view with full details.
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

use CFH\Middleware\AuthMiddleware;
use CFH\Database\ApplicantRepository;
use CFH\Flash;

// Require authentication
AuthMiddleware::guard('view_applicants');

// Get ID from URL
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    Flash::set('error', 'Invalid applicant ID.');
    header('Location: applicants.php');
    exit;
}

// Get database connection
$pdo = require dirname(__DIR__, 2) . '/config/database.php';

// Initialize repository
$applicantRepo = new ApplicantRepository($pdo);

// Get applicant data
$applicant = $applicantRepo->getById($id);
if (!$applicant) {
    Flash::set('error', 'Applicant not found.');
    header('Location: applicants.php');
    exit;
}

// Status options
$statusOptions = ['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected'];

// Build photo and NID paths
$photoPath = !empty($applicant['photo']) 
    ? '/storage/uploads/' . $applicant['photo'] 
    : '/assets/img/no-image.png';
$nidFront = !empty($applicant['nid_front']) 
    ? '/storage/uploads/' . $applicant['nid_front'] 
    : null;
$nidBack = !empty($applicant['nid_back']) 
    ? '/storage/uploads/' . $applicant['nid_back'] 
    : null;

// Flash messages
$flash = Flash::render();

// Generate CSRF token for action form
$csrfToken = csrf_token();

$pageTitle = 'Applicant #' . $id . ' | CFH Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #f1f5f9;
            display: flex;
            min-height: 100vh;
        }
        :root { --sidebar-w: 280px; --primary: #10b981; }
        .main {
            margin-left: var(--sidebar-w);
            flex: 1;
            padding: 32px;
            min-height: 100vh;
        }
        .profile-card {
            background: #fff;
            border-radius: 24px;
            padding: 32px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            max-width: 1000px;
        }
        .header {
            display: flex;
            gap: 24px;
            align-items: center;
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 24px;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }
        .avatar {
            width: 100px;
            height: 100px;
            border-radius: 16px;
            object-fit: cover;
            border: 3px solid #e2e8f0;
            flex-shrink: 0;
        }
        .header-info h1 {
            font-size: 24px;
            font-weight: 700;
            color: #0f172a;
        }
        .header-info .id-status {
            color: #64748b;
            font-size: 14px;
        }
        .badge {
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        .badge-pending { background: #fef3c7; color: #92400e; }
        .badge-approved { background: #d1fae5; color: #065f46; }
        .badge-rejected { background: #fee2e2; color: #991b1b; }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 16px;
            margin-bottom: 30px;
        }
        .info-item {
            background: #f8fafc;
            padding: 16px;
            border-radius: 12px;
        }
        .info-item .label {
            font-size: 12px;
            color: #64748b;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .info-item .value {
            font-weight: 600;
            color: #0f172a;
            margin-top: 4px;
        }
        .info-item .value code {
            background: #e2e8f0;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 13px;
        }
        .images {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 30px;
        }
        .images .doc-item {
            flex: 1;
            min-width: 200px;
        }
        .images .doc-item .label {
            font-size: 12px;
            color: #64748b;
            font-weight: 500;
            margin-bottom: 8px;
        }
        .doc-img {
            width: 100%;
            max-width: 300px;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            object-fit: cover;
            max-height: 300px;
        }
        .actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }
        .btn {
            padding: 10px 24px;
            border-radius: 40px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            transition: all 0.2s;
        }
        .btn-success {
            background: #10b981;
            color: #fff;
        }
        .btn-success:hover {
            background: #059669;
            transform: translateY(-2px);
        }
        .btn-danger {
            background: #ef4444;
            color: #fff;
        }
        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-2px);
        }
        .btn-secondary {
            background: #e2e8f0;
            color: #1e293b;
        }
        .btn-secondary:hover {
            background: #cbd5e1;
        }
        .flash-message {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
        .flash-message.success {
            background: #d1fae5;
            border: 1px solid #a7f3d0;
            color: #065f46;
        }
        .flash-message.error {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #991b1b;
        }
        .flash-message.info {
            background: #dbeafe;
            border: 1px solid #bfdbfe;
            color: #1e40af;
        }
        @media (max-width: 768px) {
            .main { margin-left: 0; padding: 16px; }
            .header { flex-direction: column; text-align: center; }
            .avatar { margin: 0 auto; }
            .grid { grid-template-columns: 1fr; }
            .actions { justify-content: center; }
        }
    </style>
</head>
<body>
    <?php include '_sidebar.php'; ?>
    
    <main class="main">
        <div class="profile-card">
            <?= $flash ?>
            
            <div class="header">
                <img src="<?= h($photoPath) ?>" alt="<?= h($applicant['name']) ?>" class="avatar">
                <div class="header-info">
                    <h1><?= h($applicant['name']) ?></h1>
                    <div class="id-status">
                        ID: CFH-<?= str_pad((string) $id, 5, '0', STR_PAD_LEFT) ?>
                        &nbsp;|&nbsp; Status: 
                        <span class="badge badge-<?= $applicant['status'] ?>">
                            <?= $statusOptions[$applicant['status']] ?? ucfirst($applicant['status']) ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <div class="grid">
                <div class="info-item">
                    <div class="label">Father's Name</div>
                    <div class="value"><?= h($applicant['father_name'] ?? '-') ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Mother's Name</div>
                    <div class="value"><?= h($applicant['mother_name'] ?? '-') ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Phone</div>
                    <div class="value"><?= h($applicant['phone']) ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Blood Group</div>
                    <div class="value"><?= h($applicant['blood_group'] ?? '-') ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Team Category</div>
                    <div class="value"><?= h($applicant['team_category'] ?? '-') ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Division</div>
                    <div class="value"><?= h($applicant['division']) ?></div>
                </div>
                <div class="info-item">
                    <div class="label">District</div>
                    <div class="value"><?= h($applicant['district']) ?></div>
                </div>
                <div class="info-item">
                    <div class="label">Transaction ID</div>
                    <div class="value"><code><?= h($applicant['trx_id']) ?></code></div>
                </div>
                <div class="info-item">
                    <div class="label">Applied On</div>
                    <div class="value"><?= date('d M Y, H:i', strtotime($applicant['created_at'])) ?></div>
                </div>
                <div class="info-item">
                    <div class="label">IP Address</div>
                    <div class="value"><code><?= h($applicant['ip_address'] ?? '-') ?></code></div>
                </div>
            </div>
            
            <?php if ($nidFront || $nidBack): ?>
                <div class="images">
                    <?php if ($nidFront): ?>
                        <div class="doc-item">
                            <div class="label">NID Front</div>
                            <img src="<?= h($nidFront) ?>" alt="NID Front" class="doc-img">
                        </div>
                    <?php endif; ?>
                    <?php if ($nidBack): ?>
                        <div class="doc-item">
                            <div class="label">NID Back</div>
                            <img src="<?= h($nidBack) ?>" alt="NID Back" class="doc-img">
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <div class="actions">
                <form method="POST" action="action.php">
                    <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
                    <input type="hidden" name="id" value="<?= (int) $id ?>">
                    <input type="hidden" name="redirect" value="view">
                    
                    <button type="submit" name="action" value="approved" class="btn btn-success">✅ Approve</button>
                    <button type="submit" name="action" value="rejected" class="btn btn-danger">❌ Reject</button>
                </form>
                <a href="applicants.php" class="btn btn-secondary">← Back to List</a>
            </div>
        </div>
    </main>
</body>
</html>