<?php
/**
 * public/admin/logs.php
 * 
 * Audit logs with filtering and pagination.
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

use CFH\Middleware\AuthMiddleware;
use CFH\Database\AuditRepository;
use CFH\Flash;

// Require authentication
AuthMiddleware::guard('view_logs');

// Get database connection
$pdo = require dirname(__DIR__, 2) . '/config/database.php';

// Initialize repository
$auditRepo = new AuditRepository($pdo);

// Get filters
$filters = [
    'action_type' => in_array($_GET['type'] ?? '', [
        'LOGIN_SUCCESS', 'LOGIN_FAILED', 'LOGOUT', 
        'STATUS_APPROVED', 'STATUS_REJECTED', 'STATUS_PENDING',
        'SETTINGS', 'PASSWORD', 'EXPORT_CSV'
    ]) ? $_GET['type'] : '',
    'search' => isset($_GET['q']) ? trim($_GET['q']) : '',
];

// Pagination
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 30;

// Get logs
$result = $auditRepo->getLogs($filters, $page, $perPage);
$logs = $result['items'];
$total = $result['total'];
$pagination = $result['pagination'];

// Distinct actions for filter dropdown
$actions = $auditRepo->getDistinctActions();

// Flash messages
$flash = Flash::render();

// Action type colors for badges
$typeColors = [
    'LOGIN_SUCCESS' => ['bg' => '#d1fae5', 'fg' => '#065f46'],
    'LOGIN_FAILED' => ['bg' => '#fee2e2', 'fg' => '#991b1b'],
    'LOGOUT' => ['bg' => '#f1f5f9', 'fg' => '#475569'],
    'STATUS_APPROVED' => ['bg' => '#d1fae5', 'fg' => '#065f46'],
    'STATUS_REJECTED' => ['bg' => '#fee2e2', 'fg' => '#991b1b'],
    'STATUS_PENDING' => ['bg' => '#fef3c7', 'fg' => '#92400e'],
    'SETTINGS' => ['bg' => '#ede9fe', 'fg' => '#5b21b6'],
    'PASSWORD' => ['bg' => '#fce7f3', 'fg' => '#9d174d'],
    'EXPORT_CSV' => ['bg' => '#dbeafe', 'fg' => '#1e40af'],
];

$pageTitle = 'Audit Logs | CFH Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #f1f5f9;
            display: flex;
            min-height: 100vh;
        }
        :root { --sidebar-w: 280px; --primary: #10b981; }
        .main {
            margin-left: var(--sidebar-w);
            flex: 1;
            padding: 32px;
            min-height: 100vh;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 12px;
        }
        .page-header h1 {
            font-size: 28px;
            font-weight: 700;
            color: #0f172a;
        }
        .filter-bar {
            background: #fff;
            border-radius: 16px;
            padding: 16px 20px;
            margin-bottom: 24px;
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .filter-bar label {
            font-size: 13px;
            font-weight: 600;
            color: #64748b;
        }
        .filter-bar select,
        .filter-bar input {
            padding: 8px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
            color: #1e293b;
            background: #fff;
        }
        .filter-bar select:focus,
        .filter-bar input:focus {
            outline: none;
            border-color: #10b981;
        }
        .btn {
            padding: 8px 18px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-primary {
            background: #10b981;
            color: #fff;
        }
        .btn-primary:hover {
            background: #059669;
        }
        .btn-secondary {
            background: #e2e8f0;
            color: #1e293b;
        }
        .btn-secondary:hover {
            background: #cbd5e1;
        }
        .table-wrapper {
            background: #fff;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        th {
            background: #f8fafc;
            font-size: 12px;
            text-transform: uppercase;
            color: #64748b;
            letter-spacing: 0.5px;
            font-weight: 600;
        }
        .action-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 24px;
            flex-wrap: wrap;
        }
        .page-link {
            padding: 8px 16px;
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            text-decoration: none;
            color: #475569;
            font-size: 14px;
            transition: all 0.2s;
        }
        .page-link:hover {
            border-color: #10b981;
            color: #10b981;
        }
        .page-link.active {
            background: #10b981;
            color: #fff;
            border-color: #10b981;
        }
        .page-link.disabled {
            opacity: 0.5;
            cursor: not-allowed;
            pointer-events: none;
        }
        .flash-message {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
        .flash-message.success {
            background: #d1fae5;
            border: 1px solid #a7f3d0;
            color: #065f46;
        }
        .flash-message.error {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #991b1b;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #94a3b8;
        }
        .empty-state h3 { font-size: 18px; margin-bottom: 8px; color: #475569; }
        @media (max-width: 768px) {
            .main { margin-left: 0; padding: 16px; }
            .page-header h1 { font-size: 22px; }
            .filter-bar { flex-direction: column; align-items: stretch; }
            .filter-bar select { width: 100%; }
            table { font-size: 13px; }
            th, td { padding: 8px 10px; }
        }
    </style>
</head>
<body>
    <?php include '_sidebar.php'; ?>
    
    <main class="main">
        <div class="page-header">
            <h1>📋 Audit Logs</h1>
        </div>
        
        <?= $flash ?>
        
        <div class="filter-bar">
            <label for="type">Action Type:</label>
            <select id="type" name="type" onchange="this.form.submit()">
                <option value="">All</option>
                <?php foreach ($actions as $action): ?>
                    <option value="<?= h($action) ?>" <?= $filters['action_type'] === $action ? 'selected' : '' ?>>
                        <?= h($action) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            
            <label for="q">Search:</label>
            <input type="text" id="q" name="q" placeholder="IP or description" value="<?= h($filters['search']) ?>">
            
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="logs.php" class="btn btn-secondary">Reset</a>
        </div>
        
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Admin</th>
                        <th>Action</th>
                        <th>Description</th>
                        <th>IP</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr>
                            <td colspan="6">
                                <div class="empty-state">
                                    <h3>No logs found</h3>
                                    <p>Try adjusting your filters.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: foreach ($logs as $log): ?>
                        <tr>
                            <td><?= (int) $log['id'] ?></td>
                            <td><?= h($log['username'] ?? 'System') ?></td>
                            <td>
                                <?php
                                $type = $log['action_type'];
                                $colors = $typeColors[$type] ?? ['bg' => '#f1f5f9', 'fg' => '#475569'];
                                ?>
                                <span class="action-badge" style="background:<?= $colors['bg'] ?>;color:<?= $colors['fg'] ?>;">
                                    <?= h($type) ?>
                                </span>
                            </td>
                            <td><?= h(mb_substr($log['description'] ?? '', 0, 80)) ?></td>
                            <td><?= h($log['ip_address'] ?? '-') ?></td>
                            <td><?= date('d M Y, H:i', strtotime($log['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        
        <?php if ($pagination['total_pages'] > 1): ?>
            <div class="pagination">
                <?php if ($pagination['has_prev']): ?>
                    <a href="?<?= http_build_query(array_merge($_GET, ['page' => $pagination['prev']])) ?>" class="page-link">← Previous</a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                    <?php if ($i === $pagination['current']): ?>
                        <span class="page-link active"><?= $i ?></span>
                    <?php elseif ($i <= 5 || $i > $pagination['total_pages'] - 5 || abs($i - $pagination['current']) <= 2): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" class="page-link"><?= $i ?></a>
                    <?php elseif ($i === 6 || $i === $pagination['total_pages'] - 5): ?>
                        <span class="page-link disabled">…</span>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($pagination['has_next']): ?>
                    <a href="?<?= http_build_query(array_merge($_GET, ['page' => $pagination['next']])) ?>" class="page-link">Next →</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </main>
</body>
</html>