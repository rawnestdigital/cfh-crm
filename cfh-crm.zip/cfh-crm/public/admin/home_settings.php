<?php
/**
 * public/admin/home_settings.php
 * 
 * Homepage content management.
 * Full CRUD for all homepage sections.
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

use CFH\Middleware\AuthMiddleware;
use CFH\Database\HomeContentRepository;
use CFH\Database\AuditRepository;
use CFH\Flash;

// Require authentication with settings permission
AuthMiddleware::guard('manage_settings');

// Get database connection
$pdo = require dirname(__DIR__, 2) . '/config/database.php';

// Initialize repositories
$homeRepo = new HomeContentRepository($pdo);
$auditRepo = new AuditRepository($pdo);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        csrf_verify();
        
        $action = $_POST['action'] ?? '';
        $adminId = (int) $_SESSION['admin_id'];
        
        switch ($action) {
            case 'update_hero':
                $homeRepo->updateHero([
                    'title' => trim($_POST['title'] ?? ''),
                    'subtitle' => trim($_POST['subtitle'] ?? ''),
                    'description' => trim($_POST['description'] ?? ''),
                    'button_text' => trim($_POST['button_text'] ?? ''),
                    'button_link' => trim($_POST['button_link'] ?? ''),
                ]);
                $auditRepo->log($adminId, 'SETTINGS', 'Hero section updated');
                Flash::set('success', 'Hero section updated successfully.');
                break;
                
            case 'add_mission':
                $homeRepo->addMission([
                    'title' => trim($_POST['title'] ?? ''),
                    'description' => trim($_POST['description'] ?? ''),
                    'icon' => trim($_POST['icon'] ?? ''),
                    'type' => $_POST['type'] ?? 'mission',
                    'order' => (int) ($_POST['order'] ?? 1),
                ]);
                $auditRepo->log($adminId, 'SETTINGS', 'Mission item added');
                Flash::set('success', 'Mission item added successfully.');
                break;
                
            case 'update_stats':
                $stats = $_POST['stats'] ?? [];
                foreach ($stats as $id => $value) {
                    $homeRepo->updateStat((int) $id, (int) $value);
                }
                $auditRepo->log($adminId, 'SETTINGS', 'Stats updated');
                Flash::set('success', 'Stats updated successfully.');
                break;
                
            case 'add_team':
                $homeRepo->addTeamMember([
                    'name' => trim($_POST['name'] ?? ''),
                    'position' => trim($_POST['position'] ?? ''),
                    'bio' => trim($_POST['bio'] ?? ''),
                    'photo' => trim($_POST['photo'] ?? ''),
                    'facebook' => trim($_POST['facebook'] ?? ''),
                    'twitter' => trim($_POST['twitter'] ?? ''),
                    'linkedin' => trim($_POST['linkedin'] ?? ''),
                    'order' => (int) ($_POST['order'] ?? 1),
                ]);
                $auditRepo->log($adminId, 'SETTINGS', 'Team member added');
                Flash::set('success', 'Team member added successfully.');
                break;
                
            default:
                Flash::set('error', 'Unknown action.');
        }
        
    } catch (Throwable $e) {
        Flash::set('error', 'Operation failed: ' . $e->getMessage());
    }
    
    header('Location: home_settings.php');
    exit;
}

// Get all homepage content
$content = $homeRepo->getAll();

// Flash messages
$flash = Flash::render();

$pageTitle = 'Homepage Settings | CFH Admin';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Hind Siliguri', sans-serif;
            background: #f1f5f9;
            display: flex;
            min-height: 100vh;
        }
        :root { --sidebar-w: 280px; --primary: #10b981; }
        .main {
            margin-left: var(--sidebar-w);
            flex: 1;
            padding: 32px;
            min-height: 100vh;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 12px;
        }
        .page-header h1 {
            font-size: 28px;
            font-weight: 700;
            color: #0f172a;
        }
        .card {
            background: #fff;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .card h2 {
            font-size: 18px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid #e2e8f0;
        }
        .form-group {
            margin-bottom: 16px;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            font-size: 14px;
            color: #475569;
            margin-bottom: 6px;
        }
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
            color: #1e293b;
            transition: border-color 0.2s;
        }
        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #10b981;
        }
        .form-group textarea {
            min-height: 60px;
            resize: vertical;
        }
        .btn {
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary {
            background: #10b981;
            color: #fff;
        }
        .btn-primary:hover {
            background: #059669;
        }
        .btn-secondary {
            background: #e2e8f0;
            color: #1e293b;
        }
        .btn-secondary:hover {
            background: #cbd5e1;
        }
        .btn-danger {
            background: #ef4444;
            color: #fff;
        }
        .btn-danger:hover {
            background: #dc2626;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        .table th, .table td {
            padding: 10px 12px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        .table th {
            background: #f8fafc;
            font-size: 12px;
            text-transform: uppercase;
            color: #64748b;
            font-weight: 600;
        }
        .flash-message {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
        .flash-message.success {
            background: #d1fae5;
            border: 1px solid #a7f3d0;
            color: #065f46;
        }
        .flash-message.error {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #991b1b;
        }
        .flash-message.info {
            background: #dbeafe;
            border: 1px solid #bfdbfe;
            color: #1e40af;
        }
        @media (max-width: 768px) {
            .main { margin-left: 0; padding: 16px; }
            .page-header h1 { font-size: 22px; }
            .card { padding: 16px; }
        }
    </style>
</head>
<body>
    <?php include '_sidebar.php'; ?>
    
    <main class="main">
        <div class="page-header">
            <h1>🎨 Homepage Settings</h1>
        </div>
        
        <?= $flash ?>
        
        <!-- Hero Section -->
        <div class="card">
            <h2>🖼️ Hero Section</h2>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                <input type="hidden" name="action" value="update_hero">
                
                <div class="form-group">
                    <label for="hero_title">Title</label>
                    <input type="text" id="hero_title" name="title" value="<?= h($content['hero']['title'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="hero_subtitle">Subtitle</label>
                    <input type="text" id="hero_subtitle" name="subtitle" value="<?= h($content['hero']['subtitle'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="hero_description">Description</label>
                    <textarea id="hero_description" name="description"><?= h($content['hero']['description'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <label for="hero_button_text">Button Text</label>
                    <input type="text" id="hero_button_text" name="button_text" value="<?= h($content['hero']['button_text'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="hero_button_link">Button Link</label>
                    <input type="text" id="hero_button_link" name="button_link" value="<?= h($content['hero']['button_link'] ?? '') ?>">
                </div>
                <button type="submit" class="btn btn-primary">Update Hero</button>
            </form>
        </div>
        
        <!-- Missions -->
        <div class="card">
            <h2>➕ Add Mission / Vision</h2>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                <input type="hidden" name="action" value="add_mission">
                
                <div class="form-group">
                    <label for="mission_title">Title</label>
                    <input type="text" id="mission_title" name="title" required>
                </div>
                <div class="form-group">
                    <label for="mission_description">Description</label>
                    <textarea id="mission_description" name="description" required></textarea>
                </div>
                <div class="form-group">
                    <label for="mission_icon">Icon (Font Awesome class)</label>
                    <input type="text" id="mission_icon" name="icon" placeholder="fa-eye">
                </div>
                <div class="form-group">
                    <label for="mission_type">Type</label>
                    <select id="mission_type" name="type">
                        <option value="mission">Mission</option>
                        <option value="vision">Vision</option>
                        <option value="core_value">Core Value</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="mission_order">Order</label>
                    <input type="number" id="mission_order" name="order" value="1">
                </div>
                <button type="submit" class="btn btn-primary">Add Mission</button>
            </form>
            
            <div style="margin-top:20px;">
                <h3>Current Missions</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Order</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($content['missions'] as $mission): ?>
                            <tr>
                                <td><?= h($mission['title']) ?></td>
                                <td><?= h($mission['type']) ?></td>
                                <td><?= (int) $mission['order'] ?></td>
                                <td>
                                    <a href="edit_mission.php?id=<?= (int) $mission['id'] ?>" class="btn btn-secondary" style="padding:4px 12px;font-size:12px;">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Stats -->
        <div class="card">
            <h2>📊 Statistics</h2>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                <input type="hidden" name="action" value="update_stats">
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>Label</th>
                            <th>Value</th>
                            <th>Icon</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($content['stats'] as $stat): ?>
                            <tr>
                                <td><?= h($stat['label']) ?></td>
                                <td>
                                    <input type="number" name="stats[<?= (int) $stat['id'] ?>]" value="<?= (int) $stat['value'] ?>" style="width:100px;">
                                </td>
                                <td><?= h($stat['icon'] ?? '') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="submit" class="btn btn-primary">Update Stats</button>
            </form>
        </div>
        
        <!-- Quick Links to Other Sections -->
        <div class="card" style="background:#f0fdf4;border-color:#10b981;">
            <h2 style="color:#10b981;">🔗 Other Sections</h2>
            <div style="display:flex;gap:12px;flex-wrap:wrap;">
                <a href="manage_team.php" class="btn btn-primary">👥 Team Management</a>
                <a href="manage_events.php" class="btn btn-primary">📅 Event Management</a>
                <a href="manage_gallery.php" class="btn btn-primary">🖼️ Gallery Management</a>
                <a href="manage_testimonials.php" class="btn btn-primary">💬 Testimonials</a>
            </div>
        </div>
    </main>
</body>
</html>