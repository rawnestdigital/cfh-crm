<?php
/**
 * public/admin/applicants.php
 * 
 * Applicant list with keyset pagination and filtering.
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

use CFH\Middleware\AuthMiddleware;
use CFH\Database\ApplicantRepository;
use CFH\Flash;

// Require authentication
AuthMiddleware::guard('view_applicants');

// Get database connection
$pdo = require dirname(__DIR__, 2) . '/config/database.php';

// Initialize repository
$applicantRepo = new ApplicantRepository($pdo);

// Get filters from URL
$filters = [
    'status' => in_array($_GET['status'] ?? '', ['pending', 'approved', 'rejected']) ? $_GET['status'] : '',
    'division' => isset($_GET['division']) ? trim($_GET['division']) : '',
    'search' => isset($_GET['q']) ? trim($_GET['q']) : '',
];

// Get pagination parameters
$lastId = isset($_GET['last_id']) ? (int) $_GET['last_id'] : 0;
$perPage = 20;

// Get applicant list
$result = $applicantRepo->getList($filters, $lastId, $perPage);
$applicants = $result['items'];
$total = $result['total'];
$nextId = $result['next_id'];
$hasNext = $result['has_next'];

// Get BD divisions from config
$divisions = defined('BD_DIVISIONS') ? BD_DIVISIONS : [];

// Status options
$statusOptions = ['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected'];

// Flash messages
$flash = Flash::render();

$pageTitle = 'Applicants | CFH Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #f1f5f9;
            display: flex;
            min-height: 100vh;
        }
        :root { --sidebar-w: 280px; --primary: #10b981; }
        .main {
            margin-left: var(--sidebar-w);
            flex: 1;
            padding: 32px;
            min-height: 100vh;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 12px;
        }
        .page-header h1 {
            font-size: 28px;
            font-weight: 700;
            color: #0f172a;
        }
        .filter-bar {
            background: #fff;
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 24px;
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            align-items: flex-end;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .filter-group {
            flex: 1;
            min-width: 150px;
        }
        .filter-group label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            color: #64748b;
            margin-bottom: 4px;
        }
        .filter-group input,
        .filter-group select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
            color: #1e293b;
            background: #fff;
            transition: border-color 0.2s;
        }
        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #10b981;
        }
        .btn {
            padding: 10px 22px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-primary {
            background: #10b981;
            color: #fff;
        }
        .btn-primary:hover {
            background: #059669;
        }
        .btn-secondary {
            background: #e2e8f0;
            color: #1e293b;
        }
        .btn-secondary:hover {
            background: #cbd5e1;
        }
        .btn-export {
            background: #3b82f6;
            color: #fff;
        }
        .btn-export:hover {
            background: #2563eb;
        }
        .table-wrapper {
            background: #fff;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        th {
            background: #f8fafc;
            font-size: 12px;
            text-transform: uppercase;
            color: #64748b;
            letter-spacing: 0.5px;
            font-weight: 600;
        }
        .badge {
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        .badge-pending { background: #fef3c7; color: #92400e; }
        .badge-approved { background: #d1fae5; color: #065f46; }
        .badge-rejected { background: #fee2e2; color: #991b1b; }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 24px;
            flex-wrap: wrap;
        }
        .page-link {
            padding: 8px 16px;
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            text-decoration: none;
            color: #475569;
            font-size: 14px;
            transition: all 0.2s;
        }
        .page-link:hover {
            border-color: #10b981;
            color: #10b981;
        }
        .page-link.active {
            background: #10b981;
            color: #fff;
            border-color: #10b981;
        }
        .page-link.disabled {
            opacity: 0.5;
            cursor: not-allowed;
            pointer-events: none;
        }
        .flash-message {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
        .flash-message.success {
            background: #d1fae5;
            border: 1px solid #a7f3d0;
            color: #065f46;
        }
        .flash-message.error {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #991b1b;
        }
        .flash-message.warning {
            background: #fef3c7;
            border: 1px solid #fde68a;
            color: #92400e;
        }
        .flash-message.info {
            background: #dbeafe;
            border: 1px solid #bfdbfe;
            color: #1e40af;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #94a3b8;
        }
        .empty-state h3 { font-size: 18px; margin-bottom: 8px; color: #475569; }
        .view-link { color: #10b981; text-decoration: none; font-weight: 500; }
        .view-link:hover { text-decoration: underline; }
        code { background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-size: 12px; }
        
        @media (max-width: 768px) {
            .main { margin-left: 0; padding: 16px; }
            .filter-bar { flex-direction: column; }
            .filter-group { width: 100%; min-width: 0; }
            .page-header h1 { font-size: 22px; }
            table { font-size: 14px; }
            th, td { padding: 8px 10px; }
            .btn { padding: 8px 16px; font-size: 13px; }
        }
    </style>
</head>
<body>
    <?php include '_sidebar.php'; ?>
    
    <main class="main">
        <div class="page-header">
            <h1>👥 Applicants</h1>
            <div>
                <a href="export.php?<?= http_build_query(array_merge($filters, ['csrf_token' => csrf_token()])) ?>" class="btn btn-export">📥 Export CSV</a>
            </div>
        </div>
        
        <?= $flash ?>
        
        <form class="filter-bar" method="GET">
            <div class="filter-group">
                <label for="q">Search</label>
                <input type="text" id="q" name="q" placeholder="Name, phone or TrxID" value="<?= h($filters['search']) ?>">
            </div>
            <div class="filter-group">
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="">All status</option>
                    <?php foreach ($statusOptions as $value => $label): ?>
                        <option value="<?= $value ?>" <?= $filters['status'] === $value ? 'selected' : '' ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="filter-group">
                <label for="division">Division</label>
                <select id="division" name="division">
                    <option value="">All divisions</option>
                    <?php foreach (array_keys($divisions) as $div): ?>
                        <option value="<?= h($div) ?>" <?= $filters['division'] === $div ? 'selected' : '' ?>><?= h($div) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">🔍 Filter</button>
            <a href="applicants.php" class="btn btn-secondary">Reset</a>
        </form>
        
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Division</th>
                        <th>District</th>
                        <th>TrxID</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($applicants)): ?>
                        <tr>
                            <td colspan="9">
                                <div class="empty-state">
                                    <h3>No applicants found</h3>
                                    <p>Try adjusting your filters or search terms.</p>
                                </div>
                            </td>
                        </tr>
                    <?php else: foreach ($applicants as $r): ?>
                        <tr>
                            <td><?= (int) $r['id'] ?></td>
                            <td><strong><?= h($r['name']) ?></strong></td>
                            <td><?= h($r['phone']) ?></td>
                            <td><?= h($r['division']) ?></td>
                            <td><?= h($r['district']) ?></td>
                            <td><code><?= h($r['trx_id']) ?></code></td>
                            <td><span class="badge badge-<?= $r['status'] ?>"><?= $statusOptions[$r['status']] ?? ucfirst($r['status']) ?></span></td>
                            <td><?= date('d M Y', strtotime($r['created_at'])) ?></td>
                            <td><a href="view.php?id=<?= (int) $r['id'] ?>" class="view-link">View</a></td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="pagination">
            <?php if ($lastId > 0): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['last_id' => 0])) ?>" class="page-link">← First</a>
                <a href="?<?= http_build_query(array_merge($_GET, ['last_id' => $lastId - $perPage])) ?>" class="page-link">← Previous</a>
            <?php endif; ?>
            
            <?php if ($hasNext): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['last_id' => $nextId])) ?>" class="page-link">Next →</a>
            <?php endif; ?>
            
            <span class="page-link disabled">Page <?= $lastId > 0 ? ceil($lastId / $perPage) + 1 : 1 ?></span>
        </div>
    </main>
</body>
</html>