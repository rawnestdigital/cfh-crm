<?php
require_once __DIR__ . '/../bootstrap.php';
auth_guard();
require_permission('manage_settings');
$id = (int)($_GET['id'] ?? 0);
if (!$id) redirect('manage_testimonials.php');
$pdo = db();
$stmt = $pdo->prepare("SELECT * FROM cfh_home_testimonials WHERE id = ?");
$stmt->execute([$id]);
$testimonial = $stmt->fetch();
if (!$testimonial) redirect('manage_testimonials.php');
$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $name = $_POST['name'] ?? '';
    $position = $_POST['position'] ?? '';
    $message = $_POST['message'] ?? '';
    $rating = (int)($_POST['rating'] ?? 5);
    $order = (int)($_POST['order'] ?? 1);
    $photo = $testimonial['photo'];
    if (!empty($_FILES['photo']['name'])) {
        $upload = uploadFile($_FILES['photo'], 'testimonials');
        if ($upload['success']) $photo = $upload['filename'];
        else $error = $upload['error'];
    }
    if (empty($error)) {
        $stmt = $pdo->prepare("UPDATE cfh_home_testimonials SET name=?, position=?, message=?, rating=?, photo=?, `order`=? WHERE id=?");
        $stmt->execute([$name, $position, $message, $rating, $photo, $order, $id]);
        $success = 'মতামত আপডেট করা হয়েছে।';
        // refresh
        $stmt = $pdo->prepare("SELECT * FROM cfh_home_testimonials WHERE id = ?");
        $stmt->execute([$id]);
        $testimonial = $stmt->fetch();
    }
}
function uploadFile($file, $folder) { /* same */ }
?>
<!DOCTYPE html>
<html lang="bn">
<head><meta charset="UTF-8"><title>মতামত এডিট | CFH</title><style>/* same styles */</style></head>
<body><?php include '_sidebar.php'; ?><main class="main"><h1>✏️ মতামত এডিট</h1>
<?php if($success): ?><div class="alert alert-success">✅ <?=h($success)?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-error">⚠️ <?=h($error)?></div><?php endif; ?>
<div class="card">
<form method="POST" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=csrf_token()?>">
<div class="form-group"><label>নাম *</label><input type="text" name="name" value="<?=h($testimonial['name'])?>" required></div>
<div class="form-group"><label>পদবি</label><input type="text" name="position" value="<?=h($testimonial['position'])?>"></div>
<div class="form-group"><label>মতামত *</label><textarea name="message" rows="3" required><?=h($testimonial['message'])?></textarea></div>
<div class="form-group"><label>রেটিং</label><select name="rating"><?php for($i=5;$i>=1;$i--): ?><option value="<?=$i?>" <?=$testimonial['rating']==$i?'selected':''?>><?=str_repeat('⭐',$i)?></option><?php endfor; ?></select></div>
<div class="form-group"><label>বর্তমান ছবি</label><br><?php if($testimonial['photo']): ?><img src="../storage/uploads/<?=h($testimonial['photo'])?>" width="60" height="60" style="border-radius:50%"><?php endif; ?></div>
<div class="form-group"><label>নতুন ছবি</label><input type="file" name="photo" accept="image/*"></div>
<div class="form-group"><label>অর্ডার</label><input type="number" name="order" value="<?=$testimonial['order']?>"></div>
<button type="submit" class="btn">আপডেট করুন</button>
<a href="manage_testimonials.php" class="btn" style="background:#64748b">বাতিল</a>
</form></div></main>
<script>function toggleSidebar(){var s=document.getElementById('sidebar'),o=document.getElementById('sidebarOverlay');if(s)s.classList.toggle('open');if(o)o.classList.toggle('show')}</script>
</body></html>