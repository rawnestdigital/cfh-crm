<?php
require_once __DIR__ . '/../bootstrap.php';
auth_guard();
require_permission('manage_settings');
$activePage = 'settings';
$pdo = db();
$error = $success = '';

// Delete
if (isset($_GET['delete'])) {
    csrf_verify($_GET['csrf_token'] ?? '');
    $stmt = $pdo->prepare("DELETE FROM cfh_home_events WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    $success = 'ইভেন্ট মুছে ফেলা হয়েছে।';
}

// Add/Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id = (int)($_POST['id'] ?? 0);
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $date = $_POST['date'] ?? null;
    $location = $_POST['location'] ?? '';
    $type = $_POST['type'] ?? '';
    $order = (int)($_POST['order'] ?? 1);
    
    $image = null;
    if (!empty($_FILES['image']['name'])) {
        $upload = uploadFile($_FILES['image'], 'events');
        if ($upload['success']) $image = $upload['filename'];
        else $error = $upload['error'];
    }
    
    if (empty($error)) {
        if ($id > 0) {
            if ($image) {
                $stmt = $pdo->prepare("UPDATE cfh_home_events SET title=?, description=?, date=?, location=?, type=?, image=?, `order`=? WHERE id=?");
                $stmt->execute([$title, $description, $date, $location, $type, $image, $order, $id]);
            } else {
                $stmt = $pdo->prepare("UPDATE cfh_home_events SET title=?, description=?, date=?, location=?, type=?, `order`=? WHERE id=?");
                $stmt->execute([$title, $description, $date, $location, $type, $order, $id]);
            }
            $success = 'ইভেন্ট আপডেট করা হয়েছে।';
        } else {
            $stmt = $pdo->prepare("INSERT INTO cfh_home_events (title, description, date, location, type, image, `order`, is_active) VALUES (?,?,?,?,?,?,?,1)");
            $stmt->execute([$title, $description, $date, $location, $type, $image, $order]);
            $success = 'নতুন ইভেন্ট যোগ করা হয়েছে।';
        }
    }
}

$events = $pdo->query("SELECT * FROM cfh_home_events ORDER BY `order`")->fetchAll();

function uploadFile($file, $folder) {
    if ($file['error'] !== UPLOAD_ERR_OK) return ['success'=>false,'error'=>'Upload failed'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','webp'])) return ['success'=>false,'error'=>'Invalid file type'];
    $filename = uniqid().'.'.$ext;
    $dir = dirname(__DIR__).'/storage/uploads/'.$folder;
    if (!is_dir($dir)) mkdir($dir,0755,true);
    if (move_uploaded_file($file['tmp_name'], $dir.'/'.$filename))
        return ['success'=>true,'filename'=>$folder.'/'.$filename];
    return ['success'=>false,'error'=>'Move failed'];
}
?>
<!DOCTYPE html>
<html lang="bn">
<head><meta charset="UTF-8"><title>ইভেন্ট ম্যানেজমেন্ট | CFH</title><link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet"><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Hind Siliguri',sans-serif;background:#f1f5f9;display:flex}:root{--sidebar-w:260px}.main{margin-left:var(--sidebar-w);flex:1;padding:32px}.card{background:#fff;border-radius:16px;padding:24px;margin-bottom:24px}.form-group{margin-bottom:16px}.form-group label{display:block;font-weight:600;margin-bottom:6px}.form-group input,.form-group textarea,.form-group select{width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:8px}.btn{padding:10px 20px;background:#10b981;color:#fff;border:none;border-radius:8px;cursor:pointer}.btn-danger{background:#ef4444}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:12px;text-align:left;border-bottom:1px solid #e2e8f0}.alert{padding:12px;border-radius:8px;margin-bottom:20px}.alert-success{background:#d1fae5;color:#065f46}.alert-error{background:#fee2e2;color:#991b1b}@media(max-width:768px){.main{margin-left:0;padding:16px}}</style></head>
<body><?php include '_sidebar.php'; ?><main class="main"><h1>📅 ইভেন্ট ম্যানেজমেন্ট</h1>
<?php if($success): ?><div class="alert alert-success">✅ <?=h($success)?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-error">⚠️ <?=h($error)?></div><?php endif; ?>

<div class="card"><h2>➕ নতুন ইভেন্ট যোগ করুন</h2>
<form method="POST" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=csrf_token()?>">
<div class="form-group"><label>শিরোনাম *</label><input type="text" name="title" required></div>
<div class="form-group"><label>বিবরণ</label><textarea name="description" rows="3"></textarea></div>
<div class="form-group"><label>তারিখ</label><input type="date" name="date"></div>
<div class="form-group"><label>স্থান</label><input type="text" name="location"></div>
<div class="form-group"><label>ধরন</label><input type="text" name="type" placeholder="যেমন: রক্তদান, শিক্ষা সহায়তা"></div>
<div class="form-group"><label>ছবি</label><input type="file" name="image" accept="image/*"></div>
<div class="form-group"><label>অর্ডার</label><input type="number" name="order" value="1"></div>
<button type="submit" class="btn">যোগ করুন</button></form></div>

<div class="card"><h2>📋 বর্তমান ইভেন্টসমূহ</h2>
<table class="table"><thead><th>ছবি</th><th>শিরোনাম</th><th>তারিখ</th><th>স্থান</th><th>অর্ডার</th><th>অ্যাকশন</th></thead><tbody>
<?php foreach($events as $e): ?>
<tr>
<td><?= $e['image'] ? '<img src="../storage/uploads/'.h($e['image']).'" width="50" height="50" style="object-fit:cover;border-radius:8px">' : '—' ?></td>
<td><?=h($e['title'])?></td>
<td><?= $e['date'] ? date('d M Y', strtotime($e['date'])) : '—' ?></td>
<td><?=h($e['location'])?></td>
<td><?=$e['order']?></td>
<td>
<a href="edit_event.php?id=<?=$e['id']?>" class="btn" style="background:#3b82f6;padding:5px 12px">✏️ এডিট</a>
<a href="?delete=<?=$e['id']?>&csrf_token=<?=urlencode(csrf_token())?>" class="btn btn-danger" style="background:#ef4444;padding:5px 12px" onclick="return confirm('মুছে ফেলতে চান?')">🗑️ ডিলিট</a>
</td>
</tr>
<?php endforeach; ?>
</tbody></table></div></main>
<script>function toggleSidebar(){var s=document.getElementById('sidebar'),o=document.getElementById('sidebarOverlay');if(s)s.classList.toggle('open');if(o)o.classList.toggle('show')}</script>
</body></html>