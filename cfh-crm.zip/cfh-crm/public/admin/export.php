<?php
/**
 * public/admin/export.php
 * 
 * CSV export with streaming.
 * POST only for security.
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

use CFH\Middleware\AuthMiddleware;
use CFH\Database\ApplicantRepository;
use CFH\Services\ExportService;
use CFH\Flash;

// Require authentication with export permission
AuthMiddleware::guard('export_data');

// Only POST allowed
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Flash::set('error', 'Invalid request method.');
    header('Location: applicants.php');
    exit;
}

// CSRF verification
try {
    csrf_verify();
} catch (Throwable $e) {
    Flash::set('error', 'Security token mismatch.');
    header('Location: applicants.php');
    exit;
}

// Get filters
$filters = [
    'status' => in_array($_POST['status'] ?? '', ['pending', 'approved', 'rejected']) ? $_POST['status'] : '',
    'from_date' => isset($_POST['from']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['from']) ? $_POST['from'] : '',
    'to_date' => isset($_POST['to']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['to']) ? $_POST['to'] : '',
];

// Get database connection
$pdo = require dirname(__DIR__, 2) . '/config/database.php';

// Initialize repository and service
$applicantRepo = new ApplicantRepository($pdo);
$exportService = new ExportService($applicantRepo);

// Generate filename
$filename = 'CFH_Export_' . date('Ymd_His') . '.csv';

// Stream CSV
try {
    // Log audit
    $auditRepo = new \CFH\Database\AuditRepository($pdo);
    $auditRepo->log(
        (int) $_SESSION['admin_id'],
        'EXPORT_CSV',
        'Exported CSV with filters: ' . json_encode($filters, JSON_UNESCAPED_UNICODE)
    );
    
    $exportService->streamCsv($filters, $filename);
} catch (Throwable $e) {
    Flash::set('error', 'Export failed: ' . $e->getMessage());
    header('Location: applicants.php');
    exit;
}