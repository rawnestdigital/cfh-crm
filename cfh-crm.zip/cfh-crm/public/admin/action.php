<?php
/**
 * public/admin/action.php
 * 
 * Handle applicant status changes.
 * Uses rate limiting to prevent abuse.
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

use CFH\Middleware\AuthMiddleware;
use CFH\Database\ApplicantRepository;
use CFH\Database\AuditRepository;
use CFH\Flash;

// Require authentication with permission
AuthMiddleware::guard('manage_applicants');

// Rate limiting: 10 actions per minute per admin
$rateKey = 'action_rate_' . $_SESSION['admin_id'];
$rateLimit = 10;
$rateWindow = 60;

// Simple file-based rate limiter
$rateDir = dirname(__DIR__, 2) . '/storage/private/rate_limits';
if (!is_dir($rateDir)) {
    mkdir($rateDir, 0750, true);
}
$rateFile = $rateDir . '/' . md5($rateKey) . '.tmp';

if (file_exists($rateFile)) {
    $data = file_get_contents($rateFile);
    $count = (int) ($data ?? 0);
    $mtime = filemtime($rateFile);
    if (time() - $mtime < $rateWindow) {
        if ($count >= $rateLimit) {
            Flash::set('error', 'Too many actions. Please wait a moment.');
            header('Location: applicants.php');
            exit;
        }
        file_put_contents($rateFile, (string) ($count + 1), LOCK_EX);
    } else {
        file_put_contents($rateFile, '1', LOCK_EX);
    }
} else {
    file_put_contents($rateFile, '1', LOCK_EX);
}

// CSRF verification
try {
    csrf_verify();
} catch (Throwable $e) {
    Flash::set('error', 'Security token mismatch. Please try again.');
    header('Location: applicants.php');
    exit;
}

// Get and validate input
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$action = $_POST['action'] ?? '';

if (!$id || !in_array($action, ['approved', 'rejected', 'pending'], true)) {
    Flash::set('error', 'Invalid request.');
    header('Location: applicants.php');
    exit;
}

// Get database connection
$pdo = require dirname(__DIR__, 2) . '/config/database.php';

// Initialize repositories
$applicantRepo = new ApplicantRepository($pdo);
$auditRepo = new AuditRepository($pdo);

// Update status
try {
    $result = $applicantRepo->updateStatus($id, $action, (int) $_SESSION['admin_id']);
    
    if ($result) {
        // Log audit
        $auditRepo->log(
            (int) $_SESSION['admin_id'],
            'STATUS_' . strtoupper($action),
            "Application #{$id} changed to {$action}"
        );
        
        Flash::set('success', 'Status updated successfully.');
    } else {
        Flash::set('info', 'Status is already set to ' . $action . '.');
    }
    
} catch (Throwable $e) {
    Flash::set('error', 'Failed to update status: ' . $e->getMessage());
}

// Redirect back
$redirect = ($_POST['redirect'] ?? '') === 'view' ? "view.php?id={$id}" : 'applicants.php';
header("Location: {$redirect}");
exit;