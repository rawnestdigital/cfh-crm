<?php
/**
 * public/admin/settings.php
 * 
 * System settings management.
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

use CFH\Middleware\AuthMiddleware;
use CFH\Database\SettingRepository;
use CFH\Database\AuditRepository;
use CFH\Flash;

// Require authentication with settings permission
AuthMiddleware::guard('manage_settings');

// Get database connection
$pdo = require dirname(__DIR__, 2) . '/config/database.php';

// Initialize repositories
$settingRepo = new SettingRepository($pdo);
$auditRepo = new AuditRepository($pdo);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        csrf_verify();
        
        $auditRepo->log((int) $_SESSION['admin_id'], 'SETTINGS', 'System settings updated');
        
        // Save all settings
        $settings = [
            'org_name' => trim($_POST['org_name'] ?? ''),
            'org_email' => trim($_POST['org_email'] ?? ''),
            'org_phone' => trim($_POST['org_phone'] ?? ''),
            'org_address' => trim($_POST['org_address'] ?? ''),
            'reg_fee' => (string) max(0, (int) ($_POST['reg_fee'] ?? 0)),
            'bkash_number' => trim($_POST['bkash_number'] ?? ''),
            'applicant_limit' => (string) max(0, (int) ($_POST['applicant_limit'] ?? 0)),
            'notification_email' => trim($_POST['notification_email'] ?? ''),
            'maintenance_mode' => isset($_POST['maintenance_mode']) ? '1' : '0',
        ];
        
        foreach ($settings as $key => $value) {
            $settingRepo->set($key, $value, 'system');
        }
        
        Flash::set('success', 'Settings saved successfully.');
        
    } catch (Throwable $e) {
        Flash::set('error', 'Failed to save settings: ' . $e->getMessage());
    }
    
    header('Location: settings.php');
    exit;
}

// Get current settings
$settings = $settingRepo->getAll('system');

// Flash messages
$flash = Flash::render();

$pageTitle = 'Settings | CFH Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #f1f5f9;
            display: flex;
            min-height: 100vh;
        }
        :root { --sidebar-w: 280px; --primary: #10b981; }
        .main {
            margin-left: var(--sidebar-w);
            flex: 1;
            padding: 32px;
            min-height: 100vh;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 12px;
        }
        .page-header h1 {
            font-size: 28px;
            font-weight: 700;
            color: #0f172a;
        }
        .card {
            background: #fff;
            border-radius: 16px;
            padding: 28px;
            margin-bottom: 24px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .card h2 {
            font-size: 18px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 1px solid #e2e8f0;
        }
        .form-group {
            margin-bottom: 16px;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            font-size: 14px;
            color: #475569;
            margin-bottom: 6px;
        }
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
            color: #1e293b;
            transition: border-color 0.2s;
        }
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #10b981;
        }
        .form-group textarea {
            min-height: 60px;
            resize: vertical;
        }
        .form-group .hint {
            font-size: 12px;
            color: #94a3b8;
            margin-top: 4px;
        }
        .btn {
            padding: 10px 24px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary {
            background: #10b981;
            color: #fff;
        }
        .btn-primary:hover {
            background: #059669;
        }
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 26px;
        }
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .toggle-slider {
            position: absolute;
            inset: 0;
            background: #cbd5e1;
            border-radius: 30px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .toggle-slider:before {
            content: "";
            position: absolute;
            width: 20px;
            height: 20px;
            left: 3px;
            bottom: 3px;
            background: #fff;
            border-radius: 50%;
            transition: transform 0.3s;
        }
        .toggle-switch input:checked + .toggle-slider {
            background: #10b981;
        }
        .toggle-switch input:checked + .toggle-slider:before {
            transform: translateX(24px);
        }
        .flash-message {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
        .flash-message.success {
            background: #d1fae5;
            border: 1px solid #a7f3d0;
            color: #065f46;
        }
        .flash-message.error {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #991b1b;
        }
        @media (max-width: 768px) {
            .main { margin-left: 0; padding: 16px; }
            .page-header h1 { font-size: 22px; }
            .card { padding: 20px; }
        }
    </style>
</head>
<body>
    <?php include '_sidebar.php'; ?>
    
    <main class="main">
        <div class="page-header">
            <h1>⚙️ System Settings</h1>
        </div>
        
        <?= $flash ?>
        
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
            
            <div class="card">
                <h2>Organization Info</h2>
                <div class="form-group">
                    <label for="org_name">Organization Name</label>
                    <input type="text" id="org_name" name="org_name" value="<?= h($settings['org_name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="org_email">Email</label>
                    <input type="email" id="org_email" name="org_email" value="<?= h($settings['org_email'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="org_phone">Phone</label>
                    <input type="text" id="org_phone" name="org_phone" value="<?= h($settings['org_phone'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="org_address">Address</label>
                    <textarea id="org_address" name="org_address"><?= h($settings['org_address'] ?? '') ?></textarea>
                </div>
            </div>
            
            <div class="card">
                <h2>Payment & Registration</h2>
                <div class="form-group">
                    <label for="reg_fee">Registration Fee (BDT)</label>
                    <input type="number" id="reg_fee" name="reg_fee" value="<?= h($settings['reg_fee'] ?? '200') ?>">
                </div>
                <div class="form-group">
                    <label for="bkash_number">bKash Number</label>
                    <input type="text" id="bkash_number" name="bkash_number" value="<?= h($settings['bkash_number'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="applicant_limit">Applicant Limit (0 = unlimited)</label>
                    <input type="number" id="applicant_limit" name="applicant_limit" value="<?= h($settings['applicant_limit'] ?? '0') ?>">
                    <div class="hint">Set to 0 to allow unlimited applications.</div>
                </div>
                <div class="form-group">
                    <label for="notification_email">Notification Email</label>
                    <input type="email" id="notification_email" name="notification_email" value="<?= h($settings['notification_email'] ?? '') ?>">
                </div>
            </div>
            
            <div class="card">
                <h2>System Control</h2>
                <div class="form-group">
                    <label>Maintenance Mode</label>
                    <label class="toggle-switch">
                        <input type="checkbox" name="maintenance_mode" value="1" <?= ($settings['maintenance_mode'] ?? '0') === '1' ? 'checked' : '' ?>>
                        <span class="toggle-slider"></span>
                    </label>
                    <div class="hint">When enabled, only admins can access the site.</div>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary">💾 Save Settings</button>
        </form>
    </main>
</body>
</html>