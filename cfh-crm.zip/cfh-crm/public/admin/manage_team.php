<?php
require_once __DIR__ . '/../bootstrap.php';
auth_guard();
require_permission('manage_settings');
$activePage = 'settings';

$pdo = db();
$error = '';
$success = '';

// Handle delete
if (isset($_GET['delete'])) {
    csrf_verify($_GET['csrf_token'] ?? '');
    $stmt = $pdo->prepare("DELETE FROM cfh_home_team WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    $success = 'সদস্য মুছে ফেলা হয়েছে।';
}

// Handle add/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id = (int)($_POST['id'] ?? 0);
    $name = $_POST['name'] ?? '';
    $position = $_POST['position'] ?? '';
    $bio = $_POST['bio'] ?? '';
    $facebook = $_POST['facebook'] ?? '';
    $twitter = $_POST['twitter'] ?? '';
    $linkedin = $_POST['linkedin'] ?? '';
    $order = (int)($_POST['order'] ?? 1);
    
    // Handle photo upload
    $photo = null;
    if (!empty($_FILES['photo']['name'])) {
        $upload = uploadFile($_FILES['photo'], 'team');
        if ($upload['success']) {
            $photo = $upload['filename'];
        } else {
            $error = $upload['error'];
        }
    }
    
    if (empty($error)) {
        if ($id > 0) {
            if ($photo) {
                $stmt = $pdo->prepare("UPDATE cfh_home_team SET name=?, position=?, bio=?, photo=?, facebook=?, twitter=?, linkedin=?, `order`=? WHERE id=?");
                $stmt->execute([$name, $position, $bio, $photo, $facebook, $twitter, $linkedin, $order, $id]);
            } else {
                $stmt = $pdo->prepare("UPDATE cfh_home_team SET name=?, position=?, bio=?, facebook=?, twitter=?, linkedin=?, `order`=? WHERE id=?");
                $stmt->execute([$name, $position, $bio, $facebook, $twitter, $linkedin, $order, $id]);
            }
            $success = 'সদস্য আপডেট করা হয়েছে।';
        } else {
            $stmt = $pdo->prepare("INSERT INTO cfh_home_team (name, position, bio, photo, facebook, twitter, linkedin, `order`, is_active) VALUES (?,?,?,?,?,?,?,?,1)");
            $stmt->execute([$name, $position, $bio, $photo, $facebook, $twitter, $linkedin, $order]);
            $success = 'নতুন সদস্য যোগ করা হয়েছে।';
        }
    }
}

// Fetch all team members
$team = $pdo->query("SELECT * FROM cfh_home_team ORDER BY `order`")->fetchAll();

function uploadFile($file, $folder) {
    if ($file['error'] !== UPLOAD_ERR_OK) return ['success' => false, 'error' => 'Upload failed'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','webp'])) return ['success' => false, 'error' => 'Invalid file type'];
    $filename = uniqid() . '.' . $ext;
    $uploadDir = dirname(__DIR__) . '/storage/uploads/' . $folder;
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    if (move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $filename)) {
        return ['success' => true, 'filename' => $folder . '/' . $filename];
    }
    return ['success' => false, 'error' => 'Move failed'];
}
?>
<!DOCTYPE html>
<html lang="bn">
<head><meta charset="UTF-8"><title>টিম ম্যানেজমেন্ট | CFH</title><link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet"><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Hind Siliguri',sans-serif;background:#f1f5f9;display:flex}:root{--sidebar-w:260px}.main{margin-left:var(--sidebar-w);flex:1;padding:32px}.card{background:#fff;border-radius:16px;padding:24px;margin-bottom:24px}.card h2{margin-bottom:20px}.form-group{margin-bottom:16px}.form-group label{display:block;font-weight:600;margin-bottom:6px}.form-group input,.form-group textarea{width:100%;padding:10px;border:1px solid #e2e8f0;border-radius:8px}.btn{padding:10px 20px;background:#10b981;color:#fff;border:none;border-radius:8px;cursor:pointer}.btn-danger{background:#ef4444}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:12px;text-align:left;border-bottom:1px solid #e2e8f0}.alert{padding:12px;border-radius:8px;margin-bottom:20px}.alert-success{background:#d1fae5;color:#065f46}.alert-error{background:#fee2e2;color:#991b1b}@media(max-width:768px){.main{margin-left:0;padding:16px}}</style></head>
<body><?php include '_sidebar.php'; ?><main class="main"><h1>👥 টিম মেম্বার ম্যানেজমেন্ট</h1>
<?php if($success): ?><div class="alert alert-success">✅ <?=h($success)?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-error">⚠️ <?=h($error)?></div><?php endif; ?>

<div class="card"><h2>➕ নতুন সদস্য যোগ করুন</h2>
<form method="POST" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=csrf_token()?>">
<div class="form-group"><label>নাম *</label><input type="text" name="name" required></div>
<div class="form-group"><label>পদবি</label><input type="text" name="position"></div>
<div class="form-group"><label>বায়ো</label><textarea name="bio" rows="3"></textarea></div>
<div class="form-group"><label>ছবি</label><input type="file" name="photo" accept="image/*"></div>
<div class="form-group"><label>ফেসবুক</label><input type="url" name="facebook"></div>
<div class="form-group"><label>টুইটার</label><input type="url" name="twitter"></div>
<div class="form-group"><label>লিংকডইন</label><input type="url" name="linkedin"></div>
<div class="form-group"><label>অর্ডার</label><input type="number" name="order" value="1"></div>
<button type="submit" class="btn">যোগ করুন</button></form></div>

<div class="card"><h2>📋 বর্তমান সদস্যবৃন্দ</h2>
<table class="table"><thead><th>ছবি</th><th>নাম</th><th>পদবি</th><th>অর্ডার</th><th>অ্যাকশন</th></thead><tbody>
<?php foreach($team as $m): ?>
<tr><td><?= $m['photo'] ? '<img src="../storage/uploads/'.h($m['photo']).'" width="50" height="50" style="object-fit:cover;border-radius:10px">' : '—' ?></td>
<td><?=h($m['name'])?></td><td><?=h($m['position'])?></td><td><?=$m['order']?></td>
<td><a href="edit_team.php?id=<?=$m['id']?>" class="btn" style="background:#3b82f6;padding:5px 12px">✏️ এডিট</a>
<a href="?delete=<?=$m['id']?>&csrf_token=<?=urlencode(csrf_token())?>" class="btn btn-danger" style="background:#ef4444;padding:5px 12px" onclick="return confirm('মুছে ফেলতে চান?')">🗑️ ডিলিট</a></td></tr>
<?php endforeach; ?>
</tbody></table></div></main>
<script>function toggleSidebar(){var s=document.getElementById('sidebar'),o=document.getElementById('sidebarOverlay');if(s)s.classList.toggle('open');if(o)o.classList.toggle('show')}</script>
</body></html>