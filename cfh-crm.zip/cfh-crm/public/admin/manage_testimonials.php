<?php
require_once __DIR__ . '/../bootstrap.php';
auth_guard();
require_permission('manage_settings');
$activePage = 'settings';
$pdo = db();
$error = $success = '';

// Delete
if (isset($_GET['delete'])) {
    csrf_verify($_GET['csrf_token'] ?? '');
    $stmt = $pdo->prepare("DELETE FROM cfh_home_testimonials WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    $success = 'মতামত মুছে ফেলা হয়েছে।';
}

// Add/Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id = (int)($_POST['id'] ?? 0);
    $name = $_POST['name'] ?? '';
    $position = $_POST['position'] ?? '';
    $message = $_POST['message'] ?? '';
    $rating = (int)($_POST['rating'] ?? 5);
    $order = (int)($_POST['order'] ?? 1);
    $photo = null;
    if (!empty($_FILES['photo']['name'])) {
        $upload = uploadFile($_FILES['photo'], 'testimonials');
        if ($upload['success']) $photo = $upload['filename'];
        else $error = $upload['error'];
    }
    if (empty($error)) {
        if ($id > 0) {
            if ($photo) {
                $stmt = $pdo->prepare("UPDATE cfh_home_testimonials SET name=?, position=?, message=?, rating=?, photo=?, `order`=? WHERE id=?");
                $stmt->execute([$name, $position, $message, $rating, $photo, $order, $id]);
            } else {
                $stmt = $pdo->prepare("UPDATE cfh_home_testimonials SET name=?, position=?, message=?, rating=?, `order`=? WHERE id=?");
                $stmt->execute([$name, $position, $message, $rating, $order, $id]);
            }
            $success = 'মতামত আপডেট করা হয়েছে।';
        } else {
            $stmt = $pdo->prepare("INSERT INTO cfh_home_testimonials (name, position, message, rating, photo, `order`, is_active) VALUES (?,?,?,?,?,?,1)");
            $stmt->execute([$name, $position, $message, $rating, $photo, $order]);
            $success = 'নতুন মতামত যোগ করা হয়েছে।';
        }
    }
}

$testimonials = $pdo->query("SELECT * FROM cfh_home_testimonials ORDER BY `order`")->fetchAll();

function uploadFile($file, $folder) { /* same as before */ }
?>
<!DOCTYPE html>
<html lang="bn">
<head><meta charset="UTF-8"><title>মতামত ম্যানেজমেন্ট | CFH</title><link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet"><style>/* same base */</style></head>
<body><?php include '_sidebar.php'; ?><main class="main"><h1>💬 টেস্টিমোনিয়াল ম্যানেজমেন্ট</h1>
<?php if($success): ?><div class="alert alert-success">✅ <?=h($success)?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-error">⚠️ <?=h($error)?></div><?php endif; ?>

<div class="card"><h2>➕ নতুন মতামত যোগ করুন</h2>
<form method="POST" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=csrf_token()?>">
<div class="form-group"><label>নাম *</label><input type="text" name="name" required></div>
<div class="form-group"><label>পদবি</label><input type="text" name="position"></div>
<div class="form-group"><label>মতামত *</label><textarea name="message" rows="3" required></textarea></div>
<div class="form-group"><label>রেটিং (১-৫)</label><select name="rating"><option value="5">★★★★★</option><option value="4">★★★★☆</option><option value="3">★★★☆☆</option><option value="2">★★☆☆☆</option><option value="1">★☆☆☆☆</option></select></div>
<div class="form-group"><label>ছবি</label><input type="file" name="photo" accept="image/*"></div>
<div class="form-group"><label>অর্ডার</label><input type="number" name="order" value="1"></div>
<button type="submit" class="btn">যোগ করুন</button></form></div>

<div class="card"><h2>📋 বর্তমান মতামতসমূহ</h2>
<table class="table"><thead><th>ছবি</th><th>নাম</th><th>মতামত</th><th>রেটিং</th><th>অর্ডার</th><th>অ্যাকশন</th></thead><tbody>
<?php foreach($testimonials as $t): ?>
<tr>
<td><?= $t['photo'] ? '<img src="../storage/uploads/'.h($t['photo']).'" width="40" height="40" style="border-radius:50%;object-fit:cover">' : '—' ?></td>
<td><?=h($t['name'])?><br><small><?=h($t['position'])?></small></td>
<td><?=h(mb_substr($t['message'],0,50))?>...</td>
<td><?=str_repeat('⭐', $t['rating'])?></td>
<td><?=$t['order']?></td>
<td>
<a href="edit_testimonial.php?id=<?=$t['id']?>" class="btn" style="background:#3b82f6;padding:5px 12px">✏️ এডিট</a>
<a href="?delete=<?=$t['id']?>&csrf_token=<?=urlencode(csrf_token())?>" class="btn btn-danger" style="background:#ef4444;padding:5px 12px" onclick="return confirm('মুছতে চান?')">🗑️ ডিলিট</a>
</td>
</tr>
<?php endforeach; ?>
</tbody></table></div></main>
<script>function toggleSidebar(){var s=document.getElementById('sidebar'),o=document.getElementById('sidebarOverlay');if(s)s.classList.toggle('open');if(o)o.classList.toggle('show')}</script>
</body></html>