<?php
/**
 * public/submit_registration.php
 * 
 * Registration submission handler with file upload and validation.
 */

declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

use CFH\Database\ApplicantRepository;
use CFH\Database\SettingRepository;
use CFH\Database\AuditRepository;
use CFH\Flash;

// CSRF verification
try {
    csrf_verify();
} catch (Throwable $e) {
    Flash::set('error', 'Security token mismatch. Please try again.');
    header('Location: register.php');
    exit;
}

// Validate inputs
$name = trim($_POST['name'] ?? '');
$father = trim($_POST['father_name'] ?? '');
$mother = trim($_POST['mother_name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$blood = trim($_POST['blood_group'] ?? '');
$team = trim($_POST['team_category'] ?? '');
$division = trim($_POST['division'] ?? '');
$district = trim($_POST['district'] ?? '');
$trxId = trim($_POST['trx_id'] ?? '');

// Validation
$errors = [];

if (empty($name)) {
    $errors[] = 'Name is required.';
}

if (empty($father)) {
    $errors[] = 'Father\'s name is required.';
}

if (empty($mother)) {
    $errors[] = 'Mother\'s name is required.';
}

if (!preg_match('/^01[3-9]\d{8}$/', $phone)) {
    $errors[] = 'Invalid phone number. Please use a valid Bangladeshi number (01XXXXXXXXX).';
}

if (!preg_match('/^[A-Za-z0-9]{6,30}$/', $trxId)) {
    $errors[] = 'Invalid Transaction ID. It should be 6-30 alphanumeric characters.';
}

// File upload validation
if (empty($_FILES['photo']['name'])) {
    $errors[] = 'Photo is required.';
}

if (!empty($errors)) {
    foreach ($errors as $error) {
        Flash::set('error', $error);
    }
    header('Location: register.php');
    exit;
}

// Upload files
$uploadDir = dirname(__DIR__) . '/storage/public/uploads';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Helper function for upload
function uploadFile(array $file, string $type): ?string {
    if (empty($file['name'])) {
        return null;
    }
    
    // Security checks
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('File upload failed.');
    }
    
    if ($file['size'] > 2 * 1024 * 1024) {
        throw new RuntimeException('File too large (max 2MB).');
    }
    
    // MIME validation
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    $allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (!in_array($mime, $allowed, true)) {
        throw new RuntimeException('Invalid file type. Allowed: JPG, PNG, WEBP.');
    }
    
    // Extension validation
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowedExt = ['jpg', 'jpeg', 'png', 'webp'];
    if (!in_array($ext, $allowedExt, true)) {
        throw new RuntimeException('Invalid file extension.');
    }
    
    // Generate secure filename
    $subDir = date('Y/m/d');
    $targetDir = dirname(__DIR__) . '/storage/public/uploads/' . $type . '/' . $subDir;
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }
    
    $filename = bin2hex(random_bytes(16)) . '.' . $ext;
    $destination = $targetDir . '/' . $filename;
    
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new RuntimeException('Failed to save file.');
    }
    
    return $type . '/' . $subDir . '/' . $filename;
}

try {
    $pdo = require dirname(__DIR__) . '/config/database.php';
    
    // Start transaction
    $pdo->beginTransaction();
    
    // Upload files
    $photoPath = uploadFile($_FILES['photo'], 'applicants');
    
    $nidFront = null;
    if (!empty($_FILES['nid_f']['name'])) {
        $nidFront = uploadFile($_FILES['nid_f'], 'applicants');
    }
    
    $nidBack = null;
    if (!empty($_FILES['nid_b']['name'])) {
        $nidBack = uploadFile($_FILES['nid_b'], 'applicants');
    }
    
    // Get IP address
    $ip = client_ip();
    $ipHash = hash('sha256', $ip);
    
    // Insert into database
    $stmt = $pdo->prepare("
        INSERT INTO cfh_applicants 
        (name, father_name, mother_name, phone, blood_group, team_category, 
         division, district, photo, nid_front, nid_back, trx_id, ip_address, status)
        VALUES 
        (:name, :father, :mother, :phone, :blood, :team, 
         :division, :district, :photo, :nid_front, :nid_back, :trx_id, :ip, 'pending')
    ");
    
    $stmt->execute([
        ':name' => $name,
        ':father' => $father,
        ':mother' => $mother,
        ':phone' => $phone,
        ':blood' => $blood,
        ':team' => $team,
        ':division' => $division,
        ':district' => $district,
        ':photo' => $photoPath,
        ':nid_front' => $nidFront,
        ':nid_back' => $nidBack,
        ':trx_id' => $trxId,
        ':ip' => $ipHash,
    ]);
    
    $id = (int) $pdo->lastInsertId();
    
    // Commit transaction
    $pdo->commit();
    
    // Log audit
    $auditRepo = new AuditRepository($pdo);
    $auditRepo->log(null, 'REGISTRATION', "New registration #{$id}: {$name}");
    
    // Send email notification to admin
    $settingRepo = new SettingRepository($pdo);
    $adminEmail = $settingRepo->get('notification_email');
    if ($adminEmail) {
        $subject = 'নতুন নিবন্ধন - CFH';
        $message = "একজন নতুন সদস্য নিবন্ধন করেছেন:\n\n";
        $message .= "নাম: {$name}\n";
        $message .= "ফোন: {$phone}\n";
        $message .= "রেজিস্ট্রেশন আইডি: CFH-" . str_pad((string) $id, 5, '0', STR_PAD_LEFT) . "\n";
        $message .= "অ্যাডমিন প্যানেল: " . (isset($_SERVER['HTTP_HOST']) ? "https://{$_SERVER['HTTP_HOST']}/admin/view.php?id={$id}" : '');
        
        // Simple mail (use proper mail library in production)
        @mail($adminEmail, $subject, $message, "From: no-reply@cfhbd.org");
    }
    
    // Redirect to success page
    Flash::set('success', 'আপনার নিবন্ধন সফল হয়েছে!');
    header("Location: success.php?id={$id}");
    exit;
    
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    error_log('[REGISTRATION ERROR] ' . $e->getMessage());
    Flash::set('error', 'আপনার আবেদন সম্পন্ন করা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।');
    header('Location: register.php');
    exit;
}