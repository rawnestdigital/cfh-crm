<?php
/**
 * public/health-check.php
 * 
 * Health check endpoint for monitoring.
 * Accessible only from localhost or with a valid token.
 */

declare(strict_types=1);

// Security: Only allow from localhost or with valid token
$allowedIps = ['127.0.0.1', '::1', 'localhost'];
$clientIp = $_SERVER['REMOTE_ADDR'] ?? '';
$token = $_GET['token'] ?? '';

$validToken = hash_equals($token, hash_hmac('sha256', 'health-check', $_ENV['APP_SECRET'] ?? 'cfh-secret-key'));

if (!in_array($clientIp, $allowedIps, true) && !$validToken) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Forbidden']);
    exit;
}

// Load bootstrap
require_once dirname(__DIR__) . '/config/bootstrap.php';

$results = [];
$status = 'ok';
$statusCode = 200;

// 1. Database connection
try {
    $pdo = require dirname(__DIR__) . '/config/database.php';
    $pdo->query("SELECT 1")->fetch();
    $results['database'] = ['status' => 'ok', 'message' => 'Connected'];
} catch (Throwable $e) {
    $status = 'error';
    $statusCode = 503;
    $results['database'] = ['status' => 'error', 'message' => $e->getMessage()];
}

// 2. Cache availability (APCu/Redis/file)
$cacheStatus = 'ok';
$cacheMsg = 'File cache (fallback)';
if (function_exists('apcu_fetch')) {
    $cacheMsg = 'APCu available';
} elseif (class_exists('Redis')) {
    try {
        $redis = new Redis();
        $redis->connect($_ENV['REDIS_HOST'] ?? '127.0.0.1', (int) ($_ENV['REDIS_PORT'] ?? 6379), 1.0);
        if (!empty($_ENV['REDIS_PASSWORD'])) {
            $redis->auth($_ENV['REDIS_PASSWORD']);
        }
        $redis->ping();
        $cacheMsg = 'Redis available';
    } catch (Throwable $e) {
        $cacheStatus = 'warning';
        $cacheMsg = 'Redis unavailable, using file cache';
    }
}
$results['cache'] = ['status' => $cacheStatus, 'message' => $cacheMsg];

// 3. Upload directory writable
$uploadDir = dirname(__DIR__) . '/storage/public/uploads';
if (is_dir($uploadDir)) {
    $testFile = $uploadDir . '/test_write.tmp';
    if (file_put_contents($testFile, 'test') !== false) {
        unlink($testFile);
        $results['uploads'] = ['status' => 'ok', 'message' => 'Writable'];
    } else {
        $status = 'error';
        $statusCode = 503;
        $results['uploads'] = ['status' => 'error', 'message' => 'Not writable'];
    }
} else {
    $status = 'error';
    $statusCode = 503;
    $results['uploads'] = ['status' => 'error', 'message' => 'Directory missing'];
}

// 4. Virus scanner availability
$clamavSocket = $_ENV['CLAMAV_SOCKET'] ?? '';
if ($clamavSocket && file_exists($clamavSocket)) {
    $results['virus_scanner'] = ['status' => 'ok', 'message' => 'ClamAV available'];
} elseif ($clamavSocket) {
    $results['virus_scanner'] = ['status' => 'warning', 'message' => 'ClamAV socket not found'];
} else {
    $results['virus_scanner'] = ['status' => 'info', 'message' => 'Virus scanning not configured'];
}

// 5. PHP extensions
$requiredExtensions = ['pdo_mysql', 'fileinfo', 'json', 'session', 'openssl', 'mbstring'];
$missing = [];
foreach ($requiredExtensions as $ext) {
    if (!extension_loaded($ext)) {
        $missing[] = $ext;
    }
}
if (empty($missing)) {
    $results['extensions'] = ['status' => 'ok', 'message' => 'All required extensions loaded'];
} else {
    $status = 'error';
    $statusCode = 503;
    $results['extensions'] = ['status' => 'error', 'message' => 'Missing extensions: ' . implode(', ', $missing)];
}

// 6. Maintenance mode
if (isset($results['database']) && $results['database']['status'] === 'ok') {
    try {
        $settingRepo = new \CFH\Database\SettingRepository($pdo);
        $maintenance = $settingRepo->get('maintenance_mode');
        if ($maintenance === '1') {
            $results['maintenance'] = ['status' => 'warning', 'message' => 'Maintenance mode active'];
        } else {
            $results['maintenance'] = ['status' => 'ok', 'message' => 'Maintenance mode off'];
        }
    } catch (Throwable $e) {
        $results['maintenance'] = ['status' => 'warning', 'message' => 'Could not check maintenance mode'];
    }
}

// Output JSON
http_response_code($statusCode);
header('Content-Type: application/json');
echo json_encode([
    'status' => $status,
    'timestamp' => date('c'),
    'results' => $results,
], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
exit;