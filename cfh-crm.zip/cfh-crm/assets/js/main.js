/**
 * assets/js/main.js
 * 
 * Main JavaScript for CFH homepage.
 * Handles navigation, animations, and interactive elements.
 */

(function() {
    'use strict';

    // ── Navbar scroll behaviour ──────────────────────────────────────────────
    const nav = document.getElementById('mainNav');
    let ticking = false;

    function onScroll() {
        const y = window.scrollY;
        nav.classList.toggle('scrolled', y > 60);
        ticking = false;
    }

    window.addEventListener('scroll', function() {
        if (!ticking) {
            window.requestAnimationFrame(onScroll);
            ticking = true;
        }
    }, { passive: true });

    // ── Mobile menu toggle ──────────────────────────────────────────────────
    const toggle = document.getElementById('navToggle');
    const mobileMenu = document.getElementById('mobileMenu');

    function openMobileMenu() {
        mobileMenu.classList.add('open');
        mobileMenu.removeAttribute('aria-hidden');
        toggle.setAttribute('aria-expanded', 'true');
        document.body.style.overflow = 'hidden';
    }

    function closeMobileMenu() {
        mobileMenu.classList.remove('open');
        mobileMenu.setAttribute('aria-hidden', 'true');
        toggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
    }

    if (toggle) {
        toggle.addEventListener('click', function() {
            toggle.getAttribute('aria-expanded') === 'true' ? closeMobileMenu() : openMobileMenu();
        });
    }

    // Close mobile menu on link click
    mobileMenu.querySelectorAll('a').forEach(function(link) {
        link.addEventListener('click', closeMobileMenu);
    });

    // ── Scroll spy for active nav link ──────────────────────────────────────
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');

    if (sections.length && navLinks.length) {
        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    navLinks.forEach(function(link) {
                        link.classList.toggle('active', link.getAttribute('href') === '#' + entry.target.id);
                    });
                }
            });
        }, { rootMargin: '-40% 0px -55% 0px' });

        sections.forEach(function(section) {
            observer.observe(section);
        });
    }

    // ── FAQ: close others when one opens ──────────────────────────────────
    document.querySelectorAll('.faq-item').forEach(function(el) {
        el.addEventListener('toggle', function() {
            if (el.open) {
                document.querySelectorAll('.faq-item[open]').forEach(function(other) {
                    if (other !== el) {
                        other.removeAttribute('open');
                    }
                });
            }
        });
    });

    // ── Smooth anchor scroll ────────────────────────────────────────────────
    document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
        anchor.addEventListener('click', function(e) {
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

})();