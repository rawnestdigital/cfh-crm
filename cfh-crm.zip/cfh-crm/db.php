<?php
declare(strict_types=1);
if (!defined('CFH_BOOTSTRAP_LOADED')) {
    require_once __DIR__ . '/bootstrap.php';
}
if (!isset($pdo)) {
    $pdo = db();
}