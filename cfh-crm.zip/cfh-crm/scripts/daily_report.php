#!/usr/bin/env php
<?php
/**
 * scripts/daily_report.php
 * Daily report email to admin
 */

declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

use CFH\Database\ApplicantRepository;
use CFH\Database\SettingRepository;

$pdo = require dirname(__DIR__) . '/config/database.php';
$applicantRepo = new ApplicantRepository($pdo);
$settingRepo = new SettingRepository($pdo);

$stats = $applicantRepo->getStats();
$adminEmail = $settingRepo->get('notification_email') ?: 'admin@comeforhumanity.org';

$subject = "CFH Daily Report - " . date('Y-m-d');
$message = "CFH Daily Report\n";
$message .= "================\n\n";
$message .= "Date: " . date('Y-m-d H:i:s') . "\n";
$message .= "Total Applications: " . $stats['total'] . "\n";
$message .= "Pending: " . $stats['pending'] . "\n";
$message .= "Approved: " . $stats['approved'] . "\n";
$message .= "Rejected: " . $stats['rejected'] . "\n";
$message .= "Today: " . $stats['today'] . "\n";
$message .= "\nSent from CFH CRM\n";

mail($adminEmail, $subject, $message, "From: CFH CRM <no-reply@comeforhumanity.org>");

echo "Daily report sent to {$adminEmail}\n";
exit(0);