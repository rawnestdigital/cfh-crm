<?php
/**
 * config/database.php — Database Connection Factory
 */

declare(strict_types=1);

if (!isset($ENV)) {
    $ENV = require_once __DIR__ . '/bootstrap.php';
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }
    
    $host = $ENV['DB_HOST'] ?? 'localhost';
    $port = $ENV['DB_PORT'] ?? 3306;
    $name = $ENV['DB_NAME'] ?? 'cfh_volunteers';
    $user = $ENV['DB_USER'] ?? 'cfh_user';
    $pass = $ENV['DB_PASS'] ?? '';
    
    try {
        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 5,
        ]);
        $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->query("SELECT 1")->fetch();
        return $pdo;
    } catch (PDOException $e) {
        error_log("[DATABASE] Connection failed: " . $e->getMessage());
        throw new RuntimeException("Database connection failed", 0, $e);
    }
}

return db();
