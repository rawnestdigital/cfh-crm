<?php
/**
 * config/load_env.php — Pure PHP .env file loader
 */

declare(strict_types=1);

if (!function_exists('load_env')) {
    function load_env(string $path): array
    {
        if (!is_readable($path)) {
            throw new RuntimeException("Environment file not readable: {$path}");
        }

        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lines === false) {
            throw new RuntimeException("Failed to read environment file: {$path}");
        }

        $env = [];
        foreach ($lines as $line) {
            if (str_starts_with(trim($line), '#')) {
                continue;
            }
            if (!str_contains($line, '=')) {
                continue;
            }
            [$key, $value] = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);

            if (str_starts_with($value, '"') && str_ends_with($value, '"')) {
                $value = substr($value, 1, -1);
                $value = str_replace('\\"', '"', $value);
            } elseif (str_starts_with($value, "'") && str_ends_with($value, "'")) {
                $value = substr($value, 1, -1);
                $value = str_replace("\\'", "'", $value);
            }

            $value = str_replace('\n', "\n", $value);
            $value = preg_replace_callback('/\${([a-zA-Z0-9_]+)}/', function ($matches) use ($env) {
                return $env[$matches[1]] ?? $matches[0];
            }, $value);

            if ($value === 'true') {
                $value = true;
            } elseif ($value === 'false') {
                $value = false;
            } elseif ($value === 'null') {
                $value = null;
            } elseif (is_numeric($value) && !str_contains($value, '.')) {
                $value = (int) $value;
            } elseif (is_numeric($value) && str_contains($value, '.')) {
                $value = (float) $value;
            }

            $env[$key] = $value;
            putenv("{$key}=" . (is_string($value) ? $value : (string) $value));
        }

        return $env;
    }
}

if (!isset($ENV) && file_exists(dirname(__DIR__) . '/.env')) {
    $ENV = load_env(dirname(__DIR__) . '/.env');
}