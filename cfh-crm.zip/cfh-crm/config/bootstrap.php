<?php
/**
 * config/bootstrap.php — Production-hardened core bootstrap
 * 
 * Security features:
 *   - Error reporting suppressed in production, logged to file
 *   - Session management with HTTP-only, Secure, SameSite=Strict cookies
 *   - CSRF token generation and validation
 *   - XSS protection via h() helper
 *   - Secure redirect() and json_response()
 *   - Client IP detection with proxy support
 *   - Login rate limiting via session + file cache
 *   - Global exception handler with logging
 * 
 * This file must be included at the very top of every public entry point.
 */

declare(strict_types=1);

// Prevent direct access via web server
if (PHP_SAPI === 'cli' && !defined('STDIN')) {
    http_response_code(403);
    exit('Direct access prohibited');
}

// ──────────────────────────────────────────────────────────────────────────────
// 0. Load Environment
// ──────────────────────────────────────────────────────────────────────────────

require_once __DIR__ . '/load_env.php';

$ENV = $ENV ?? [];
$appEnv = $ENV['APP_ENV'] ?? 'production';
$debug = $ENV['APP_DEBUG'] ?? false;

// ──────────────────────────────────────────────────────────────────────────────
// 1. Error & Exception Handling
// ──────────────────────────────────────────────────────────────────────────────

// Set error reporting based on environment
if ($debug) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}

// Log file configuration
$logDir = dirname(__DIR__) . '/logs';
if (!is_dir($logDir)) {
    mkdir($logDir, 0755, true);
}
ini_set('error_log', $logDir . '/php_errors.log');

/**
 * Custom error handler - converts PHP errors to ErrorException.
 */
set_error_handler(function (int $severity, string $message, string $file, int $line): bool {
    // Respect error_reporting() settings
    if (!(error_reporting() & $severity)) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

/**
 * Global exception handler - logs and renders a safe error page.
 */
set_exception_handler(function (Throwable $e): void {
    $logDir = dirname(__DIR__) . '/logs';
    $logFile = $logDir . '/exceptions.log';
    
    $entry = sprintf(
        "[%s] %s: %s in %s:%d\nStack trace:\n%s\n",
        date('Y-m-d H:i:s'),
        get_class($e),
        $e->getMessage(),
        $e->getFile(),
        $e->getLine(),
        $e->getTraceAsString()
    );
    file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);

    // In production: show generic error page
    if (!($GLOBALS['debug'] ?? false)) {
        http_response_code(500);
        if (!headers_sent()) {
            header('Content-Type: text/html; charset=UTF-8');
        }
        echo '<!DOCTYPE html><html><head><title>500 - Server Error</title></head>'
           . '<body><h1>Sorry, something went wrong.</h1>'
           . '<p>We\'ve been notified. Please try again later.</p></body></html>';
        exit;
    }
    
    // In development: show detailed error
    http_response_code(500);
    throw $e;
});

// ──────────────────────────────────────────────────────────────────────────────
// 2. Session Management (Secure)
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Configure session cookie parameters with security flags.
 * 
 * Why: Prevents session hijacking via:
 *   - HttpOnly: Prevents JavaScript access
 *   - Secure: Only sent over HTTPS
 *   - SameSite=Strict: Prevents CSRF via cross-site requests
 *   - Path=/: Available across the entire site
 */
function configure_session(): void
{
    $secure = ($GLOBALS['ENV']['APP_ENV'] ?? 'production') === 'production' 
        || (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

    session_set_cookie_params([
        'lifetime' => 0,                    // Session cookie (expires on browser close)
        'path' => '/',
        'domain' => '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Strict',
    ]);

    // Change session name from default PHPSESSID
    $sessionName = $GLOBALS['ENV']['SESSION_NAME'] ?? 'CFH_SID';
    session_name($sessionName);
    
    // Set session save path if not default
    $savePath = dirname(__DIR__) . '/storage/private/sessions';
    if (!is_dir($savePath)) {
        mkdir($savePath, 0750, true);
    }
    session_save_path($savePath);
}

// Configure session before starting
configure_session();

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Regenerate session ID at intervals to prevent fixation.
 * 
 * Why: If an attacker obtains a valid session ID, they can only use it
 *      for a limited time before the ID changes.
 */
$interval = $ENV['SESSION_REGEN_INTERVAL'] ?? 900; // 15 minutes
if (!isset($_SESSION['_last_regen'])) {
    $_SESSION['_last_regen'] = time();
} elseif (time() - $_SESSION['_last_regen'] > $interval) {
    session_regenerate_id(true);
    $_SESSION['_last_regen'] = time();
}

// ──────────────────────────────────────────────────────────────────────────────
// 3. Security Helpers
// ──────────────────────────────────────────────────────────────────────────────

/**
 * HTML-encode a value for safe output.
 * 
 * Why: Prevents XSS attacks by escaping special characters.
 * 
 * @param string|int|float|null $value The value to escape
 * @return string Escaped string (empty string for null)
 */
function h($value): string
{
    if ($value === null) {
        return '';
    }
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * CSRF token generation.
 * 
 * Why: Protects against Cross-Site Request Forgery attacks by ensuring
 *      that POST requests originate from the same site.
 * 
 * @return string The CSRF token
 */
function csrf_token(): string
{
    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf_token'];
}

/**
 * CSRF token verification.
 * 
 * @param string|null $token The token to verify (defaults to POST['csrf_token'])
 * @throws RuntimeException If token is missing or invalid
 */
function csrf_verify(?string $token = null): void
{
    $submitted = $token ?? ($_POST['csrf_token'] ?? '');
    
    if ($submitted === '') {
        throw new RuntimeException('CSRF token missing');
    }
    
    if (!hash_equals(csrf_token(), $submitted)) {
        // Log the attempt for audit
        $ip = client_ip();
        error_log("[SECURITY] CSRF mismatch from IP: {$ip}");
        throw new RuntimeException('CSRF token mismatch');
    }
}

/**
 * Get client IP address with proxy support.
 * 
 * Why: Handles reverse proxies (Cloudflare, nginx) while preventing
 *      IP spoofing by validating the header value.
 * 
 * @return string The client IP address
 */
function client_ip(): string
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    // Try Cloudflare
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    // Try X-Forwarded-For (validate to prevent spoofing)
    elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $forwarded = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        $forwarded = trim($forwarded);
        if (filter_var($forwarded, FILTER_VALIDATE_IP)) {
            $ip = $forwarded;
        }
    }
    // Try X-Real-IP
    elseif (isset($_SERVER['HTTP_X_REAL_IP'])) {
        $realIp = trim($_SERVER['HTTP_X_REAL_IP']);
        if (filter_var($realIp, FILTER_VALIDATE_IP)) {
            $ip = $realIp;
        }
    }
    
    return $ip;
}

// ──────────────────────────────────────────────────────────────────────────────
// 4. Redirect and Response Helpers
// ──────────────────────────────────────────────────────────────────────────────

/**
 * HTTP redirect with proper cleanup.
 * 
 * Why: Ensures no output is sent before redirect and uses 302 by default.
 * 
 * @param string $url The destination URL
 * @param int $code HTTP status code (302, 301, etc.)
 */
function redirect(string $url, int $code = 302): never
{
    // Clean any pending output buffers
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // Prevent open redirects
    $allowedHosts = [$_SERVER['HTTP_HOST'] ?? ''];
    $parsed = parse_url($url);
    if (isset($parsed['host']) && !in_array($parsed['host'], $allowedHosts, true)) {
        $url = '/'; // Fallback to home
    }
    
    header("Location: {$url}", true, $code);
    exit;
}

/**
 * Send JSON response with proper headers.
 * 
 * Why: Standardizes API responses with correct Content-Type.
 * 
 * @param array $data The data to encode
 * @param int $code HTTP status code
 */
function json_response(array $data, int $code = 200): never
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ──────────────────────────────────────────────────────────────────────────────
// 5. Login Rate Limiting (Session + File Cache)
// ──────────────────────────────────────────────────────────────────────────────

/**
 * Check if an IP is locked due to too many failed login attempts.
 * 
 * Why: Prevents brute-force attacks by rate limiting login attempts.
 * 
 * @param string $ip Client IP address
 * @return bool True if locked
 */
function login_is_locked(string $ip): bool
{
    $lockFile = dirname(__DIR__) . '/storage/private/locks/' . md5($ip) . '.lock';
    
    if (!is_dir(dirname($lockFile))) {
        mkdir(dirname($lockFile), 0750, true);
    }
    
    if (!file_exists($lockFile)) {
        return false;
    }
    
    $data = file_get_contents($lockFile);
    if ($data === false) {
        return false;
    }
    
    $attempts = (int) $data;
    $maxAttempts = $GLOBALS['ENV']['LOGIN_MAX_ATTEMPTS'] ?? 5;
    
    return $attempts >= $maxAttempts;
}

/**
 * Record a failed login attempt.
 * 
 * Why: Increments the counter for the IP address.
 * 
 * @param string $ip Client IP address
 */
function login_record_failure(string $ip): void
{
    $lockFile = dirname(__DIR__) . '/storage/private/locks/' . md5($ip) . '.lock';
    
    if (!is_dir(dirname($lockFile))) {
        mkdir(dirname($lockFile), 0750, true);
    }
    
    $attempts = 1;
    if (file_exists($lockFile)) {
        $data = file_get_contents($lockFile);
        if ($data !== false) {
            $attempts = (int) $data + 1;
        }
    }
    
    file_put_contents($lockFile, (string) $attempts, LOCK_EX);
}

/**
 * Clear login lock for an IP after successful login.
 * 
 * @param string $ip Client IP address
 */
function login_clear(string $ip): void
{
    $lockFile = dirname(__DIR__) . '/storage/private/locks/' . md5($ip) . '.lock';
    if (file_exists($lockFile)) {
        unlink($lockFile);
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// 6. Application Constants
// ──────────────────────────────────────────────────────────────────────────────

// Define application constants (safe defaults)
define('APP_ENV', $appEnv);
define('APP_DEBUG', $debug);
define('APP_NAME', $ENV['APP_NAME'] ?? 'CFH');
define('APP_URL', $ENV['APP_URL'] ?? 'https://localhost');
define('APP_VERSION', $ENV['APP_VERSION'] ?? '3.0.0');
define('SESSION_LIFETIME', (int) ($ENV['SESSION_LIFETIME'] ?? 7200));
define('CSRF_TOKEN_LENGTH', 32);
define('UPLOAD_MAX_SIZE', (int) ($ENV['UPLOAD_MAX_SIZE'] ?? 2097152));

// ──────────────────────────────────────────────────────────────────────────────
// 7. Return Environment for Further Use
// ──────────────────────────────────────────────────────────────────────────────

return $ENV;