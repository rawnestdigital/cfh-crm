<?php
/**
 * views/homepage.php
 * 
 * Homepage template with all sections.
 * Used by public/index.php after fetching content.
 */

// Content is passed as $content variable
$hero = $content['hero'] ?? null;
$missions = $content['missions'] ?? [];
$stats = $content['stats'] ?? [];
$team = $content['team'] ?? [];
$programs = $content['programs'] ?? [];
$testimonials = $content['testimonials'] ?? [];
$events = $content['events'] ?? [];
$gallery = $content['gallery'] ?? [];
$faqs = $content['faqs'] ?? [];
$homeSettings = $content['settings'] ?? [];

$siteName = $homeSettings['site_name'] ?? 'CFH';
$siteTagline = $homeSettings['site_tagline'] ?? 'Making Humanity Prevail';
$primaryColor = $homeSettings['primary_color'] ?? '#10b981';
$socialFacebook = $homeSettings['social_facebook'] ?? '#';
$socialInstagram = $homeSettings['social_instagram'] ?? '#';
$socialTwitter = $homeSettings['social_twitter'] ?? '#';
$socialYoutube = $homeSettings['social_youtube'] ?? '#';
$contactEmail = $homeSettings['contact_email'] ?? 'hello@cfhbd.org';
$contactPhone = $homeSettings['contact_phone'] ?? '+880 1700-000000';
$address = $homeSettings['address'] ?? 'Meherpur, Bangladesh';
?>
<!DOCTYPE html>
<html lang="bn-BD">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($siteName) ?> | <?= h($siteTagline) ?></title>
    <meta name="description" content="<?= h($siteTagline) ?>">
    <meta name="theme-color" content="<?= h($primaryColor) ?>">
    
    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= h($siteName) ?>">
    <meta property="og:description" content="<?= h($siteTagline) ?>">
    <meta property="og:image" content="/assets/img/og-default.jpg">
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Noto+Sans+Bengali:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="/assets/css/style.css?v=<?= filemtime(dirname(__DIR__) . '/public/assets/css/style.css') ?>">
</head>
<body>
    <!-- Skip Link -->
    <a href="#mainContent" class="skip-link">Skip to main content</a>
    
    <!-- Navbar -->
    <header role="banner">
        <nav id="mainNav" role="navigation" aria-label="Primary navigation">
            <a href="/" class="nav-logo">
                <div class="logo-mark">CF</div>
                <span><?= h($siteName) ?></span>
            </a>
            
            <div class="nav-menu">
                <a href="#impact" class="nav-link">Impact</a>
                <a href="#programs" class="nav-link">Programs</a>
                <a href="#mission" class="nav-link">Mission</a>
                <a href="#events" class="nav-link">Events</a>
                <a href="#team" class="nav-link">Team</a>
                <a href="#faq" class="nav-link">FAQ</a>
                <a href="/register" class="btn btn-primary btn-sm">Join Movement</a>
            </div>
            
            <button class="nav-toggle" id="navToggle" aria-label="Toggle navigation">
                <span></span><span></span><span></span>
            </button>
        </nav>
    </header>

    <!-- Mobile Menu -->
    <div id="mobileMenu" role="dialog" aria-modal="true" aria-label="Mobile navigation" aria-hidden="true">
        <a href="#impact" onclick="closeMobileMenu()">Impact</a>
        <a href="#programs" onclick="closeMobileMenu()">Programs</a>
        <a href="#mission" onclick="closeMobileMenu()">Mission</a>
        <a href="#events" onclick="closeMobileMenu()">Events</a>
        <a href="#team" onclick="closeMobileMenu()">Team</a>
        <a href="#faq" onclick="closeMobileMenu()">FAQ</a>
        <a href="/register" class="btn btn-primary">Join Movement</a>
    </div>

    <main id="mainContent">
        <!-- Hero Section -->
        <section id="hero" aria-labelledby="heroHeading">
            <div class="container hero-content">
                <div data-aos="fade-up">
                    <span class="hero-eyebrow">Founded 2024</span>
                    <h1 id="heroHeading">
                        <?= $hero['title'] ?? 'Building a <span class="gradient-text">Humane Bangladesh</span> Together.' ?>
                    </h1>
                    <p class="hero-desc">
                        <?= h($hero['description'] ?? 'CFH is a technology-driven volunteer organization empowering youth to solve social crises across Bangladesh with compassion and action.') ?>
                    </p>
                    <div class="hero-actions">
                        <a href="#impact" class="btn btn-primary btn-lg">Our Impact</a>
                        <a href="#programs" class="btn btn-secondary btn-lg">Explore Programs</a>
                        <a href="/register" class="btn btn-outline btn-lg">Join Now</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Stats / Impact -->
        <section id="impact" class="section" aria-labelledby="impactHeading">
            <div class="container">
                <div class="section-header" data-aos="fade-up">
                    <div class="section-badge"><i class="fas fa-fire"></i> Live Impact</div>
                    <h2 class="section-title" id="impactHeading">Numbers That <span class="gradient-text">Actually Matter</span></h2>
                </div>
                
                <div class="stats-grid">
                    <?php foreach ($stats as $stat): ?>
                        <div class="stat-card" data-aos="zoom-in" data-aos-delay="<?= $loopIndex ?? 0 ?>">
                            <div class="stat-number"><?= number_format((int) $stat['value']) ?><?= h($stat['suffix'] ?? '') ?></div>
                            <div class="stat-label"><?= h($stat['label']) ?></div>
                            <div class="stat-icon"><i class="<?= h($stat['icon'] ?? 'fas fa-star') ?>"></i></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- Programs -->
        <section id="programs" class="section" aria-labelledby="programsHeading">
            <div class="container">
                <div class="section-header center" data-aos="fade-up">
                    <div class="section-badge"><i class="fas fa-rocket"></i> Programs</div>
                    <h2 class="section-title" id="programsHeading">What We <span class="gradient-text">Work On</span></h2>
                </div>
                
                <div class="programs-grid">
                    <?php foreach ($programs as $prog): ?>
                        <div class="program-card" data-aos="fade-up">
                            <div class="program-icon"><i class="<?= h($prog['icon'] ?? 'fas fa-hands-helping') ?>"></i></div>
                            <h3><?= h($prog['title']) ?></h3>
                            <p><?= h($prog['description']) ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- Mission -->
        <section id="mission" class="section" aria-labelledby="missionHeading">
            <div class="container">
                <div class="section-header" data-aos="fade-up">
                    <div class="section-badge"><i class="fas fa-compass"></i> Our Mission</div>
                    <h2 class="section-title" id="missionHeading">Why We <span class="gradient-text">Exist</span></h2>
                </div>
                
                <div class="mission-grid">
                    <?php foreach ($missions as $m): ?>
                        <div class="mission-item">
                            <div class="mission-dot"><i class="fas <?= h($m['icon'] ?? 'fa-check') ?>"></i></div>
                            <div class="mission-body">
                                <h3><?= h($m['title']) ?></h3>
                                <p><?= h($m['description']) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- Events -->
        <section id="events" class="section" aria-labelledby="eventsHeading">
            <div class="container">
                <div class="section-header" data-aos="fade-up">
                    <div class="section-badge"><i class="fas fa-calendar-alt"></i> Events</div>
                    <h2 class="section-title" id="eventsHeading">Upcoming <span class="gradient-text">Activities</span></h2>
                </div>
                
                <div class="events-list">
                    <?php foreach ($events as $event): ?>
                        <div class="event-card" data-aos="fade-up">
                            <div class="event-date">
                                <span class="day"><?= date('d', strtotime($event['date'] ?? 'now')) ?></span>
                                <span class="month"><?= date('M', strtotime($event['date'] ?? 'now')) ?></span>
                            </div>
                            <div class="event-info">
                                <h3><?= h($event['title']) ?></h3>
                                <p><i class="fas fa-map-marker-alt"></i> <?= h($event['location'] ?? '') ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- Team -->
        <section id="team" class="section" aria-labelledby="teamHeading">
            <div class="container">
                <div class="section-header center" data-aos="fade-up">
                    <div class="section-badge"><i class="fas fa-crown"></i> Leadership</div>
                    <h2 class="section-title" id="teamHeading">Meet the <span class="gradient-text">Team</span></h2>
                </div>
                
                <div class="team-grid">
                    <?php foreach ($team as $member): ?>
                        <div class="team-card" data-aos="fade-up">
                            <img src="/storage/public/uploads/<?= h($member['photo']) ?>" alt="<?= h($member['name']) ?>" class="team-avatar">
                            <h4><?= h($member['name']) ?></h4>
                            <p class="team-role"><?= h($member['position']) ?></p>
                            <div class="team-socials">
                                <?php if (!empty($member['facebook'])): ?>
                                    <a href="<?= h($member['facebook']) ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <?php endif; ?>
                                <?php if (!empty($member['linkedin'])): ?>
                                    <a href="<?= h($member['linkedin']) ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- Testimonials -->
        <section id="testimonials" class="section" aria-labelledby="testimonialHeading">
            <div class="container">
                <div class="section-header center" data-aos="fade-up">
                    <div class="section-badge"><i class="fas fa-comment-dots"></i> Testimonials</div>
                    <h2 class="section-title" id="testimonialHeading">Words From <span class="gradient-text">Community</span></h2>
                </div>
                
                <div class="testimonials-grid">
                    <?php foreach ($testimonials as $t): ?>
                        <div class="testimonial-card" data-aos="fade-up">
                            <div class="testimonial-quote">&ldquo;</div>
                            <p class="testimonial-text"><?= h($t['text']) ?></p>
                            <div class="testimonial-author">
                                <img src="/storage/public/uploads/<?= h($t['photo'] ?? '') ?>" alt="<?= h($t['name']) ?>">
                                <div>
                                    <p class="name"><?= h($t['name']) ?></p>
                                    <p class="meta"><?= h($t['meta'] ?? '') ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- FAQ -->
        <section id="faq" class="section" aria-labelledby="faqHeading">
            <div class="container">
                <div class="section-header center" data-aos="fade-up">
                    <div class="section-badge"><i class="fas fa-question-circle"></i> FAQ</div>
                    <h2 class="section-title" id="faqHeading">Common <span class="gradient-text">Questions</span></h2>
                </div>
                
                <div class="faq-grid">
                    <?php foreach ($faqs as $faq): ?>
                        <details class="faq-item">
                            <summary><?= h($faq['question']) ?></summary>
                            <div class="faq-answer"><?= h($faq['answer']) ?></div>
                        </details>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer role="contentinfo">
        <div class="container">
            <div class="footer-main">
                <div class="footer-brand">
                    <h3><?= h($siteName) ?></h3>
                    <p><?= h($siteTagline) ?></p>
                    <div class="footer-socials">
                        <a href="<?= h($socialFacebook) ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                        <a href="<?= h($socialInstagram) ?>" target="_blank"><i class="fab fa-instagram"></i></a>
                        <a href="<?= h($socialTwitter) ?>" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="<?= h($socialYoutube) ?>" target="_blank"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                
                <div class="footer-col">
                    <h4>Organization</h4>
                    <ul>
                        <li><a href="/about">About</a></li>
                        <li><a href="/programs">Programs</a></li>
                        <li><a href="/team">Team</a></li>
                        <li><a href="/gallery">Gallery</a></li>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h4>Get Involved</h4>
                    <ul>
                        <li><a href="/register">Volunteer</a></li>
                        <li><a href="/donate">Donate</a></li>
                        <li><a href="/events">Events</a></li>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h4>Contact</h4>
                    <ul>
                        <li><a href="mailto:<?= h($contactEmail) ?>"><?= h($contactEmail) ?></a></li>
                        <li><a href="tel:<?= h($contactPhone) ?>"><?= h($contactPhone) ?></a></li>
                        <li><?= h($address) ?></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> <?= h($siteName) ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="/assets/js/main.js?v=<?= filemtime(dirname(__DIR__) . '/public/assets/js/main.js') ?>"></script>
</body>
</html>