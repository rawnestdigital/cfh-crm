-- install.sql — Complete CFH Database Schema
-- Run this once on a fresh database
-- Version: 3.0.0

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_admin
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` enum('superadmin','admin','moderator') NOT NULL DEFAULT 'admin',
  `permissions` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_login_attempts
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_login_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(50) NOT NULL,
  `attempted_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ip_address` (`ip_address`),
  KEY `attempted_at` (`attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_audit_logs
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_audit_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned DEFAULT NULL,
  `action_type` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `admin_id` (`admin_id`),
  KEY `action_type` (`action_type`),
  KEY `created_at` (`created_at`),
  KEY `ip_address` (`ip_address`),
  CONSTRAINT `fk_audit_admin` FOREIGN KEY (`admin_id`) REFERENCES `cfh_admin` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_applicants
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_applicants` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `team_category` varchar(50) DEFAULT NULL,
  `division` varchar(50) DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `nid_front` varchar(255) DEFAULT NULL,
  `nid_back` varchar(255) DEFAULT NULL,
  `trx_id` varchar(50) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `division` (`division`),
  KEY `district` (`district`),
  KEY `phone` (`phone`),
  KEY `trx_id` (`trx_id`),
  KEY `created_at` (`created_at`),
  KEY `status_created` (`status`, `created_at`),
  KEY `division_status` (`division`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_settings (system settings)
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` text NOT NULL,
  `group` varchar(50) DEFAULT 'general',
  `type` enum('string','boolean','number','json') NOT NULL DEFAULT 'string',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_home_hero
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_home_hero` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subtitle` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `button_text` varchar(100) DEFAULT NULL,
  `button_link` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_home_mission
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_home_mission` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `type` enum('mission','vision','core_value') NOT NULL DEFAULT 'mission',
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_home_stats
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_home_stats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `value` int(10) unsigned NOT NULL,
  `suffix` varchar(20) DEFAULT '',
  `icon` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_home_team
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_home_team` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_home_programs
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_home_programs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `beneficiaries` varchar(50) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_home_testimonials
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_home_testimonials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) DEFAULT NULL,
  `message` text NOT NULL,
  `rating` tinyint(1) unsigned NOT NULL DEFAULT 5,
  `photo` varchar(255) DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_home_events
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_home_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `date` date DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_home_gallery
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_home_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_home_faqs
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_home_faqs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: cfh_home_settings
-- ============================================================
CREATE TABLE IF NOT EXISTS `cfh_home_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` text NOT NULL,
  `group` varchar(50) DEFAULT 'general',
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- DEFAULT DATA
-- ============================================================

-- 1. Default admin (password: generate with `password_hash('your_password', PASSWORD_DEFAULT)`)
-- Replace the hash below with a real one!
INSERT INTO `cfh_admin` (`id`, `username`, `password`, `full_name`, `role`, `is_active`)
VALUES (1, 'admin', '$2y$12$W4nX5wZdUZx4Zex3Pw/Q7uKjA0Yy1QrPQpP1PtLQ6L9Q9Q9Q9Q9Q9Q9Q', 'Administrator', 'superadmin', 1)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- 2. Default home hero
INSERT INTO `cfh_home_hero` (`id`, `title`, `subtitle`, `description`, `button_text`, `button_link`, `image`)
VALUES (1, 'Building a <span class="gradient-text">Humane Bangladesh</span> Together.',
        'Founded 2024', 
        'CFH is a technology-driven volunteer organization empowering youth to solve social crises across Bangladesh with compassion and action.',
        'Join Movement', '/register', NULL)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- 3. Default stats
INSERT INTO `cfh_home_stats` (`label`, `value`, `suffix`, `icon`, `description`, `order`) VALUES
('Volunteers', 1200, '+', 'fas fa-users', 'Active volunteers nationwide', 1),
('Lives Impacted', 45000, '+', 'fas fa-hands-helping', 'People helped directly', 2),
('Districts', 64, '/64', 'fas fa-map-marker-alt', 'Coverage across Bangladesh', 3),
('Projects', 38, '+', 'fas fa-seedling', 'Completed initiatives', 4)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- 4. Default missions
INSERT INTO `cfh_home_mission` (`title`, `description`, `icon`, `type`, `order`) VALUES
('Identify', 'We use field research and data analytics to find where help is needed most.', 'fa-eye', 'mission', 1),
('Mobilise', 'We connect passionate volunteers with the right skills to the right cause.', 'fa-users', 'mission', 2),
('Act Fast', 'Rapid deployment ensures aid reaches people within 48 hours of a crisis.', 'fa-bolt', 'mission', 3),
('Measure', 'Every intervention is measured for impact, ensuring accountability and learning.', 'fa-chart-bar', 'mission', 4)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- 5. Default programs
INSERT INTO `cfh_home_programs` (`title`, `description`, `icon`, `beneficiaries`, `region`, `order`) VALUES
('Emergency Relief', 'Rapid response teams providing food, shelter, and medical aid during crises.', 'fas fa-medkit', '12,000+', 'Nationwide', 1),
('Youth Education', 'Scholarships, tutoring centres, and digital skills training for underprivileged youth.', 'fas fa-graduation-cap', '5,400+', 'Meherpur, Dhaka', 2),
('Clean Water Access', 'Installation and maintenance of tube-wells and water purification units in remote areas.', 'fas fa-tint', '38 villages', 'Rural areas', 3),
('Climate Action', 'Tree plantation drives and eco-awareness programs protecting our natural ecosystems.', 'fas fa-seedling', '80,000+ trees', 'Nationwide', 4),
('Digital Bangladesh', 'Free coding bootcamps and tech literacy workshops transforming rural youth into digital citizens.', 'fas fa-laptop-code', '2,200+', 'Nationwide', 5),
('Women Empowerment', 'Vocational training, micro-finance support, and legal aid for women in marginalized communities.', 'fas fa-female', '3,800+', 'Rural areas', 6)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- 6. Default testimonials
INSERT INTO `cfh_home_testimonials` (`name`, `position`, `message`, `rating`, `order`) VALUES
('Rahul Biswas', 'Former beneficiary, Dhaka', 'CFH changed my life. The youth bootcamp gave me the skills I needed to get my first tech job.', 5, 1),
('Nusrat Jahan', 'Volunteer, Rajshahi', 'As a volunteer here for 2 years, I have never seen an organization so transparent and impactful.', 5, 2),
('Abdul Karim', 'Resident, Meherpur', 'The medical camp reached our village when no one else would. Truly humanity first.', 5, 3)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- 7. Default FAQs
INSERT INTO `cfh_home_faqs` (`question`, `answer`, `order`) VALUES
('How do I become a volunteer?', 'Register on our website, complete a short onboarding quiz, and you will be matched with a local chapter within 48 hours.', 1),
('Is CFH a registered organization?', 'Yes. CFH is officially registered with the NGO Affairs Bureau of Bangladesh under registration number XXXXX.', 2),
('How are donations used?', 'At least 90% of every donation goes directly to programs. Our full financial report is published annually on our website.', 3),
('Can I volunteer from abroad?', 'Absolutely. We have a dedicated Digital Volunteer Program where diaspora members contribute remotely through skills, advocacy, and fundraising.', 4)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- 8. Default home settings
INSERT INTO `cfh_home_settings` (`key`, `value`, `group`, `order`) VALUES
('site_name', 'CFH', 'general', 1),
('site_tagline', 'Making Humanity Prevail — Join the leading volunteer movement in Bangladesh.', 'general', 2),
('primary_color', '#10b981', 'style', 3),
('secondary_color', '#f59e0b', 'style', 4),
('accent_color', '#6366f1', 'style', 5),
('footer_text', 'Humanity First. Always.', 'general', 6),
('contact_email', 'hello@cfhbd.org', 'contact', 7),
('contact_phone', '+880 1700-000000', 'contact', 8),
('address', 'Meherpur, Bangladesh', 'contact', 9),
('social_facebook', 'https://facebook.com/cfhbd', 'social', 10),
('social_instagram', 'https://instagram.com/cfhbd', 'social', 11),
('social_twitter', 'https://twitter.com/cfhbd', 'social', 12),
('social_youtube', 'https://youtube.com/@cfhbd', 'social', 13),
('registration_url', '/register', 'navigation', 14),
('donate_url', '/donate', 'navigation', 15)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- 9. Default system settings
INSERT INTO `cfh_settings` (`key`, `value`, `group`, `type`) VALUES
('org_name', 'CFH - Come For Humanity', 'organization', 'string'),
('org_email', 'hello@cfhbd.org', 'organization', 'string'),
('org_phone', '+880 1700-000000', 'organization', 'string'),
('org_address', 'Meherpur, Bangladesh', 'organization', 'string'),
('reg_fee', '200', 'payment', 'number'),
('bkash_number', '017XXXXXXXX', 'payment', 'string'),
('applicant_limit', '0', 'system', 'number'),
('notification_email', 'notify@cfhbd.org', 'system', 'string'),
('maintenance_mode', '0', 'system', 'boolean')
ON DUPLICATE KEY UPDATE `id`=`id`;

SET FOREIGN_KEY_CHECKS = 1;