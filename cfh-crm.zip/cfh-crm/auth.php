<?php
declare(strict_types=1);

/**
 * CFH ENTERPRISE AUTH LAYER
 * Secure Login + Session Protection
 */

require_once __DIR__ . '/bootstrap.php';

/* =========================
   AUTO REDIRECT IF LOGGED IN
========================= */
if (!empty($_SESSION['admin_id'])) {
    header('Location: /admin/dashboard.php');
    exit;
}

/* =========================
   CLIENT IP (SAFE)
========================= */
function client_ip(): string {
    return filter_var(
        $_SERVER['HTTP_X_FORWARDED_FOR']
        ?? $_SERVER['REMOTE_ADDR']
        ?? 'unknown',
        FILTER_VALIDATE_IP
    ) ?: 'unknown';
}

/* =========================
   LOGIN LOCK CHECK (DB + SESSION)
========================= */
function is_ip_locked(PDO $pdo, string $ip): bool {

    // DB cleanup old attempts
    $pdo->prepare("
        DELETE FROM cfh_login_attempts
        WHERE attempted_at < DATE_SUB(NOW(), INTERVAL ? SECOND)
    ")->execute([LOGIN_LOCKOUT_TIME]);

    // count attempts
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM cfh_login_attempts
        WHERE ip_address = ?
        AND attempted_at >= DATE_SUB(NOW(), INTERVAL ? SECOND)
    ");

    $stmt->execute([$ip, LOGIN_LOCKOUT_TIME]);

    return (int)$stmt->fetchColumn() >= LOGIN_MAX_ATTEMPTS;
}

/* =========================
   LOGIN PROCESS
========================= */
$error = '';
$ip = client_ip();
$locked = is_ip_locked($pdo, $ip);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$locked) {

    try {
        csrf_verify();

        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');

        if ($username === '' || $password === '') {
            throw new RuntimeException('ইউজারনেম ও পাসওয়ার্ড আবশ্যক।');
        }

        if (strlen($username) > 50) {
            throw new RuntimeException('ইউজারনেম খুব বড়।');
        }

        /* =========================
           FETCH ADMIN
        ========================= */
        $stmt = $pdo->prepare("
            SELECT id, username, password, full_name, is_active
            FROM cfh_admin
            WHERE username = ?
            LIMIT 1
        ");

        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        /* =========================
           PASSWORD CHECK
        ========================= */
        if ($admin && (int)$admin['is_active'] === 1 &&
            password_verify($password, $admin['password'])) {

            /* password rehash */
            if (password_needs_rehash($admin['password'], PASSWORD_DEFAULT)) {
                $pdo->prepare("UPDATE cfh_admin SET password=? WHERE id=?")
                    ->execute([password_hash($password, PASSWORD_DEFAULT), $admin['id']]);
            }

            /* session hardening */
            session_regenerate_id(true);

            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['full_name'];
            $_SESSION['login_ip'] = $ip;
            $_SESSION['user_agent'] = hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '');
            $_SESSION['last_regen'] = time();
            $_SESSION['last_activity'] = time();

            /* clear attempts */
            unset($_SESSION['login_attempts']);

            /* audit log */
            log_audit($pdo, 'LOGIN_SUCCESS', "Admin login: {$username}");

            header('Location: /admin/dashboard.php');
            exit;
        }

        /* =========================
           FAILED LOGIN LOG
        ========================= */
        $pdo->prepare("
            INSERT INTO cfh_login_attempts (ip_address, username)
            VALUES (?, ?)
        ")->execute([$ip, mb_substr($username, 0, 50)]);

        log_audit($pdo, 'LOGIN_FAILED', "Failed login attempt: {$username}");

        throw new RuntimeException('ভুল ইউজারনেম বা পাসওয়ার্ড।');

    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<title>CFH Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
body {
    font-family: sans-serif;
    background: #0a0f1e;
    color: #fff;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.box {
    width: 360px;
    padding: 30px;
    background:#111827;
    border-radius:16px;
}

input {
    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:10px;
    border:1px solid #333;
    background:#1f2937;
    color:#fff;
}

button {
    width:100%;
    padding:12px;
    background:#10b981;
    border:none;
    border-radius:10px;
    color:#fff;
    font-weight:bold;
    cursor:pointer;
}

.error {
    color:#ef4444;
    font-size:14px;
    margin-bottom:10px;
}
</style>
</head>

<body>

<div class="box">
    <h2>Admin Login</h2>

    <?php if ($locked): ?>
        <p class="error">⛔ IP সাময়িকভাবে ব্লক করা হয়েছে</p>
    <?php endif; ?>

    <?php if ($error): ?>
        <p class="error"><?= h($error) ?></p>
    <?php endif; ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" <?= $locked ? 'disabled' : '' ?>>
            Login
        </button>
    </form>
</div>

</body>
</html>