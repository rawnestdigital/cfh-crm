<?php
$hash = password_hash('@@cfh@@', PASSWORD_DEFAULT);
echo $hash;