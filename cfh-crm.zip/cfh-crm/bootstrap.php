<?php
/**
 * config/bootstrap.php — Production-hardened core bootstrap
 */

declare(strict_types=1);

// Prevent direct access via web server
if (PHP_SAPI === 'cli' && !defined('STDIN')) {
    http_response_code(403);
    exit('Direct access prohibited');
}

// Load environment
require_once __DIR__ . '/load_env.php';

$ENV = $ENV ?? [];
$appEnv = $ENV['APP_ENV'] ?? 'production';
$debug = $ENV['APP_DEBUG'] ?? false;

// Error & Exception Handling
if ($debug) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}

$logDir = dirname(__DIR__) . '/logs';
if (!is_dir($logDir)) {
    mkdir($logDir, 0755, true);
}
ini_set('error_log', $logDir . '/php_errors.log');

set_error_handler(function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

set_exception_handler(function (Throwable $e): void {
    $logDir = dirname(__DIR__) . '/logs';
    $logFile = $logDir . '/exceptions.log';
    
    $entry = sprintf(
        "[%s] %s: %s in %s:%d\nStack trace:\n%s\n",
        date('Y-m-d H:i:s'),
        get_class($e),
        $e->getMessage(),
        $e->getFile(),
        $e->getLine(),
        $e->getTraceAsString()
    );
    file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);

    if (!($GLOBALS['debug'] ?? false)) {
        http_response_code(500);
        if (!headers_sent()) {
            header('Content-Type: text/html; charset=UTF-8');
        }
        echo '<!DOCTYPE html><html><head><title>500 - Server Error</title></head>'
           . '<body><h1>Sorry, something went wrong.</h1>'
           . '<p>We\'ve been notified. Please try again later.</p></body></html>';
        exit;
    }
    
    http_response_code(500);
    throw $e;
});

// Session Management
function configure_session(): void
{
    $secure = ($GLOBALS['ENV']['APP_ENV'] ?? 'production') === 'production' 
        || (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

    $sessionDomain = $_ENV['SESSION_DOMAIN'] ?? '';
    $params = [
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Strict',
    ];
    if ($sessionDomain) {
        $params['domain'] = $sessionDomain;
    }
    session_set_cookie_params($params);

    $sessionName = $ENV['SESSION_NAME'] ?? 'CFH_SID';
    session_name($sessionName);
    
    $savePath = dirname(__DIR__) . '/storage/private/sessions';
    if (!is_dir($savePath)) {
        mkdir($savePath, 0750, true);
    }
    session_save_path($savePath);
}

configure_session();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$interval = $ENV['SESSION_REGEN_INTERVAL'] ?? 900;
if (!isset($_SESSION['_last_regen'])) {
    $_SESSION['_last_regen'] = time();
} elseif (time() - $_SESSION['_last_regen'] > $interval) {
    session_regenerate_id(true);
    $_SESSION['_last_regen'] = time();
}

// Security Helpers
function h($value): string
{
    if ($value === null) {
        return '';
    }
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrf_token(): string
{
    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf_token'];
}

function csrf_verify(?string $token = null): void
{
    $submitted = $token ?? ($_POST['csrf_token'] ?? '');
    if ($submitted === '') {
        throw new RuntimeException('CSRF token missing');
    }
    if (!hash_equals(csrf_token(), $submitted)) {
        $ip = client_ip();
        error_log("[SECURITY] CSRF mismatch from IP: {$ip}");
        throw new RuntimeException('CSRF token mismatch');
    }
}

function client_ip(): string
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $forwarded = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        $forwarded = trim($forwarded);
        if (filter_var($forwarded, FILTER_VALIDATE_IP)) {
            $ip = $forwarded;
        }
    } elseif (isset($_SERVER['HTTP_X_REAL_IP'])) {
        $realIp = trim($_SERVER['HTTP_X_REAL_IP']);
        if (filter_var($realIp, FILTER_VALIDATE_IP)) {
            $ip = $realIp;
        }
    }
    return $ip;
}

// Redirect and Response Helpers
function redirect(string $url, int $code = 302): never
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    $allowedHosts = [$_SERVER['HTTP_HOST'] ?? ''];
    $parsed = parse_url($url);
    if (isset($parsed['host']) && !in_array($parsed['host'], $allowedHosts, true)) {
        $url = '/';
    }
    header("Location: {$url}", true, $code);
    exit;
}

function json_response(array $data, int $code = 200): never
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// Login Rate Limiting
function login_is_locked(string $ip): bool
{
    $lockFile = dirname(__DIR__) . '/storage/private/locks/' . md5($ip) . '.lock';
    if (!is_dir(dirname($lockFile))) {
        mkdir(dirname($lockFile), 0750, true);
    }
    if (!file_exists($lockFile)) {
        return false;
    }
    $data = file_get_contents($lockFile);
    if ($data === false) {
        return false;
    }
    $attempts = (int) $data;
    $maxAttempts = $GLOBALS['ENV']['LOGIN_MAX_ATTEMPTS'] ?? 5;
    return $attempts >= $maxAttempts;
}

function login_record_failure(string $ip): void
{
    $lockFile = dirname(__DIR__) . '/storage/private/locks/' . md5($ip) . '.lock';
    if (!is_dir(dirname($lockFile))) {
        mkdir(dirname($lockFile), 0750, true);
    }
    $attempts = 1;
    if (file_exists($lockFile)) {
        $data = file_get_contents($lockFile);
        if ($data !== false) {
            $attempts = (int) $data + 1;
        }
    }
    file_put_contents($lockFile, (string) $attempts, LOCK_EX);
}

function login_clear(string $ip): void
{
    $lockFile = dirname(__DIR__) . '/storage/private/locks/' . md5($ip) . '.lock';
    if (file_exists($lockFile)) {
        unlink($lockFile);
    }
}

// Application Constants
define('APP_ENV', $appEnv);
define('APP_DEBUG', $debug);
define('APP_NAME', $ENV['APP_NAME'] ?? 'CFH');
define('APP_URL', $ENV['APP_URL'] ?? 'https://localhost');
define('APP_VERSION', $ENV['APP_VERSION'] ?? '3.0.0');
define('SESSION_LIFETIME', (int) ($ENV['SESSION_LIFETIME'] ?? 7200));
define('CSRF_TOKEN_LENGTH', 32);
define('UPLOAD_MAX_SIZE', (int) ($ENV['UPLOAD_MAX_SIZE'] ?? 2097152));

return $ENV;